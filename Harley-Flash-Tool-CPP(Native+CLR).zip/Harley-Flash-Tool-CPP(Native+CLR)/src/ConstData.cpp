#include "ConstData.h"
namespace Harley_FlashTool {
	Array<char>* ConstData::KeysArray1;
	Array<char>* ConstData::KeysArray2;
	ConstData::ConstData(){
		Array<char>* expr_0A = new Array<char>(131072);
		RuntimeHelpers::InitializeArray(expr_0A, fieldof(<PrivateImplementationDetails>::D281234C25C6FF9D08538B780636BCC5BBE87FC2F7D7DBBA3ECE5EF386D81277)->FieldHandle);
		ConstData::KeysArray1 = expr_0A;
		Array<char>* expr_24 = new Array<char>(524288);
		RuntimeHelpers::InitializeArray(expr_24, fieldof(<PrivateImplementationDetails>::FAD5A77D3B5F39AC53FA7A3ACA57C6F47065C7D432CCD3E2E7935F440A67D9DA)->FieldHandle);
		ConstData::KeysArray2 = expr_24;
	}

}