#pragma once
using namespace System;
using namespace System::ComponentModel;
using namespace System::Drawing;
using namespace System::Windows::Forms;
namespace Harley_FlashTool {
	class MainForm : public virtual Form, public virtual Object{
		public:
		enum class ECUTYPE{
			MC9S12DJ128,
			MC9S12XEP768,
			TC265_MT21M,
			unknown
		};
		public:
		class ComboboxItem : public virtual Object
		{
			public:
			String* ComboboxItem::getText()
			{
				return Text_var;
			}
			void ComboboxItem::setText(String* value)
			{
				Text_var = value;
			}
			public:
			Object* ComboboxItem::getValue()
			{
				return Value_var;
			}
			void ComboboxItem::setValue(Object* value)
			{
				Value_var = value;
			}
			public:
			virtual String* ToString()
			{
				return this->getText();
			}
			public:
			String* Text_var;
			public:
			Object* Value_var;
			public:
			ComboboxItem::ComboboxItem()
			{
				Text_var = (String*)(0);
				Value_var = (Object*)(0);
			}
		};
		public:
		class Iso14230RecvObj : public virtual Object
		{
			public:
			uint Iso14230RecvObj::gete1_Timestamp()
			{
				return e1_Timestamp_var;
			}
			void Iso14230RecvObj::sete1_Timestamp(uint value)
			{
				e1_Timestamp_var = value;
			}
			public:
			char Iso14230RecvObj::gete2_Src()
			{
				return e2_Src_var;
			}
			void Iso14230RecvObj::sete2_Src(char value)
			{
				e2_Src_var = value;
			}
			public:
			char Iso14230RecvObj::gete3_Dst()
			{
				return e3_Dst_var;
			}
			void Iso14230RecvObj::sete3_Dst(char value)
			{
				e3_Dst_var = value;
			}
			public:
			Array<char>* Iso14230RecvObj::gete4_Data()
			{
				return e4_Data_var;
			}
			void Iso14230RecvObj::sete4_Data(Array<char>* value)
			{
				e4_Data_var = value;
			}
			public:
			uint e1_Timestamp_var;
			public:
			char e2_Src_var;
			public:
			char e3_Dst_var;
			public:
			Array<char>* e4_Data_var;
			public:
			Iso14230RecvObj::Iso14230RecvObj()
			{
				e1_Timestamp_var = (uint)(0);
				e2_Src_var = (char)(0);
				e3_Dst_var = (char)(0);
				e4_Data_var = (Array<char>*)(0);
			}
		};
		public:
		class Iso15765Recv : public virtual Object
		{
			public:
			uint Iso15765Recv::gete1_Timestamp()
			{
				return e1_Timestamp_var;
			}
			void Iso15765Recv::sete1_Timestamp(uint value)
			{
				e1_Timestamp_var = value;
			}
			public:
			uint Iso15765Recv::gete2_CanRxId()
			{
				return e2_CanRxId_var;
			}
			void Iso15765Recv::sete2_CanRxId(uint value)
			{
				e2_CanRxId_var = value;
			}
			public:
			char Iso15765Recv::gete3_DiagAddr()
			{
				return e3_DiagAddr_var;
			}
			void Iso15765Recv::sete3_DiagAddr(char value)
			{
				e3_DiagAddr_var = value;
			}
			public:
			Array<char>* Iso15765Recv::gete4_Data()
			{
				return e4_Data_var;
			}
			void Iso15765Recv::sete4_Data(Array<char>* value)
			{
				e4_Data_var = value;
			}
			public:
			uint e1_Timestamp_var;
			public:
			uint e2_CanRxId_var;
			public:
			char e3_DiagAddr_var;
			public:
			Array<char>* e4_Data_var;
			public:
			Iso15765Recv::Iso15765Recv()
			{
				e1_Timestamp_var = (uint)(0);
				e2_CanRxId_var = (uint)(0);
				e3_DiagAddr_var = (char)(0);
				e4_Data_var = (Array<char>*)(0);
			}
		};
		public:
		struct ChecksumArea : public virtual ValueType
		{
			long StartAddress;
			long EndAddress;
			long StoredAddress;
			String* AreaName;
			ChecksumArea::ChecksumArea(long start, long end, long stored, String* name)
			{
				this->StartAddress = start;
				this->EndAddress = end;
				this->StoredAddress = stored;
				this->AreaName = name;
			}
			ChecksumArea::ChecksumArea()
			{
			}
			String* ToString()
			{
				return new String(CURRENT_TYPE);
			}
		};
		private:
			DELEGATE(void, Array<char>*) SetBytesCallback;
		private:
			DELEGATE(void, String*) SetTextCallback;
		private:
			DELEGATE(void, String*, String*, String*, String*, String*, String*, String*, String*, String*, String*, String*, String*) SetECUInfoCallback;
		private:
			DELEGATE(void, char) SetProgressCallback;
		private:
			DELEGATE(void) ClearTextCallback;
		private:
		static String* g_sAppVersion;
		private:
		static MainForm::ECUTYPE g_ECUSelected;
		private:
		static String* g_slogFile;
		private:
		static String* g_sRunDir;
		private:
		static int g_J2534Device;
		private:
		static char BroadcastAddress;
		private:
		static char UnitAddress;
		private:
		static char TesterAddress;
		private:
		static char InterbyteTime;
		private:
		static int binSize;
		private:
		static Array<char>* binBytes;
		private:
		static ushort g_LastCanTxId;
		private:
		static ushort g_ecu_CanTx;
		private:
		static ushort g_ecu_CanRx;
		private:
			Array<char>* aKLineMsgTransferDataDataByCommonId1;
		private:
			Array<char>* aKLineMsgTransferDataDataByCommonId2;
		private:
			Array<char>* aKLineMsgAccessTimingParameters2;
		private:
			Array<char>* aKLineMsgRequestDownload;
		private:
			Array<char>* aKLineMsgStartRoutineByLocalId3;
		private:
			Array<char>* aCANMsgWriteDataByCommonId1;
		private:
			Array<char>* aCANMsgWriteDataByCommonId2;
		private:
			Array<char>* aCANMsgStartRoutineByLocalId1;
		private:
		static String* g_sErrorMessage;
		private:
			Array<char>* g_Data;
		private:
		static Dictionary_T<String, String>* ECUPartNumDict;
		private:
			IEnumerable_T<APIInfo>* devices_installed;
		private:
			BackgroundWorker* backgroundWorkerWriteKLine;
		private:
			BackgroundWorker* backgroundWorkerWriteCAN;
		public:
		static API* API;
		public:
		static Device* Device;
		public:
		static Channel* Channel;
		private:
			Array<MainForm::ChecksumArea>* checksumAreas;
		private:
			IContainer* components;
		private:
			Label* label1;
		private:
			ComboBox* comboBox1;
		private:
			GroupBox* groupBox1;
		private:
			TextBox* textBox1;
		private:
			Button* btnWriteFlash;
		private:
			ProgressBar* progressBar1;
		private:
			Button* btnLoad;
		private:
			GroupBox* groupBox3;
		private:
			Label* label2;
		private:
			ComboBox* comboBox2;
		private:
			Button* btnECUinfo;
		private:
			PictureBox* pictureBox1;
		private:
			TextBox* tbFilelocation;
		private:
			GroupBox* gBoxFile;
		private:
			Button* btnReadFlash;
		private:
			MenuStrip* menuStrip1;
		private:
			ToolStripMenuItem* diagnosticToolStripMenuItem;
		private:
			ToolStripMenuItem* parameterToolStripMenuItem;
		private:
			ToolStripMenuItem* readDTCToolStripMenuItem;
		private:
			ToolStripMenuItem* actuatorTestToolStripMenuItem;
		private:
			ToolStripMenuItem* specialFunctionToolStripMenuItem;
		private:
			ToolStripMenuItem* writeVINPartNumberToolStripMenuItem;
		private:
			GroupBox* Log;
		private:
			TextBox* txtLog;
		private:
			Button* btnReadEEPROM;
		private:
			ToolStripMenuItem* moduleReplacemetToolStripMenuItem;
		public:
			MainForm();
		private:
			void SetText(String* text);
		private:
			void SetECUInfo(String* text1, String* text2, String* text3, String* text4, String* text5, String* text6, String* text7, String* text8, String* text9, String* text10, String* text11, String* text12);
		private:
			void SetProgress(char progress);
		private:
			void ClearText();
		private:
			void loadBytesFromFile(Object* sender, EventArgs* e);
		private:
			void clearBytes(Object* sender, EventArgs* e);
		private:
			void Form1_Load(Object* sender, EventArgs* e);
		public:
		static Array<char>* StringToByteArray(String* hex);
		public:
		static String* ByteArrayToString(Array<char>* ba, int nLength, String* strSpace);
		public:
		static String* ByteArrayToDecimalString(Array<char>* ba, int nLength, String* strSpace);
		public:
		static String* ByteArrayToDecimalStringAll(Array<char>* ba, int nLength);
		public:
		static bool sendRequestCAN(ushort CanTxId, Array<char>* aCanMsg, MainForm::Iso15765Recv* iso15765Obj, int uTryCount = 1);
		public:
		static bool sendRequestCANWaitEndless(ushort CanTxId, Array<char>* aCanMsg, MainForm::Iso15765Recv* iso15765Obj);
		private:
		static bool sendRequestKLine(Array<char>* aMsg, MainForm::Iso14230RecvObj* iso14230Obj, bool bBroadCast = false);
		private:
		static bool sendRequestKLineWaitEndless(char UnitAddr, Array<char>* aMsg, MainForm::Iso14230RecvObj* iso14230Obj, bool bBroadCast = false);
		private:
			bool SecurityAccess1(Array<char>* aSeed, Array<char>* aF1F4, Array<char>* aKey);
		private:
			bool SecurityAccess2(Array<char>* aSeed, Array<char>* aF1F4, Array<char>* aKey);
		private:
			void harleySecurityCalcCore(char leave, Array<uint>* ret, Array<uint>* flag, uint status);
		private:
			void harley_calc_access_key_1(Array<char>* aSeed, Array<char>* aKey);
		private:
			bool GenerateKeyTC265(Array<char>* receive, Array<char>* send);
		private:
			void FLTRK_JSA(Array<ushort>* a1, Array<char>* a2);
		private:
			void FLTRK_JSB(uint& a1, Array<char>* a2, Array<char>* a3);
		private:
		static bool StartIso14230(uint BaudRate, ConnectFlag connectFlagParam);
		private:
		static bool SetParamsIso14230(char testerAddr, char interbyte, uint BaudRate = 10400u);
		private:
		static bool SetParamsIso9141(char testerAddr, char interbyte, uint BaudRate = 10400u);
		private:
		static bool SendRawKline(Array<char>* Data);
		private:
		static bool WakeupIso14230(char UnitAddress, bool bBroadcast, bool bAutodetect);
		private:
		static bool SendIso14230(Array<char>* Data, bool bBroadCast = false, bool bUseAdditionalLenByte = false);
		private:
		static bool RecvRawKlineMsg(Array<char>* KlineMsg, int nBytesToReceive);
		private:
		static bool RecvIso14230(MainForm::Iso14230RecvObj* iso14230RecvObj);
		private:
		static bool StartIso14230Old(uint BaudRate);
		private:
		static bool SetParamsIso14230Old(char testerAddr, char interbyte, uint BaudRate = 10400u);
		private:
			bool ConnectToUnitCAN();
		private:
		static bool ConnectToUnitnew(bool bBroadcast);
		private:
		static bool ConnectToUnitold(bool bBroadcast, bool bUseRawInit);
		private:
			void ReadECUInfo();
		private:
			bool ReadECUInfoCANBUS();
		private:
			void ReadECUInfoCAN();
		private:
			bool CANWriteFlashXEP768(BackgroundWorker* worker, DoWorkEventArgs* e);
		private:
			bool CANWriteFlashTC265D(BackgroundWorker* worker, DoWorkEventArgs* e);
		private:
			bool SaveDump(Array<char>* Bytes, String* strFileName);
		private:
			void SelectComboBoxItem(String* itemText);
		private:
			void GetFlashTypeFromBinSize();
		private:
			bool VPWJ(BackgroundWorker* worker, DoWorkEventArgs* e);
		private:
			bool KLineWriteProcess(BackgroundWorker* worker, DoWorkEventArgs* e);
		private:
			bool CANWriteProcess(BackgroundWorker* worker, DoWorkEventArgs* e);
		private:
			void backgroundWorker_DoWorkWriteCAN(Object* sender, DoWorkEventArgs* e);
		private:
			void backgroundWorker_DoWorkWriteCANCompleted(Object* sender, RunWorkerCompletedEventArgs* e);
		private:
			void backgroundWorker_DoWorkWriteKLine(Object* sender, DoWorkEventArgs* e);
		private:
			void backgroundWorker_DoWorkWriteKLineCompleted(Object* sender, RunWorkerCompletedEventArgs* e);
		private:
			void comboBox1_SelectedIndexChanged(Object* sender, EventArgs* e);
		private:
			void btnWriteFlash_Click(Object* sender, EventArgs* e);
		private:
			uint CalculateCRC32(Array<char>* data, long startAddress, long endAddress);
		private:
			ushort Get16SUM(int startPos, int endPos);
		private:
			bool FixCRC();
		private:
			bool OpenJ2534Device();
		private:
			void btnLoad_Click(Object* sender, EventArgs* e);
		private:
			void comboBox2_SelectedIndexChanged(Object* sender, EventArgs* e);
		private:
			void btnECUinfo_Click(Object* sender, EventArgs* e);
		private:
			void groupBox1_Enter(Object* sender, EventArgs* e);
		private:
			bool HDXEP768READE2P();
		private:
			bool HDTC265DREADE2P();
		private:
			bool HDTC265DREAD();
		private:
			bool HDXEP768READ();
		private:
			void btnReadFlash_Click(Object* sender, EventArgs* e);
		private:
			void btnReadEEPROM_Click(Object* sender, EventArgs* e);
		private:
			void writePartNumberVinXEP768(String* PartNumber, String* VIN, String* ASPN);
		private:
			void writePartNumberVinTC265D(String* PartNumber, String* VIN, String* ASPN, String* SWCONFIG);
		private:
			uint ReadBigEndianUInt32(Array<char>* data, int index);
		private:
			void WriteBigEndianUInt32(Array<char>* data, int index, uint value);
		private:
			void moduleConfigToolStripMenuItem_Click(Object* sender, EventArgs* e);
		private:
			void writeVINPartNumberToolStripMenuItem_Click(Object* sender, EventArgs* e);
		private:
			void aCallDeleteFile();
		private:
			void aCallCanSATC265();
		private:
			void aCallCanKeepAlive();
		private:
			void aCallCanClearDTC();
		private:
			void aCallCanStartDiag01();
		private:
			void aCallCanStartDiag02();
		private:
			void aCallCanStartDiag03();
		private:
			void aCallCanReadData22F1F4();
		private:
			void aCallCanReadData22F1EC();
		private:
			void aCallCanWriteKernelTC265();
		private:
			void moduleReplacemetToolStripMenuItem_Click(Object* sender, EventArgs* e);
		public:
		virtual void Dispose(bool disposing);
		private:
			void InitializeComponent();
		static:
			MainForm();
	};
}
