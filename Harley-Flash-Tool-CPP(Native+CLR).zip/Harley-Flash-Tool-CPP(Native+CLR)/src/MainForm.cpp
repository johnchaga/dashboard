#include "MainForm.h"
namespace Harley_FlashTool {
	//Delegate declaration moved to header file
	//Delegate declaration moved to header file
	//Delegate declaration moved to header file
	//Delegate declaration moved to header file
	//Delegate declaration moved to header file
	String* MainForm::g_sAppVersion = new String("2.29.9");
	MainForm::ECUTYPE MainForm::g_ECUSelected = MainForm::ECUTYPE::unknown;
	String* MainForm::g_slogFile;
	String* MainForm::g_sRunDir = Path::GetDirectoryName(Assembly::GetExecutingAssembly()->Location);
	int MainForm::g_J2534Device = 0;
	char MainForm::BroadcastAddress = 51;
	char MainForm::UnitAddress = 16;
	char MainForm::TesterAddress = 240;
	char MainForm::InterbyteTime = 0;
	int MainForm::binSize;
	Array<char>* MainForm::binBytes;
	ushort MainForm::g_LastCanTxId = 0;
	ushort MainForm::g_ecu_CanTx = 0;
	ushort MainForm::g_ecu_CanRx = 0;
	String* MainForm::g_sErrorMessage = new String("FAILED!");
	Dictionary_T<String, String>* MainForm::ECUPartNumDict;
	API* MainForm::API;
	Device* MainForm::Device;
	Channel* MainForm::Channel;
	MainForm::MainForm(){
		g_Data = null;
		aCANMsgStartRoutineByLocalId1 = null;
		aCANMsgWriteDataByCommonId2 = null;
		aCANMsgWriteDataByCommonId1 = null;
		Array<MainForm::ChecksumArea>* expr_23 = new Array<MainForm::ChecksumArea>(3);
		expr_23->SetData(0, new MainForm::ChecksumArea(0L, 81851L, 81852L, new String("Checksum #1")));
		expr_23->SetData(1, new MainForm::ChecksumArea(655360L, 786363L, 786364L, new String("Checksum #2")));
		expr_23->SetData(2, new MainForm::ChecksumArea(786432L, 2621371L, 2621372L, new String("Checksum #3")));
		this->checksumAreas = expr_23;
		this->components = null;
		Form::.ctor();
		this->InitializeComponent();
		this->backgroundWorkerWriteKLine = new BackgroundWorker();
		this->backgroundWorkerWriteKLine->WorkerSupportsCancellation = true;
		this->backgroundWorkerWriteKLine->DoWork += *(new DoWorkEventHandler(this->backgroundWorker_DoWorkWriteKLine));
		this->backgroundWorkerWriteKLine->RunWorkerCompleted += *(new RunWorkerCompletedEventHandler(this->backgroundWorker_DoWorkWriteKLineCompleted));
		this->backgroundWorkerWriteCAN = new BackgroundWorker();
		this->backgroundWorkerWriteCAN->WorkerSupportsCancellation = true;
		this->backgroundWorkerWriteCAN->DoWork += *(new DoWorkEventHandler(this->backgroundWorker_DoWorkWriteCAN));
		this->backgroundWorkerWriteCAN->RunWorkerCompleted += *(new RunWorkerCompletedEventHandler(this->backgroundWorker_DoWorkWriteCANCompleted));
	}
	void MainForm::SetText(String* text)
	{
		bool invokeRequired = this->textBox1->InvokeRequired;
		if (invokeRequired) {
			MainForm::SetTextCallback* setTextCallback = new MainForm::SetTextCallback(DELEGATE_FUNC(MainForm::SetText, _1));
			Delegate* arg_2A_1 = *setTextCallback;
			Array<Object>* expr_26 = new Array<Object>(1);
			expr_26->SetData(0, text);
			Form::Invoke(arg_2A_1, expr_26);
		}
		else {
			this->textBox1->Text = text;
		}
	}
	void MainForm::SetECUInfo(String* text1, String* text2, String* text3, String* text4, String* text5, String* text6, String* text7, String* text8, String* text9, String* text10, String* text11, String* text12)
	{
		bool invokeRequired = this->textBox1->InvokeRequired;
		if (invokeRequired) {
			MainForm::SetECUInfoCallback* setECUInfoCallback = new MainForm::SetECUInfoCallback(DELEGATE_FUNC(MainForm::SetECUInfo, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12));
			Delegate* arg_63_1 = *setECUInfoCallback;
			Array<Object>* expr_27 = new Array<Object>(12);
			expr_27->SetData(0, text1);
			expr_27->SetData(1, text2);
			expr_27->SetData(2, text3);
			expr_27->SetData(3, text4);
			expr_27->SetData(4, text5);
			expr_27->SetData(5, text6);
			expr_27->SetData(6, text7);
			expr_27->SetData(7, text8);
			expr_27->SetData(8, text9);
			expr_27->SetData(9, text10);
			expr_27->SetData(10, text11);
			expr_27->SetData(11, text12);
			Form::Invoke(arg_63_1, expr_27);
		}
		else {
			this->txtLog->Clear();
			this-><SetECUInfo>g__AppendLog|42_0(new String("S/W Configuration : "), text1);
			this-><SetECUInfo>g__AppendLog|42_0(new String("Module Configuration : "), text2);
			this-><SetECUInfo>g__AppendLog|42_0(new String("Hardware Part Number : "), text3);
			this-><SetECUInfo>g__AppendLog|42_0(new String("Assembly Part Number : "), text7);
			this-><SetECUInfo>g__AppendLog|42_0(new String("Calibration ID P/N : "), text4);
			this-><SetECUInfo>g__AppendLog|42_0(new String("Homologation ID : "), text9);
			this-><SetECUInfo>g__AppendLog|42_0(new String("VIN ECU Number : "), text6);
			this-><SetECUInfo>g__AppendLog|42_0(new String("Reprogram Date : "), text8);
			this-><SetECUInfo>g__AppendLog|42_0(new String("Boot S/W Version : "), text10);
			this-><SetECUInfo>g__AppendLog|42_0(new String("Calibration Version : "), text11);
			this-><SetECUInfo>g__AppendLog|42_0(new String("Application Version : "), text5);
			this-><SetECUInfo>g__AppendLog|42_0(new String("Odometer ECU : "), text12);
		}
	}
	void MainForm::SetProgress(char progress)
	{
		bool invokeRequired = this->progressBar1->InvokeRequired;
		if (invokeRequired) {
			MainForm::SetProgressCallback* setProgressCallback = new MainForm::SetProgressCallback(DELEGATE_FUNC(MainForm::SetProgress, _1));
			Delegate* arg_2F_1 = *setProgressCallback;
			Array<Object>* expr_26 = new Array<Object>(1);
			expr_26->SetData(0, BOX<char>(progress));
			Form::Invoke(arg_2F_1, expr_26);
		}
		else {
			bool flag = (progress > 0) && (progress <= 100);
			if (flag) {
				this->progressBar1->Value = (int)(progress);
			}
		}
	}
	void MainForm::ClearText()
	{
		bool invokeRequired = this->textBox1->InvokeRequired;
		if (invokeRequired) {
			MainForm::ClearTextCallback* method = new MainForm::ClearTextCallback(DELEGATE_FUNC(MainForm::ClearText));
			Form::Invoke(method, new Array<Object>(0));
		}
		else {
			this->textBox1->Text = new String("");
		}
	}
	void MainForm::loadBytesFromFile(Object* sender, EventArgs* e)
	{
		OpenFileDialog* openFileDialog = new OpenFileDialog();
		bool flag = openFileDialog->ShowDialog() != DialogResult::OK;
		if (flag) {
		}
	}
	void MainForm::clearBytes(Object* sender, EventArgs* e)
	{
	}
	void MainForm::Form1_Load(Object* sender, EventArgs* e)
	{
		MainForm::g_J2534Device = 4;
		MainForm::g_ECUSelected = MainForm::ECUTYPE::unknown;
		this->progressBar1->Visible = false;
		this->progressBar1->Minimum = 1;
		this->progressBar1->Maximum = 100;
		this->progressBar1->Value = 1;
		this->progressBar1->Step = 1;
		this->comboBox1->Items->Clear();
		this->comboBox2->Items->Clear();
		this->btnWriteFlash->Enabled = false;
		this->btnLoad->Enabled = true;
		this->tbFilelocation->Enabled = true;
		Array<char>* array = Enumerable::Repeat<char>(0, 256)->ToArray<char>();
		Array<String>* expr_B1 = new Array<String>(1);
		expr_B1->SetData(0, ((*(MainForm::g_sRunDir) + *(new String("\\Log_"))) + DateTime::getNow()->ToString(new String("MM_dd_yyyy_HH_mm_ss"))) + *(new String(".log")));
		MainForm::g_slogFile = Path::Combine(expr_B1);
		try {
			/*ERROR: Cannot translate: System.NotImplementedException: The method or operation is not implemented.. Node: ICSharpCode.NRefactory.CSharp.UsingStatement*/;
		}
		catch (Exception* ex) {
			Console::WriteLine(ex->Message);
		}
		bool flag3 = this->comboBox1->Items->Count < 1;
		if (flag3) {
			this->textBox1->Text = new String("No j2534 Pass-Thru Device available !!!");
			this->comboBox1->Enabled = false;
		}
		this-><Form1_Load>g__AddComboboxItem|49_0(new String("MC9S12DJ128_128kb_VPW"), 0);
		this-><Form1_Load>g__AddComboboxItem|49_0(new String("MC9S12XEP768_768kb_CAN"), 1);
		this-><Form1_Load>g__AddComboboxItem|49_0(new String("TC265_MT21M_2560kb_CAN"), 2);
		this->comboBox2->Enabled = true;
		this->comboBox2->SelectedText = new String("");
		this->comboBox2->Text = new String("Select Flash Memory");
		MainForm::g_ECUSelected = MainForm::ECUTYPE::unknown;
		this->Text = *(new String("HD ECU FlashTool  v")) + *(MainForm::g_sAppVersion);
	}
	Array<char>* MainForm::StringToByteArray(String* hex)
	{
		hex = hex->Replace(new String(" "), new String(""));
		int num = hex->getLength() / 2;
		Array<char>* array = new Array<char>(num);
		for (int i = 0; i < num; i += 1) {
			array->SetData(i, Convert::ToByte(hex->Substring(i * 2, 2), 16));
		}
		return array;
	}
	String* MainForm::ByteArrayToString(Array<char>* ba, int nLength, String* strSpace)
	{
		bool flag = nLength > ba->Length;
		if (flag) {
			nLength = ba->Length;
		}
		StringBuilder* stringBuilder = new StringBuilder(nLength * 2);
		for (int i = 0; i < nLength; i += 1) {
			stringBuilder->AppendFormat(*(new String("{0:X2}")) + *strSpace, BOX<char>(ba->GetData(i)));
		}
		return stringBuilder->ToString();
	}
	String* MainForm::ByteArrayToDecimalString(Array<char>* ba, int nLength, String* strSpace)
	{
		bool flag = nLength > ba->Length;
		if (flag) {
			nLength = ba->Length;
		}
		StringBuilder* stringBuilder = new StringBuilder(nLength * 4);
		for (int i = 0; i < nLength; i += 1) {
			stringBuilder->AppendFormat(*(new String("{0:D}")) + *strSpace, BOX<char>(ba->GetData(i)));
		}
		return stringBuilder->ToString();
	}
	String* MainForm::ByteArrayToDecimalStringAll(Array<char>* ba, int nLength)
	{
		bool flag = nLength > ba->Length;
		if (flag) {
			nLength = ba->Length;
		}
		ulong num = 0uL;
		for (int i = 0; i < nLength; i += 1) {
			num = (num << 8) | (ulong)(ba->GetData(i));
		}
		return num->ToString();
	}
	bool MainForm::sendRequestCAN(ushort CanTxId, Array<char>* aCanMsg, MainForm::Iso15765Recv* iso15765Obj, int uTryCount)
	{
		bool result;
		try {
			bool flag = ((MainForm::API == null) || (MainForm::Device == null)) || (MainForm::Channel == null);
			if (flag) {
				MainForm::g_sErrorMessage = new String("Interface error!");
				result = false;
				return result;
			}
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			bool flag2 = MainForm::g_LastCanTxId != CanTxId;
			if (flag2) {
				MainForm::g_LastCanTxId = CanTxId;
				MessageFilter* messageFilter = new MessageFilter();
				messageFilter->FilterType = Filter::FLOW_CONTROL_FILTER;
				MessageFilter* arg_77_0 = messageFilter;
				Array<char>* expr_6C = new Array<char>(4);
				RuntimeHelpers::InitializeArray(expr_6C, fieldof(<PrivateImplementationDetails>::AD95131BC0B799C0B1AF477FB14FCF26A6A9F76079E48BF090ACB7E8367BFD0E)->FieldHandle);
				arg_77_0->Mask = expr_6C;
				MessageFilter* arg_C8_0 = messageFilter;
				Array<char>* expr_84 = new Array<char>(4);
				expr_84->SetData(0, (char)((MainForm::g_ecu_CanRx >> 24) & 255));
				expr_84->SetData(1, (char)((MainForm::g_ecu_CanRx >> 16) & 255));
				expr_84->SetData(2, (char)((MainForm::g_ecu_CanRx >> 8) & 255));
				expr_84->SetData(3, (char)(MainForm::g_ecu_CanRx & 255));
				arg_C8_0->Pattern = expr_84;
				MessageFilter* arg_109_0 = messageFilter;
				Array<char>* expr_D5 = new Array<char>(4);
				expr_D5->SetData(0, (char)((CanTxId >> 24) & 255));
				expr_D5->SetData(1, (char)((CanTxId >> 16) & 255));
				expr_D5->SetData(2, (char)((CanTxId >> 8) & 255));
				expr_D5->SetData(3, (char)(CanTxId & 255));
				arg_109_0->FlowControl = expr_D5;
				MessageFilter* messageFilter2 = messageFilter;
				messageFilter2->TxFlags = TxFlag::ISO15765_FRAME_PAD;
				MainForm::Channel->StartMsgFilter(messageFilter2);
			}
			Array<char>* array = new Array<char>(4 + aCanMsg->Length);
			array->SetData(0, (char)((CanTxId >> 24) & 255));
			array->SetData(1, (char)((CanTxId >> 16) & 255));
			array->SetData(2, (char)((CanTxId >> 8) & 255));
			array->SetData(3, (char)(CanTxId & 255));
			Array::Copy(aCanMsg, 0, array, 4, aCanMsg->Length);
			while (true) {
				MainForm::Channel->ClearRxBuffer();
				String* str = (*(new String("Tx: ")) + CanTxId->ToString(new String("X3"))) + *(new String("     "));
				*str += MainForm::ByteArrayToString(aCanMsg, aCanMsg->Length, new String(" "));
				MainForm::Channel->SendMessage(array);
				do {
					int num4 = 0;
					bool flag3 = false;
					do {
						GetMessageResults* message = MainForm::Channel->GetMessage();
						bool flag4 = message->Result == ResultCode::STATUS_NOERROR;
						if (flag4) {
							SAE::J2534::Message* message2 = message->Messages->First<SAE::J2534::Message*>();
							num = message2->Data->Length - 4;
							bool flag5 = num > 0;
							if (flag5) {
								iso15765Obj->sete2_CanRxId(((((uint)(message2->Data->GetData(0)) * 16777216u) + ((uint)(message2->Data->GetData(1)) * 65536u)) + ((uint)(message2->Data->GetData(2)) * 256u)) + (uint)(message2->Data->GetData(3)));
								iso15765Obj->sete1_Timestamp(message2->Timestamp);
								iso15765Obj->sete3_DiagAddr(0);
								iso15765Obj->sete4_Data(new Array<char>(num));
								Array::Copy(message2->Data, 4, iso15765Obj->gete4_Data(), 0, num);
								String* str2 = (*(new String("Rx: ")) + new String(iso15765Obj->gete2_CanRxId())) + *(new String("     "));
								for (int i = 0; i < iso15765Obj->gete4_Data()->Length; i += 1) {
									str2 = (*str2 + iso15765Obj->gete4_Data()->GetData(i)->ToString(new String("X2"))) + *(new String(" "));
								}
								bool flag6 = ((num != 3) || (iso15765Obj->gete4_Data()->GetData(0) != 127)) || (iso15765Obj->gete4_Data()->GetData(2) != 120);
								if (flag6) {
									flag3 = true;
								}
								else {
									num2 = 0;
								}
							}
						}
						else {
							bool flag7 = message->Result == ResultCode::BUFFER_EMPTY;
							if (flag7) {
								num4 += 1;
								Console::WriteLine(*(new String(" Recv FAILED Response.Result = ")) + message->Result->ToString());
							}
						}
					}
					while (!flag3 && (num4 < 2));
					bool flag8 = flag3;
					if (flag8) {
						goto Block_15;
					}
				}
				while (num2++ < uTryCount);
				IL_407:
				if (num3++ >= uTryCount) {
					goto Block_19;
				}
				continue;
				Block_15:
				bool flag9 = iso15765Obj->gete4_Data()->GetData(0) == (*(aCanMsg->GetData(0)) + 64);
				if (flag9) {
					break;
				}
				bool flag10 = (iso15765Obj->gete4_Data()->GetData(0) == 127) && (iso15765Obj->gete4_Data()->GetData(0) != 120);
				if (flag10) {
					goto Block_18;
				}
				bool flag11 = num > 2;
				if (flag11) {
				}
				goto IL_407;
			}
			result = true;
			return result;
			Block_18:
			result = true;
			return result;
			Block_19:;
		}
		catch (Exception* ex) {
			Console::WriteLine(ex->Message);
			MainForm::g_sErrorMessage = new String("Interface error!");
		}
		result = false;
		return result;
	}
	bool MainForm::sendRequestCANWaitEndless(ushort CanTxId, Array<char>* aCanMsg, MainForm::Iso15765Recv* iso15765Obj)
	{
		bool result;
		try {
			bool flag = ((MainForm::API == null) || (MainForm::Device == null)) || (MainForm::Channel == null);
			if (flag) {
				MessageBox::Show(new String("Interface error !"), new String("Notice"), MessageBoxButtons::OK, MessageBoxIcon::Asterisk);
				result = false;
				return result;
			}
			int tickCount = Environment::TickCount;
			bool flag2 = false;
			bool flag3 = MainForm::g_LastCanTxId != CanTxId;
			if (flag3) {
				MainForm::g_LastCanTxId = CanTxId;
				MessageFilter* messageFilter = new MessageFilter();
				messageFilter->FilterType = Filter::FLOW_CONTROL_FILTER;
				MessageFilter* arg_84_0 = messageFilter;
				Array<char>* expr_79 = new Array<char>(4);
				RuntimeHelpers::InitializeArray(expr_79, fieldof(<PrivateImplementationDetails>::AD95131BC0B799C0B1AF477FB14FCF26A6A9F76079E48BF090ACB7E8367BFD0E)->FieldHandle);
				arg_84_0->Mask = expr_79;
				MessageFilter* arg_D5_0 = messageFilter;
				Array<char>* expr_91 = new Array<char>(4);
				expr_91->SetData(0, (char)((MainForm::g_ecu_CanRx >> 24) & 255));
				expr_91->SetData(1, (char)((MainForm::g_ecu_CanRx >> 16) & 255));
				expr_91->SetData(2, (char)((MainForm::g_ecu_CanRx >> 8) & 255));
				expr_91->SetData(3, (char)(MainForm::g_ecu_CanRx & 255));
				arg_D5_0->Pattern = expr_91;
				MessageFilter* arg_116_0 = messageFilter;
				Array<char>* expr_E2 = new Array<char>(4);
				expr_E2->SetData(0, (char)((CanTxId >> 24) & 255));
				expr_E2->SetData(1, (char)((CanTxId >> 16) & 255));
				expr_E2->SetData(2, (char)((CanTxId >> 8) & 255));
				expr_E2->SetData(3, (char)(CanTxId & 255));
				arg_116_0->FlowControl = expr_E2;
				MessageFilter* messageFilter2 = messageFilter;
				messageFilter2->TxFlags = TxFlag::ISO15765_FRAME_PAD;
				MainForm::Channel->StartMsgFilter(messageFilter2);
			}
			Array<char>* array = new Array<char>(4 + aCanMsg->Length);
			array->SetData(0, (char)((CanTxId >> 24) & 255));
			array->SetData(1, (char)((CanTxId >> 16) & 255));
			array->SetData(2, (char)((CanTxId >> 8) & 255));
			array->SetData(3, (char)(CanTxId & 255));
			Array::Copy(aCanMsg, 0, array, 4, aCanMsg->Length);
			while (true) {
				MainForm::Channel->ClearRxBuffer();
				MainForm::Channel->SendMessage(array);
				do {
					int num = 0;
					do {
						GetMessageResults* message = MainForm::Channel->GetMessage();
						bool flag4 = message->Result == ResultCode::STATUS_NOERROR;
						if (flag4) {
							SAE::J2534::Message* message2 = message->Messages->First<SAE::J2534::Message*>();
							int num2 = message2->Data->Length - 4;
							bool flag5 = num2 > 0;
							if (flag5) {
								iso15765Obj->sete2_CanRxId(((((uint)(message2->Data->GetData(0)) * 16777216u) + ((uint)(message2->Data->GetData(1)) * 65536u)) + ((uint)(message2->Data->GetData(2)) * 256u)) + (uint)(message2->Data->GetData(3)));
								iso15765Obj->sete1_Timestamp(message2->Timestamp);
								iso15765Obj->sete3_DiagAddr(0);
								iso15765Obj->sete4_Data(new Array<char>(num2));
								Array::Copy(message2->Data, 4, iso15765Obj->gete4_Data(), 0, num2);
								bool flag6 = ((num2 != 3) || (iso15765Obj->gete4_Data()->GetData(0) != 127)) || (iso15765Obj->gete4_Data()->GetData(2) != 120);
								if (flag6) {
									flag2 = true;
								}
								else {
									tickCount = Environment::TickCount;
								}
							}
						}
						else {
							bool flag7 = message->Result == ResultCode::BUFFER_EMPTY;
							if (flag7) {
								num += 1;
							}
						}
					}
					while (!flag2 && (num < 2));
					bool flag8 = flag2;
					if (flag8) {
						bool flag9 = iso15765Obj->gete4_Data()->GetData(0) == (*(aCanMsg->GetData(0)) + 64);
						if (flag9) {
							goto Block_15;
						}
					}
					else {
						Thread::Sleep(20);
					}
				}
				while ((Environment::TickCount - tickCount) <= 10000);
				if (flag2) {
					goto Block_17;
				}
			}
			Block_15:
			result = true;
			return result;
			Block_17:;
		}
		catch (Exception* ex) {
			Console::WriteLine(ex->Message);
			MainForm::g_sErrorMessage = new String("Interface error!");
		}
		result = false;
		return result;
	}
	bool MainForm::sendRequestKLine(Array<char>* aMsg, MainForm::Iso14230RecvObj* iso14230Obj, bool bBroadCast)
	{
		Array<char>* array = new Array<char>(2 + aMsg->Length);
		array->SetData(0, MainForm::TesterAddress);
		array->SetData(1, bBroadCast ? MainForm::BroadcastAddress : MainForm::UnitAddress);
		Array::Copy(aMsg, 0, array, 2, aMsg->Length);
		bool flag = !MainForm::SendIso14230(array, bBroadCast, false);
		bool result;
		if (flag) {
			result = false;
		}
		else {
			Thread::Sleep(50);
			bool flag2 = !MainForm::RecvIso14230(iso14230Obj);
			result = !flag2;
		}
		return result;
	}
	bool MainForm::sendRequestKLineWaitEndless(char UnitAddr, Array<char>* aMsg, MainForm::Iso14230RecvObj* iso14230Obj, bool bBroadCast)
	{
		bool flag = false;
		int tickCount = Environment::TickCount;
		Array<char>* array = new Array<char>(2 + aMsg->Length);
		array->SetData(0, MainForm::TesterAddress);
		array->SetData(1, bBroadCast ? MainForm::BroadcastAddress : MainForm::UnitAddress);
		Array::Copy(aMsg, 0, array, 2, aMsg->Length);
		bool flag2 = !MainForm::SendIso14230(array, bBroadCast, false);
		bool result;
		if (flag2) {
			result = false;
		}
		else {
			Thread::Sleep(50);
			while (true) {
				tickCount = Environment::TickCount;
				bool flag3 = MainForm::RecvIso14230(iso14230Obj);
				if (flag3) {
					bool flag4 = ((iso14230Obj->gete4_Data()->Length > 2) && (iso14230Obj->gete4_Data()->GetData(0) == 127)) && (iso14230Obj->gete4_Data()->GetData(2) == 120);
					if (!flag4) {
						break;
					}
				}
				Thread::Sleep(20);
				if ((Environment::TickCount - tickCount) > 10000) {
					goto IL_CF;
				}
			}
			flag = true;
			IL_CF:
			result = flag;
		}
		return result;
	}
	bool MainForm::SecurityAccess1(Array<char>* aSeed, Array<char>* aF1F4, Array<char>* aKey)
	{
		int num = ((int)(aSeed->GetData(0)) * 256) + (int)(aSeed->GetData(1));
		num *= 2;
		Array::Copy(ConstData::KeysArray1, num, aKey, 0, 2);
		aF1F4->SetData(1, *(aF1F4->GetData(1)) & 74);
		aKey->SetData(1, *(aKey->GetData(1)) ^ *(aF1F4->GetData(1)));
		return true;
	}
	bool MainForm::SecurityAccess2(Array<char>* aSeed, Array<char>* aF1F4, Array<char>* aKey)
	{
		int num = ((int)(aSeed->GetData(0)) * 256) + (int)(aSeed->GetData(1));
		num *= 2;
		Array::Copy(ConstData::KeysArray2, num, aKey, 0, 2);
		aF1F4->SetData(1, *(aF1F4->GetData(1)) & 74);
		aKey->SetData(1, *(aKey->GetData(1)) ^ *(aF1F4->GetData(1)));
		return true;
	}
	void MainForm::harleySecurityCalcCore(char leave, Array<uint>* ret, Array<uint>* flag, uint status)
	{
		uint num = ret->GetData(0);
		uint num2 = ret->GetData(1);
		uint num3 = status * (uint)(leave);
		for (char b = 0; b < leave; b += 1) {
			uint num4 = num3 + *(flag->GetData((int)((num3 >> 11) & 3u)));
			num3 -= status;
			num2 -= num4 ^ (num + ((num >> 5) ^ (16u * num)));
			num -= (num3 + *(flag->GetData((int)(num3 & 3u)))) ^ (num2 + ((num2 >> 5) ^ (16u * num2)));
		}
		ret->SetData(0, num);
		ret->SetData(1, num2);
	}
	void MainForm::harley_calc_access_key_1(Array<char>* aSeed, Array<char>* aKey)
	{
		Array<uint>* expr_07 = new Array<uint>(4);
		RuntimeHelpers::InitializeArray(expr_07, fieldof(<PrivateImplementationDetails>::47E7B9A8D72494C56997CD6D98674AFA7263EBCAAECA2600345574CB8594EB88)->FieldHandle);
		Array<uint>* array = expr_07;
		Array<char>* array2 = new Array<char>(8);
		Array<uint>* array3 = new Array<uint>(2);
		ushort num = (ushort)(((int)(aSeed->GetData(0)) << 8) | (int)(aSeed->GetData(1)));
		Array::Copy(ConstData::KeysArray2, (int)(8 * num), array2, 0, array2->Length);
		array3->SetData(0, ((((uint)(array2->GetData(3)) * 16777216u) + ((uint)(array2->GetData(2)) * 65536u)) + ((uint)(array2->GetData(1)) * 256u)) + (uint)(array2->GetData(0)));
		array3->SetData(1, ((((uint)(array2->GetData(7)) * 16777216u) + ((uint)(array2->GetData(6)) * 65536u)) + ((uint)(array2->GetData(5)) * 256u)) + (uint)(array2->GetData(4)));
		this->harleySecurityCalcCore(32, array3, array, 4087733900u);
		uint num2 = (*(array3->GetData(0)) & 4294901760u) >> 16;
		aKey->SetData(0, (char)(num2 >> 8));
		aKey->SetData(1, (char)((num2 & 255u) ^ 2u));
	}
	bool MainForm::GenerateKeyTC265(Array<char>* receive, Array<char>* send)
	{
		Array<char>* expr_07 = new Array<char>(8);
		RuntimeHelpers::InitializeArray(expr_07, fieldof(<PrivateImplementationDetails>::6CA1DDE5B19AEF4FE5EFAFBF2E718392990451548601C1669B7F7A780CAAC09E)->FieldHandle);
		Array<char>* a = expr_07;
		Array<char>* expr_1A = new Array<char>(9);
		RuntimeHelpers::InitializeArray(expr_1A, fieldof(<PrivateImplementationDetails>::63A28F7BC3D38D27BABDED1F7DB290BEFC44A71A17A8D0A9DEDFC9F2A2D5FF93)->FieldHandle);
		Array<char>* a2 = expr_1A;
		Array<char>* array = new Array<char>(4);
		Array<char>* array2 = new Array<char>(4);
		uint num = 0u;
		uint num2 = 0u;
		Array::Copy(receive, 0, array, 0, 4);
		Array::Copy(receive, 4, array2, 0, 4);
		this->FLTRK_JSB(num, array, a);
		this->FLTRK_JSB(num2, array2, a2);
		send->SetData(0, (char)(num & 255u));
		send->SetData(1, (char)((num >> 16) & 255u));
		send->SetData(2, (char)((num2 >> 24) & 255u));
		send->SetData(3, (char)((num2 >> 8) & 255u));
		send->SetData(4, (char)((num >> 8) & 255u));
		send->SetData(5, (char)((num2 >> 16) & 255u));
		send->SetData(6, (char)((num >> 24) & 255u));
		send->SetData(7, (char)(num2 & 255u));
		return true;
	}
	void MainForm::FLTRK_JSA(Array<ushort>* a1, Array<char>* a2)
	{
		Array<uint>* array = new Array<uint>(3);
		Array<ushort>* array2 = new Array<ushort>(22);
		uint num = 1u;
		array->SetData(0, (uint)((int)(a2->GetData(2)) | ((int)(a2->GetData(3)) << 8)));
		array->SetData(1, (uint)((int)(a2->GetData(4)) | ((int)(a2->GetData(5)) << 8)));
		array->SetData(2, (uint)((int)(a2->GetData(6)) | ((int)(a2->GetData(7)) << 8)));
		uint num2 = (uint)((int)(a2->GetData(0)) | ((int)(a2->GetData(1)) << 8));
		array2->SetData(0, (ushort)(num2));
		for (int i = 0; i < 21; i += 1) {
			uint num3 = array->GetData(i % 3);
			uint num4 = (uint)(((long)(i) ^ (long)((ulong)(num2 + ((num3 << 9) | (num3 >> 7))))) & 65535L);
			num2 = (num4 ^ ((num2 << 2) | (num2 >> 14))) & 65535u;
			array2->SetData((int)(num++), (ushort)(num2));
			array->SetData(i % 3, num4);
		}
		for (int j = 0; j < 22; j += 1) {
			a1->SetData(j, array2->GetData(j));
		}
	}
	void MainForm::FLTRK_JSB(uint& a1, Array<char>* a2, Array<char>* a3)
	{
		Array<ushort>* array = new Array<ushort>(22);
		this->FLTRK_JSA(array, a3);
		uint num = (uint)(((int)(a2->GetData(0)) << 8) | (int)(a2->GetData(1)));
		uint num2 = (uint)(((int)(a2->GetData(2)) << 8) | (int)(a2->GetData(3)));
		for (int i = 0; i < 22; i += 2) {
			uint num3 = (uint)((ushort)((uint)(array->GetData(i)) ^ (num2 + ((num << 9) | (num >> 7)))));
			uint num4 = (uint)((ushort)(num3 ^ ((num2 << 2) | (num2 >> 14))));
			num = (uint)((ushort)((uint)(array->GetData(i + 1)) ^ (num4 + ((num3 << 9) | (num3 >> 7)))));
			num2 = (uint)((ushort)(num ^ ((num4 << 2) | (num4 >> 14))));
		}
		a1 = (num << 16) + num2;
	}
	bool MainForm::StartIso14230(uint BaudRate, ConnectFlag connectFlagParam)
	{
		bool result;
		try {
			bool flag = MainForm::Channel != null;
			if (flag) {
				MainForm::Channel->ClearRxBuffer();
				MainForm::Channel->ClearTxBuffer();
				MainForm::Channel->ClearPeriodicMsgs();
				MainForm::Channel->Dispose();
			}
			MainForm::Channel = MainForm::Device->GetChannel(Protocol::ISO9141, (Baud)(BaudRate), connectFlagParam, false);
			MainForm::Channel->DefaultRxTimeout = 400;
			MainForm::Channel->DefaultTxTimeout = 400;
		}
		catch (Exception* ex) {
			Console::WriteLine(ex->Message);
			result = false;
			return result;
		}
		result = true;
		return result;
	}
	bool MainForm::SetParamsIso14230(char testerAddr, char interbyte, uint BaudRate)
	{
		bool result;
		try {
			MainForm::TesterAddress = testerAddr;
			MainForm::InterbyteTime = interbyte;
			Array<SConfig>* expr_14 = new Array<SConfig>(6);
			expr_14->SetData(0, new SConfig(Parameter::DATA_RATE, (int)(BaudRate)));
			expr_14->SetData(1, new SConfig(Parameter::TINIL, 25));
			expr_14->SetData(2, new SConfig(Parameter::TWUP, 50));
			expr_14->SetData(3, new SConfig(Parameter::P3_MIN, 0));
			expr_14->SetData(4, new SConfig(Parameter::P4_MIN, 0));
			expr_14->SetData(5, new SConfig(Parameter::P1_MAX, 0));
			Array<SConfig>* config = expr_14;
			MainForm::Channel->SetConfig(config);
			MessageFilter* messageFilter = new MessageFilter();
			messageFilter->PassAll();
			MainForm::Channel->StartMsgFilter(messageFilter);
			result = true;
		}
		catch (Exception* ex) {
			Console::WriteLine( ? ex->Message : *(new String("")));
			result = false;
		}
		return result;
	}
	bool MainForm::SetParamsIso9141(char testerAddr, char interbyte, uint BaudRate)
	{
		bool result;
		try {
			MainForm::TesterAddress = testerAddr;
			MainForm::InterbyteTime = interbyte;
			Array<SConfig>* expr_14 = new Array<SConfig>(6);
			expr_14->SetData(0, new SConfig(Parameter::DATA_RATE, (int)(BaudRate)));
			expr_14->SetData(1, new SConfig(Parameter::TINIL, 25));
			expr_14->SetData(2, new SConfig(Parameter::TWUP, 50));
			expr_14->SetData(3, new SConfig(Parameter::P3_MIN, 0));
			expr_14->SetData(4, new SConfig(Parameter::P4_MIN, 0));
			expr_14->SetData(5, new SConfig(Parameter::P1_MAX, 0));
			Array<SConfig>* config = expr_14;
			MainForm::Channel->SetConfig(config);
			MessageFilter* messageFilter = new MessageFilter();
			messageFilter->PassAll();
			MainForm::Channel->StartMsgFilter(messageFilter);
			result = true;
		}
		catch (Exception* ex) {
			Console::WriteLine( ? ex->Message : *(new String("")));
			result = false;
		}
		return result;
	}
	bool MainForm::SendRawKline(Array<char>* Data)
	{
		bool result;
		try {
			bool flag = Data->Length > 0;
			if (flag) {
				MainForm::Channel->ClearRxBuffer();
				Thread::Sleep(1);
				String* str = new String("Tx: ");
				*str += MainForm::ByteArrayToString(Data, Data->Length, new String(" "));
				MainForm::Channel->SendMessage(Data);
				result = true;
			}
			else {
				result = false;
			}
		}
		catch (Exception* ex) {
			Console::WriteLine( ? ex->Message : *(new String("")));
			result = false;
		}
		return result;
	}
	bool MainForm::WakeupIso14230(char UnitAddress, bool bBroadcast, bool bAutodetect)
	{
		bool result;
		try {
			Array<char>* array = new Array<char>(4);
			array->SetData(0, bBroadcast ? 193 : 129);
			array->SetData(1, bBroadcast ? MainForm::BroadcastAddress : UnitAddress);
			array->SetData(2, MainForm::TesterAddress);
			array->SetData(3, 129);
			SAE::J2534::Message* txMessage = new SAE::J2534::Message(array, TxFlag::NONE);
			String* str = new String("=Tx: ");
			*str += MainForm::ByteArrayToString(*array, *array->Length, new String(" "));
			MainForm::Channel->ClearRxBuffer();
			SAE::J2534::Message* message = MainForm::Channel->FastInit(txMessage);
			bool flag = message != null;
			if (flag) {
				bool flag2 = message->Data->Length > 0;
				if (flag2) {
					String* str2 = new String("J2534 K-line Rx: ");
					*str2 += MainForm::ByteArrayToString(*message->Data, *message->Data->Length, new String(" "));
					result = true;
					return result;
				}
			}
			result = false;
		}
		catch (Exception* ex) {
			Console::WriteLine(ex->Message);
			result = false;
		}
		return result;
	}
	bool MainForm::SendIso14230(Array<char>* Data, bool bBroadCast, bool bUseAdditionalLenByte)
	{
		bool result;
		try {
			bool flag = Data->Length > 1;
			if (flag) {
				MainForm::Channel->ClearRxBuffer();
				Thread::Sleep(1);
				if (bUseAdditionalLenByte) {
					Array<char>* array = new Array<char>(Data->Length + 1);
					array = new Array<char>(Data->Length + 2);
					array->SetData(0, 128);
					array->SetData(3, (char)(Data->Length - 2));
					array->SetData(1, Data->GetData(1));
					array->SetData(2, Data->GetData(0));
					Array::Copy(Data, 2, array, 4, Data->Length - 2);
					String* str = new String("Tx: ");
					*str += MainForm::ByteArrayToString(*array, *array->Length, new String(" "));
					MainForm::Channel->SendMessage(array);
					result = true;
				}
				else {
					Array<char>* array2 = new Array<char>(Data->Length + 1);
					bool flag2 = (Data->Length - 2) > 63;
					if (flag2) {
						array2 = new Array<char>(Data->Length + 2);
						array2->SetData(0, 128);
						array2->SetData(3, (char)(Data->Length - 2));
						array2->SetData(1, Data->GetData(1));
						array2->SetData(2, Data->GetData(0));
						Array::Copy(Data, 2, array2, 4, Data->Length - 2);
					}
					else {
						array2->SetData(0, bBroadCast ? (char)(192 + (Data->Length - 2)) : (char)(128 + (Data->Length - 2)));
						array2->SetData(1, Data->GetData(1));
						array2->SetData(2, Data->GetData(0));
						Array::Copy(Data, 2, array2, 3, Data->Length - 2);
					}
					String* str2 = new String("Tx: ");
					*str2 += MainForm::ByteArrayToString(*array2, *array2->Length, new String(" "));
					MainForm::Channel->SendMessage(array2);
					result = true;
				}
			}
			else {
				result = false;
			}
		}
		catch (Exception* ex) {
			Console::WriteLine( ? ex->Message : *(new String("")));
			result = false;
		}
		return result;
	}
	bool MainForm::RecvRawKlineMsg(Array<char>* KlineMsg, int nBytesToReceive)
	{
		bool result;
		try {
			int num = 0;
			while (true) {
				GetMessageResults* message = MainForm::Channel->GetMessage();
				bool flag = message->Result == ResultCode::STATUS_NOERROR;
				if (!flag) {
					goto IL_A6;
				}
				bool flag2 = message->Messages->GetData(0)->RxStatus == RxFlag::START_OF_MESSAGE;
				if (!flag2) {
					Array::Copy(message->Messages->GetData(0)->Data, 0, KlineMsg, num, message->Messages->GetData(0)->Data->Length);
					num += *message->Messages->GetData(0)->Data->Length;
					bool flag3 = num == (nBytesToReceive - 1);
					if (flag3) {
						break;
					}
				}
			}
			String* str = new String("Rx: ");
			*str += MainForm::ByteArrayToString(KlineMsg, KlineMsg->Length, new String(" "));
			result = true;
			return result;
			IL_A6:
			result = false;
		}
		catch (Exception* ex) {
			Console::WriteLine( ? ex->Message : *(new String("")));
			result = false;
		}
		return result;
	}
	bool MainForm::RecvIso14230(MainForm::Iso14230RecvObj* iso14230RecvObj)
	{
		bool result;
		try {
			GetMessageResults* message;
			bool flag2;
			do {
				message = MainForm::Channel->GetMessage();
				bool flag = message->Result == ResultCode::STATUS_NOERROR;
				if (!flag) {
					goto IL_109;
				}
				flag2 = message->Messages->GetData(0)->RxStatus == RxFlag::START_OF_MESSAGE;
			}
			while (flag2);
			bool flag3 = message->Messages->GetData(0)->Data->GetData(0) == 128;
			if (flag3) {
				iso14230RecvObj->sete4_Data(new Array<char>(message->Messages->GetData(0)->Data->Length - 4));
				Array::Copy(message->Messages->GetData(0)->Data, 4, iso14230RecvObj->gete4_Data(), 0, iso14230RecvObj->gete4_Data()->Length);
			}
			else {
				iso14230RecvObj->sete4_Data(new Array<char>(message->Messages->GetData(0)->Data->Length - 3));
				Array::Copy(message->Messages->GetData(0)->Data, 3, iso14230RecvObj->gete4_Data(), 0, iso14230RecvObj->gete4_Data()->Length);
			}
			String* str = new String("Rx: ");
			*str += MainForm::ByteArrayToString(iso14230RecvObj->gete4_Data(), iso14230RecvObj->gete4_Data()->Length, new String(" "));
			result = true;
			return result;
			IL_109:
			result = false;
		}
		catch (Exception* ex) {
			Console::WriteLine( ? ex->Message : *(new String("")));
			result = false;
		}
		return result;
	}
	bool MainForm::StartIso14230Old(uint BaudRate)
	{
		bool result;
		try {
			bool flag = MainForm::Channel != null;
			if (flag) {
				MainForm::Channel->ClearRxBuffer();
				MainForm::Channel->ClearTxBuffer();
				MainForm::Channel->ClearPeriodicMsgs();
				MainForm::Channel->Dispose();
			}
			MainForm::Channel = MainForm::Device->GetChannel(Protocol::ISO9141, (Baud)(BaudRate), ConnectFlag::ISO9141_K_LINE_ONLY, false);
			MainForm::Channel->DefaultRxTimeout = 400;
			MainForm::Channel->DefaultTxTimeout = 400;
		}
		catch (Exception* ex) {
			Console::WriteLine(ex->Message);
			result = false;
			return result;
		}
		result = true;
		return result;
	}
	bool MainForm::SetParamsIso14230Old(char testerAddr, char interbyte, uint BaudRate)
	{
		bool result;
		try {
			MainForm::TesterAddress = testerAddr;
			MainForm::InterbyteTime = interbyte;
			Array<SConfig>* expr_14 = new Array<SConfig>(6);
			expr_14->SetData(0, new SConfig(Parameter::DATA_RATE, (int)(BaudRate)));
			expr_14->SetData(1, new SConfig(Parameter::P1_MIN, (int)(MainForm::InterbyteTime)));
			expr_14->SetData(2, new SConfig(Parameter::P1_MAX, 20));
			expr_14->SetData(3, new SConfig(Parameter::P4_MIN, (int)(MainForm::InterbyteTime)));
			expr_14->SetData(4, new SConfig(Parameter::P4_MAX, (int)(MainForm::InterbyteTime + 4)));
			expr_14->SetData(5, new SConfig(Parameter::PARITY, 0));
			Array<SConfig>* config = expr_14;
			MainForm::Channel->SetConfig(config);
			MessageFilter* messageFilter = new MessageFilter();
			messageFilter->PassAll();
			MainForm::Channel->StartMsgFilter(messageFilter);
			result = true;
		}
		catch (Exception* ex) {
			Console::WriteLine( ? ex->Message : *(new String("")));
			result = false;
		}
		return result;
	}
	bool MainForm::ConnectToUnitCAN()
	{
		MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
		bool flag = MainForm::Channel == null;
		if (flag) {
			MainForm::Channel = MainForm::Device->GetChannel(Protocol::ISO15765, Baud::CAN, ConnectFlag::NONE, false);
			MainForm::Channel->DefaultTxFlag = TxFlag::ISO15765_FRAME_PAD;
			MainForm::Channel->SetConfig(Parameter::ISO15765_STMIN, 1);
		}
		bool flag2 = (MainForm::g_ECUSelected == MainForm::ECUTYPE::TC265_MT21M) || (MainForm::g_ECUSelected == MainForm::ECUTYPE::MC9S12XEP768);
		if (flag2) {
			MainForm::g_ecu_CanTx = 2016;
			MainForm::g_ecu_CanRx = 2024;
		}
		return true;
	}
	bool MainForm::ConnectToUnitnew(bool bBroadcast)
	{
		MainForm::Iso14230RecvObj* iso14230RecvObj = new MainForm::Iso14230RecvObj();
		MainForm::StartIso14230Old(10400u);
		Thread::Sleep(100);
		bool flag = !MainForm::SetParamsIso14230Old(MainForm::TesterAddress, 0, 10400u);
		bool result;
		if (flag) {
			result = false;
		}
		else {
			Thread::Sleep(100);
			bool flag2 = !MainForm::WakeupIso14230(MainForm::UnitAddress, bBroadcast, true);
			result = !flag2;
		}
		return result;
	}
	bool MainForm::ConnectToUnitold(bool bBroadcast, bool bUseRawInit)
	{
		MainForm::Iso14230RecvObj* iso14230RecvObj = new MainForm::Iso14230RecvObj();
		Array<char>* array = new Array<char>(5);
		int num = 0;
		bool flag = false;
		while (true) {
			if (bUseRawInit) {
				MainForm::StartIso14230(15625u, ConnectFlag::ISO9141_NO_CHECKSUM);
				bool flag2 = !MainForm::SetParamsIso9141(MainForm::TesterAddress, 0, 15625u);
				if (flag2) {
					break;
				}
				MainForm::Channel->ClearRxBuffer();
				MainForm::Channel->ClearTxBuffer();
				MainForm::SendRawKline(MainForm::StringToByteArray(new String("F7")));
				MessageBox::Show(new String("Please click OK, after click OK  \r\n \r\n Switch Ignition OFF then ON "));
				int num2 = 0;
				int num3 = 150;
				do {
					MainForm::SendRawKline(MainForm::StringToByteArray(new String("F7")));
					num2 += 1;
					bool flag3 = *(array->GetData(0)) == 203;
					if (flag3) {
						flag = true;
					}
				}
				while (!flag && (num2 < num3));
			}
			MainForm::StartIso14230(10400u, ConnectFlag::ISO9141_K_LINE_ONLY);
			bool flag4 = !MainForm::SetParamsIso14230(MainForm::TesterAddress, 0, 10400u);
			if (flag4) {
				goto Block_5;
			}
			MainForm::Channel->ClearRxBuffer();
			MainForm::Channel->ClearTxBuffer();
			bool flag5 = !MainForm::WakeupIso14230(MainForm::UnitAddress, bBroadcast, true);
			if (!flag5) {
				goto IL_13D;
			}
			num += 1;
			bool flag6 = num > 1;
			if (flag6) {
				goto Block_7;
			}
			Thread::Sleep(1000);
			if (num >= 3) {
				goto Block_8;
			}
		}
		bool result = false;
		return result;
		Block_5:
		result = false;
		return result;
		Block_7:
		result = false;
		return result;
		IL_13D:
		result = true;
		return result;
		Block_8:
		result = true;
		return result;
	}
	void MainForm::ReadECUInfo()
	{
		MainForm::Iso14230RecvObj* iso14230RecvObj = new MainForm::Iso14230RecvObj();
		String* text = new String("");
		String* text2 = new String("");
		String* text3 = new String("");
		String* text4 = new String("");
		String* text5 = new String("");
		String* text6 = new String("");
		String* text7 = new String("");
		String* text8 = new String("");
		String* text9 = new String("");
		String* text10 = new String("");
		String* text11 = new String("");
		String* text12 = new String("");
		Thread::Sleep(500);
		bool flag = MainForm::ConnectToUnitnew(false);
		if (flag) {
			Array<char>* aMsg = MainForm::StringToByteArray(new String("3E"));
			Thread::Sleep(50);
			bool flag2 = !MainForm::sendRequestKLine(aMsg, iso14230RecvObj, true);
			if (flag2) {
			}
			Thread::Sleep(50);
			Array<char>* aMsg2 = MainForm::StringToByteArray(new String("10 83"));
			bool flag3 = MainForm::sendRequestKLine(aMsg2, iso14230RecvObj, true);
			if (flag3) {
				Thread::Sleep(10);
			}
			Array<char>* array = new Array<char>(4);
			Array<char>* aMsg3 = MainForm::StringToByteArray(new String("1A 8A"));
			bool flag4 = MainForm::sendRequestKLine(aMsg3, iso14230RecvObj, false);
			if (flag4) {
				Thread::Sleep(10);
				bool flag5 = iso14230RecvObj->gete4_Data()->Length >= 6;
				if (flag5) {
					Array::Copy(iso14230RecvObj->gete4_Data(), 2, array, 0, 4);
				}
				text4 = Encoding::ASCII->GetString(array);
			}
			Array<char>* array2 = new Array<char>(4);
			Array<char>* aMsg4 = MainForm::StringToByteArray(new String("1A 8C"));
			bool flag6 = MainForm::sendRequestKLine(aMsg4, iso14230RecvObj, false);
			if (flag6) {
				Thread::Sleep(10);
				bool flag7 = iso14230RecvObj->gete4_Data()->Length >= 6;
				if (flag7) {
					Array::Copy(iso14230RecvObj->gete4_Data(), 2, array2, 0, 4);
				}
				text7 = MainForm::ByteArrayToString(array2, 4, new String(""));
			}
			Array<char>* array3 = new Array<char>(4);
			Array<char>* aMsg5 = MainForm::StringToByteArray(new String("1A 94"));
			bool flag8 = MainForm::sendRequestKLine(aMsg5, iso14230RecvObj, false);
			if (flag8) {
				Thread::Sleep(10);
				bool flag9 = iso14230RecvObj->gete4_Data()->Length >= 6;
				if (flag9) {
					Array::Copy(iso14230RecvObj->gete4_Data(), 2, array3, 0, 4);
				}
				text = MainForm::ByteArrayToString(array3, 4, new String(""));
			}
			Array<char>* array4 = new Array<char>(1);
			Array<char>* aMsg6 = MainForm::StringToByteArray(new String("1A 95"));
			bool flag10 = MainForm::sendRequestKLine(aMsg6, iso14230RecvObj, false);
			if (flag10) {
				Thread::Sleep(10);
				bool flag11 = iso14230RecvObj->gete4_Data()->Length >= 3;
				if (flag11) {
					Array::Copy(iso14230RecvObj->gete4_Data(), 2, array4, 0, 1);
				}
				text2 = MainForm::ByteArrayToString(array4, 1, new String(""));
			}
			Array<char>* array5 = new Array<char>(4);
			Array<char>* aMsg7 = MainForm::StringToByteArray(new String("1A 97"));
			bool flag12 = MainForm::sendRequestKLine(aMsg7, iso14230RecvObj, false);
			if (flag12) {
				Thread::Sleep(10);
				bool flag13 = iso14230RecvObj->gete4_Data()->Length >= 6;
				if (flag13) {
					Array::Copy(iso14230RecvObj->gete4_Data(), 2, array5, 0, 4);
				}
				text3 = Encoding::ASCII->GetString(array5);
			}
			Array<char>* array6 = new Array<char>(4);
			Array<char>* aMsg8 = MainForm::StringToByteArray(new String("1A 98"));
			bool flag14 = MainForm::sendRequestKLine(aMsg8, iso14230RecvObj, false);
			if (flag14) {
				Thread::Sleep(10);
				bool flag15 = iso14230RecvObj->gete4_Data()->Length >= 6;
				if (flag15) {
					Array::Copy(iso14230RecvObj->gete4_Data(), 2, array6, 0, 4);
				}
				text9 = MainForm::ByteArrayToString(array6, 4, new String(""));
			}
			Array<char>* array7 = new Array<char>(4);
			Array<char>* aMsg9 = MainForm::StringToByteArray(new String("1A 99"));
			bool flag16 = MainForm::sendRequestKLine(aMsg9, iso14230RecvObj, false);
			if (flag16) {
				Thread::Sleep(10);
				bool flag17 = iso14230RecvObj->gete4_Data()->Length >= 6;
				if (flag17) {
					Array::Copy(iso14230RecvObj->gete4_Data(), 2, array7, 0, 4);
				}
				text8 = MainForm::ByteArrayToString(array7, 4, new String(""));
			}
			Array<char>* array8 = new Array<char>(17);
			Array<char>* aMsg10 = MainForm::StringToByteArray(new String("1A 90"));
			bool flag18 = MainForm::sendRequestKLine(aMsg10, iso14230RecvObj, false);
			if (flag18) {
				Thread::Sleep(10);
				bool flag19 = iso14230RecvObj->gete4_Data()->Length >= 19;
				if (flag19) {
					Array::Copy(iso14230RecvObj->gete4_Data(), 2, array8, 0, 17);
				}
				text6 = Encoding::ASCII->GetString(array8);
			}
			bool flag20 = (*text3 != *(new String(""))) && (*text2 != *(new String("")));
			if (flag20) {
				String* arg = new String("");
				bool flag21 = !MainForm::ECUPartNumDict->TryGetValue(text3, arg);
				if (flag21) {
					arg = new String("XXXXX");
				}
				text11 = String::Format(new String("{0}-{1}-{2}"), text3->Substring(0, 3), arg, text2);
			}
			this->SetECUInfo(text, text2, text3, text4, text5, text6, text7, text8, text9, text10, text11, text12);
		}
	}
	bool MainForm::ReadECUInfoCANBUS()
	{
		String* text = new String("");
		String* text2 = new String("");
		String* text3 = new String("");
		String* text4 = new String("");
		String* text5 = new String("");
		String* text6 = new String("");
		String* text7 = new String("");
		String* text8 = new String("");
		String* text9 = new String("");
		String* text10 = new String("");
		String* text11 = new String("");
		String* text12 = new String("");
		bool result;
		try {
			MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
			bool flag = this->ConnectToUnitCAN();
			if (!flag) {
				MainForm::g_sErrorMessage = new String("No answer from ECU!");
				result = false;
				return result;
			}
			this->SetText(new String("Please switch the ignition Off < Then > Switch Ignition ON"));
			Array<char>* aCanMsg = MainForm::StringToByteArray(new String("3E0001"));
			MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg, iso15765Recv, 1);
			Thread::Sleep(10);
			bool flag2 = MainForm::g_ECUSelected == MainForm::ECUTYPE::MC9S12XEP768;
			if (flag2) {
				Array<char>* array = new Array<char>(8);
				Array<char>* aCanMsg2 = MainForm::StringToByteArray(new String("22 F1 e8"));
				bool flag3 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg2, iso15765Recv, 1);
				if (flag3) {
					Thread::Sleep(10);
					bool flag4 = iso15765Recv->gete4_Data()->Length >= 8;
					if (flag4) {
						Array::Copy(iso15765Recv->gete4_Data(), 3, array, 0, 8);
					}
					text2 = MainForm::ByteArrayToString(array, 8, new String(""));
				}
				Array<char>* array2 = new Array<char>(4);
				Array<char>* aCanMsg3 = MainForm::StringToByteArray(new String("22 F1 E9"));
				bool flag5 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg3, iso15765Recv, 1);
				if (flag5) {
					Thread::Sleep(15);
					bool flag6 = iso15765Recv->gete4_Data()->Length >= 4;
					if (flag6) {
						Array::Copy(iso15765Recv->gete4_Data(), 3, array2, 0, 4);
					}
					text8 = MainForm::ByteArrayToString(array2, 4, new String(""));
				}
				Array<char>* array3 = new Array<char>(8);
				Array<char>* aCanMsg4 = MainForm::StringToByteArray(new String("22 F1 EA"));
				bool flag7 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg4, iso15765Recv, 1);
				if (flag7) {
					Thread::Sleep(10);
					bool flag8 = iso15765Recv->gete4_Data()->Length >= 12;
					if (flag8) {
						Array::Copy(iso15765Recv->gete4_Data(), 3, array3, 0, 8);
					}
					text3 = Encoding::ASCII->GetString(array3);
				}
				Array<char>* array4 = new Array<char>(12);
				Array<char>* aCanMsg5 = MainForm::StringToByteArray(new String("22 F1 EC"));
				bool flag9 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg5, iso15765Recv, 1);
				if (flag9) {
					Thread::Sleep(10);
					bool flag10 = iso15765Recv->gete4_Data()->Length >= 12;
					if (flag10) {
						Array::Copy(iso15765Recv->gete4_Data(), 3, array4, 0, 12);
					}
					text7 = Encoding::ASCII->GetString(array4);
				}
				Array<char>* array5 = new Array<char>(12);
				Array<char>* aCanMsg6 = MainForm::StringToByteArray(new String("22 F1 ED"));
				bool flag11 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg6, iso15765Recv, 1);
				if (flag11) {
					Thread::Sleep(10);
					bool flag12 = iso15765Recv->gete4_Data()->Length >= 12;
					if (flag12) {
						Array::Copy(iso15765Recv->gete4_Data(), 3, array5, 0, 12);
					}
					text4 = Encoding::ASCII->GetString(array5);
				}
				Array<char>* array6 = new Array<char>(12);
				Array<char>* aCanMsg7 = MainForm::StringToByteArray(new String("22 F1 EE"));
				bool flag13 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg7, iso15765Recv, 1);
				if (flag13) {
					Thread::Sleep(10);
					bool flag14 = iso15765Recv->gete4_Data()->Length >= 12;
					if (flag14) {
						Array::Copy(iso15765Recv->gete4_Data(), 3, array6, 0, 12);
					}
					text9 = Encoding::ASCII->GetString(array6);
				}
				Array<char>* array7 = new Array<char>(17);
				Array<char>* aCanMsg8 = MainForm::StringToByteArray(new String("22 F1 EF"));
				bool flag15 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg8, iso15765Recv, 1);
				if (flag15) {
					Thread::Sleep(10);
					bool flag16 = iso15765Recv->gete4_Data()->Length >= 20;
					if (flag16) {
						Array::Copy(iso15765Recv->gete4_Data(), 3, array7, 0, 17);
					}
					text6 = Encoding::ASCII->GetString(array7);
				}
				Array<char>* array8 = new Array<char>(4);
				Array<char>* aCanMsg9 = MainForm::StringToByteArray(new String("22 02 21"));
				bool flag17 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg9, iso15765Recv);
				if (flag17) {
					Thread::Sleep(15);
					bool flag18 = iso15765Recv->gete4_Data()->Length >= 100;
					if (flag18) {
						Array::Copy(iso15765Recv->gete4_Data(), 5, array8, 0, 4);
					}
					text12 = MainForm::ByteArrayToDecimalStringAll(array8, 4) + *(new String(" Km"));
				}
			}
			else {
				bool flag19 = MainForm::g_ECUSelected == MainForm::ECUTYPE::TC265_MT21M;
				if (flag19) {
					Array<char>* array9 = new Array<char>(8);
					Array<char>* aCanMsg10 = MainForm::StringToByteArray(new String("22 10 01"));
					bool flag20 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg10, iso15765Recv, 1);
					if (flag20) {
						Thread::Sleep(10);
						bool flag21 = iso15765Recv->gete4_Data()->Length >= 8;
						if (flag21) {
							Array::Copy(iso15765Recv->gete4_Data(), 3, array9, 0, 8);
						}
						text = MainForm::ByteArrayToString(array9, 8, new String(""));
					}
					Array<char>* array10 = new Array<char>(5);
					Array<char>* aCanMsg11 = MainForm::StringToByteArray(new String("22 F1 80"));
					bool flag22 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg11, iso15765Recv, 1);
					if (flag22) {
						Thread::Sleep(10);
						bool flag23 = iso15765Recv->gete4_Data()->Length >= 8;
						if (flag23) {
							Array::Copy(iso15765Recv->gete4_Data(), 3, array10, 0, 5);
						}
						text10 = MainForm::ByteArrayToString(array10, 5, new String(""));
					}
					Array<char>* array11 = new Array<char>(5);
					Array<char>* aCanMsg12 = MainForm::StringToByteArray(new String("22 F1 81"));
					bool flag24 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg12, iso15765Recv, 1);
					if (flag24) {
						Thread::Sleep(10);
						bool flag25 = iso15765Recv->gete4_Data()->Length >= 8;
						if (flag25) {
							Array::Copy(iso15765Recv->gete4_Data(), 3, array11, 0, 5);
						}
						text5 = MainForm::ByteArrayToString(array11, 5, new String(""));
					}
					Array<char>* array12 = new Array<char>(5);
					Array<char>* aCanMsg13 = MainForm::StringToByteArray(new String("22 F1 82"));
					bool flag26 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg13, iso15765Recv, 1);
					if (flag26) {
						Thread::Sleep(10);
						bool flag27 = iso15765Recv->gete4_Data()->Length >= 8;
						if (flag27) {
							Array::Copy(iso15765Recv->gete4_Data(), 3, array12, 0, 5);
						}
						text11 = MainForm::ByteArrayToString(array12, 5, new String(""));
					}
					Array<char>* array13 = new Array<char>(8);
					Array<char>* aCanMsg14 = MainForm::StringToByteArray(new String("22 F1 E8"));
					bool flag28 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg14, iso15765Recv, 1);
					if (flag28) {
						Thread::Sleep(10);
						bool flag29 = iso15765Recv->gete4_Data()->Length >= 8;
						if (flag29) {
							Array::Copy(iso15765Recv->gete4_Data(), 3, array13, 0, 8);
						}
						text2 = MainForm::ByteArrayToString(array13, 8, new String(""));
					}
					Array<char>* array14 = new Array<char>(12);
					Array<char>* aCanMsg15 = MainForm::StringToByteArray(new String("22 F1 EC"));
					bool flag30 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg15, iso15765Recv, 1);
					if (flag30) {
						Thread::Sleep(10);
						bool flag31 = iso15765Recv->gete4_Data()->Length >= 12;
						if (flag31) {
							Array::Copy(iso15765Recv->gete4_Data(), 3, array14, 0, 12);
						}
						text7 = Encoding::ASCII->GetString(array14);
					}
					Array<char>* array15 = new Array<char>(12);
					Array<char>* aCanMsg16 = MainForm::StringToByteArray(new String("22 F1 ED"));
					bool flag32 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg16, iso15765Recv, 1);
					if (flag32) {
						Thread::Sleep(10);
						bool flag33 = iso15765Recv->gete4_Data()->Length >= 12;
						if (flag33) {
							Array::Copy(iso15765Recv->gete4_Data(), 3, array15, 0, 12);
						}
						text4 = Encoding::ASCII->GetString(array15);
					}
					Array<char>* array16 = new Array<char>(12);
					Array<char>* aCanMsg17 = MainForm::StringToByteArray(new String("22 F1 EE"));
					bool flag34 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg17, iso15765Recv, 1);
					if (flag34) {
						Thread::Sleep(10);
						bool flag35 = iso15765Recv->gete4_Data()->Length >= 12;
						if (flag35) {
							Array::Copy(iso15765Recv->gete4_Data(), 3, array16, 0, 12);
						}
						text9 = Encoding::ASCII->GetString(array16);
					}
					Array<char>* array17 = new Array<char>(17);
					Array<char>* aCanMsg18 = MainForm::StringToByteArray(new String("22 F1 90"));
					bool flag36 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg18, iso15765Recv, 1);
					if (flag36) {
						Thread::Sleep(10);
						bool flag37 = iso15765Recv->gete4_Data()->Length >= 20;
						if (flag37) {
							Array::Copy(iso15765Recv->gete4_Data(), 3, array17, 0, 17);
						}
						text6 = Encoding::ASCII->GetString(array17);
					}
					Array<char>* array18 = new Array<char>(8);
					Array<char>* aCanMsg19 = MainForm::StringToByteArray(new String("22 F1 93"));
					bool flag38 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg19, iso15765Recv, 1);
					if (flag38) {
						Thread::Sleep(10);
						bool flag39 = iso15765Recv->gete4_Data()->Length >= 12;
						if (flag39) {
							Array::Copy(iso15765Recv->gete4_Data(), 3, array18, 0, 8);
						}
						text3 = Encoding::ASCII->GetString(array18);
					}
					Array<char>* array19 = new Array<char>(8);
					Array<char>* aCanMsg20 = MainForm::StringToByteArray(new String("22 F1 99"));
					bool flag40 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg20, iso15765Recv, 1);
					if (flag40) {
						Thread::Sleep(15);
						bool flag41 = iso15765Recv->gete4_Data()->Length >= 8;
						if (flag41) {
							Array::Copy(iso15765Recv->gete4_Data(), 3, array19, 0, 8);
						}
						text8 = Encoding::ASCII->GetString(array19);
					}
					Array<char>* array20 = new Array<char>(4);
					Array<char>* aCanMsg21 = MainForm::StringToByteArray(new String("22 02 21"));
					bool flag42 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg21, iso15765Recv);
					if (flag42) {
						Thread::Sleep(15);
						bool flag43 = iso15765Recv->gete4_Data()->Length >= 100;
						if (flag43) {
							Array::Copy(iso15765Recv->gete4_Data(), 5, array20, 0, 4);
						}
						text12 = MainForm::ByteArrayToDecimalStringAll(array20, 4) + *(new String(" Km"));
					}
				}
			}
			this->SetECUInfo(text, text2, text3, text4, text5, text6, text7, text8, text9, text10, text11, text12);
		}
		catch (Exception* ex) {
			StackTrace* stackTrace = new StackTrace(ex, true);
			StackFrame* frame = stackTrace->GetFrame(stackTrace->FrameCount - 1);
			MessageBox::Show(((*(new String("Error, ReadECUInfoCANBUS , line ")) + new String(frame->GetFileLineNumber())) + *(new String(": "))) + *(ex->Message));
			result = false;
			return result;
		}
		result = true;
		return result;
	}
	void MainForm::ReadECUInfoCAN()
	{
		try {
			bool flag = this->ConnectToUnitCAN();
			if (flag) {
				this->ReadECUInfoCANBUS();
				this->ClearText();
			}
			else {
				MainForm::g_sErrorMessage = new String("No answer from unit!");
			}
		}
		catch (Exception* ex) {
			Console::WriteLine(ex->Message);
		}
	}
	bool MainForm::CANWriteFlashXEP768(BackgroundWorker* worker, DoWorkEventArgs* e)
	{
		bool result;
		try {
			MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
			uint num = 0u;
			uint num2 = 0u;
			bool flag = (this->g_Data == null) || (this->g_Data->Length == 0);
			if (flag) {
				MainForm::g_sErrorMessage = new String("No data loaded.");
				result = false;
				return result;
			}
			MainForm::ECUTYPE eCUTYPE = MainForm::g_ECUSelected;
			MainForm::ECUTYPE eCUTYPE2 = eCUTYPE;
			int num3;
			if (eCUTYPE2 != MainForm::ECUTYPE::MC9S12XEP768) {
				if (eCUTYPE2 != MainForm::ECUTYPE::TC265_MT21M) {
					MainForm::g_sErrorMessage = new String("Unsupported ECU type.");
					result = false;
					return result;
				}
				bool flag2 = this->g_Data->Length == 2621440;
				if (!flag2) {
					MainForm::g_sErrorMessage = new String("Wrong file size?");
					result = false;
					return result;
				}
				num3 = 131072;
			}
			else {
				bool flag3 = this->g_Data->Length == 786432;
				if (flag3) {
					num3 = 16384;
				}
				else {
					bool flag4 = this->g_Data->Length == 4096;
					if (!flag4) {
						MainForm::g_sErrorMessage = new String("Wrong file size?");
						result = false;
						return result;
					}
					num3 = 2048;
				}
			}
			bool flag5 = this->ConnectToUnitCAN();
			if (!flag5) {
				MainForm::g_sErrorMessage = new String("No answer from ECU!");
				result = false;
				return result;
			}
			Array<char>* aCanMsg = MainForm::StringToByteArray(new String("10 03"));
			MainForm::sendRequestCAN(2015, aCanMsg, iso15765Recv, 1);
			Thread::Sleep(10);
			this->ClearText();
			this->SetText(new String(" Erasing... Prepare Seed/Key..."));
			MainForm::sendRequestCAN(2015, aCanMsg, iso15765Recv, 1);
			Thread::Sleep(10);
			this->SetText(new String("Turn_DTC_Setting_Off"));
			Array<char>* aCanMsg2 = MainForm::StringToByteArray(new String("8502"));
			bool flag6 = MainForm::sendRequestCAN(2015, aCanMsg2, iso15765Recv, 1);
			if (flag6) {
			}
			this->SetText(new String("Disable_RxTx"));
			Array<char>* aCanMsg3 = MainForm::StringToByteArray(new String("280303"));
			bool flag7 = MainForm::sendRequestCAN(2015, aCanMsg3, iso15765Recv, 1);
			if (flag7) {
			}
			Array<char>* aCanMsg4 = MainForm::StringToByteArray(new String("10 02"));
			bool flag8 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg4, iso15765Recv, 1);
			if (flag8) {
			}
			Array<char>* expr_1ED = new Array<char>(3);
			RuntimeHelpers::InitializeArray(expr_1ED, fieldof(<PrivateImplementationDetails>::388CD0567C27CCC3231CBABAF96B6A31963F150282848836F1F33B17AF3FC162)->FieldHandle);
			Array<char>* aCanMsg5 = expr_1ED;
			Array<char>* array = new Array<char>(4);
			bool flag9 = false;
			while (!flag9) {
				bool flag10 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg5, iso15765Recv, 1);
				if (flag10) {
					bool flag11 = (iso15765Recv->gete4_Data() != null) && (iso15765Recv->gete4_Data()->Length >= 4);
					if (flag11) {
						flag9 = true;
					}
					else {
						this->SetText(new String("Invalid reply from ECU, retrying..."));
					}
				}
				else {
					this->SetText(new String("Failed to send 22 F1 F4 CAN message, retrying..."));
				}
			}
			bool flag12 = !flag9;
			if (flag12) {
				result = false;
				return result;
			}
			Array::Copy(iso15765Recv->gete4_Data(), 3, array, 0, 4);
			Array<char>* expr_29A = new Array<char>(2);
			expr_29A->SetData(0, 39);
			expr_29A->SetData(1, 1);
			Array<char>* aCanMsg6 = expr_29A;
			Array<char>* expr_2AB = new Array<char>(4);
			expr_2AB->SetData(0, 39);
			expr_2AB->SetData(1, 2);
			Array<char>* array2 = expr_2AB;
			flag9 = false;
			while (!flag9) {
				bool flag13 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg6, iso15765Recv, 1);
				if (flag13) {
					bool flag14 = (iso15765Recv->gete4_Data() != null) && (iso15765Recv->gete4_Data()->Length >= 4);
					if (flag14) {
						flag9 = true;
					}
					else {
						this->SetText(new String("Invalid reply from ECU, retrying..."));
					}
				}
				else {
					this->SetText(new String("Failed to send Seed Request CAN message, retrying..."));
				}
			}
			bool flag15 = !flag9;
			if (flag15) {
				result = false;
				return result;
			}
			Array<char>* array3 = new Array<char>(2);
			Array<char>* sourceArray = new Array<char>(2);
			Array::Copy(iso15765Recv->gete4_Data(), 2, array3, 0, 2);
			bool flag16 = this->SecurityAccess1(array3, array, sourceArray);
			if (flag16) {
				Array::Copy(sourceArray, 0, array2, 2, 2);
				bool flag17 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, array2, iso15765Recv, 1);
				if (flag17) {
					this->SetText(new String("Security Access Succeeded... Please wait"));
				}
				else {
					this->SetText(new String("Security Access failed."));
				}
			}
			else {
				this->SetText(new String("Security Access failed during key generation."));
			}
			Thread::Sleep(800);
			Array<char>* expr_3CD = new Array<char>(2);
			expr_3CD->SetData(0, 39);
			expr_3CD->SetData(1, 1);
			Array<char>* expr_3DE = new Array<char>(4);
			expr_3DE->SetData(0, 39);
			expr_3DE->SetData(1, 2);
			flag9 = false;
			while (!flag9) {
				bool flag18 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg6, iso15765Recv, 1);
				if (flag18) {
					bool flag19 = (iso15765Recv->gete4_Data() != null) && (iso15765Recv->gete4_Data()->Length >= 4);
					if (flag19) {
						flag9 = true;
					}
					else {
						this->SetText(new String("Invalid reply from ECU, retrying..."));
					}
				}
				else {
					this->SetText(new String("Failed to send Seed Request CAN message, retrying..."));
				}
			}
			bool flag20 = !flag9;
			if (flag20) {
				result = false;
				return result;
			}
			Array<char>* array4 = new Array<char>(2);
			Array<char>* array5 = new Array<char>(2);
			Array::Copy(iso15765Recv->gete4_Data(), 2, array3, 0, 2);
			this->harley_calc_access_key_1(array3, sourceArray);
			Array::Copy(sourceArray, 0, array2, 2, 2);
			bool flag21 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, array2, iso15765Recv, 1);
			if (!flag21) {
				this->SetText(new String("Security Access failed."));
				result = false;
				return result;
			}
			this->SetText(new String("Security Access Succeeded... Please wait"));
			Array<char>* aCanMsg7 = MainForm::StringToByteArray(new String("34 00 44 00 00 80 00 00 00 04 20"));
			bool flag22 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg7, iso15765Recv, 1);
			if (flag22) {
			}
			MainForm::Channel->DefaultTxTimeout = 300;
			Array<char>* aCanMsg8 = MainForm::StringToByteArray(new String("36 01 98 5e 00 07 00 00 80 00 00 00 84 1f 23 e1 f5 88 00 09 07 e0 00 01 02 03 18 20 01 4e cd 03 76 dc 23 5d 17 5c 19 87 c7 20 09 cc 30 00 5c 17 87 c7 5c 19 5c 1b 5c 1d 18 0c 01 46 01 4a cd 01 70 cc fd 00 6c 40 86 08 6c 4c dc 17 6c 44 dc 19 6c 46 dc 1b 6c 48 dc 1d 6c 4a b6 01 4a 18 0e 7c 01 46 3d 15 fa 02 ef 1e 01 44 01 14 de 13 08 5e 13 26 f0 96 12 42 5a 12 81 46 23 e7 c6 f4 20 54 ce 01 60 ec 00 8c fb e0 27 0b 8c fc 00 27 06 1c 01 44 01 20 ce 87 c7 5a 12 5c 13 ec 0a 5c 1d ec 08 5c 1b ec 06 5c 19 ed 04 1c 01 44 01 5d 17 b7 e4 c1 3e 26 08 81 02 25 04 81 07 23 a6 b7 e4 3d 07 a1 81 36 18 26 00 b9 5b 23 b7 64 84 f0 81 10 27 04 c6 12 20 39 b7 64 84 0f 04 44 05 8c 08 02 23 04 c6 13 20 29 83 00 06 5c 1f dd 21 19 44 5d 21 dd 15 dc 1b 6c 71 dc 1d 6c 71 5d 15 15 f9 2b 86 21 5a 25 15 f9 5c b7 e4 91 25 27 06 c6 73 18 20 02 2c 42 84 ef 5a 25 b7 e4 dc 1f 83 00 07 25 24 5c 1f dd 21 19 47 5d 21 dd 15 96 18 6a 70 dc 19 6c 71 dc 1b 6c 71 dc 1d 6c 71 5d 15 dc 1f 26 c3 96 21 20 1a ce 10 18 dd 15 cb 07 37 dc 21 18 0a 30 70 c3 00 01 63 80 26 f5 5d 15 5c 21 33 81 08 24 08 15 fa fe b7 18 20 ff 55 3d ce 10 07 cd 00 1f 87 c7 6c 31 04 36 fb 15 fa fe e6 81 34 27 04 c6 24 20 3a b6 00 9a 81 5a 24 04 c6 93 20 2d dc 1a 8c 00 44 27 04 c6 31 20 22 b7 64 81 10 26 08 c1 0b 24 08 c6 13 20 14 c6 12 20 10 15 fa fe 7a 15 fa fe ae b7 64 81 21 27 08 c6 24 86 34 18 20 01 7e cc 04 74 5c 17 cc 20 08 5c 19 cc 02 00 5c 1b 87 15 fa fe 5f cd 14 52 5d 15 87 c7 5c 21 15 fa fe dc fc 14 52 5c 08 f6 14 57 5b 11 5b 0c fc 14 58 5c 0f 5c 0a fc 14 5c 8c f7 ff 23 03 cc f7 ff 5c 0d fe 14 54 8e 00 02 26 1a 4c 07 20 c6 f2 b6 f7 ff 81 55 26 0a fe 14 62 be f7 f5 27 1e c6 f0 18 20 01 19 c6 f5 04 35 f7 c6 f1 fe 14 5e cd f8 00 ae 4c 26 eb fe 14 60 ae 4e 26 e4 de 0d 1a e2 fc 01 c6 7f 15 fa 01 43 de 0f d6 11 15 fa 01 16 97 18 26 00 da cd 14 52 de 0a d6 0c 15 fa 01 47 cd 14 52 de 0a d6 0c 15 fa 01 9e 97 18 26 00 bf d6 0c de 0a 1a e2 08 00 18 97 26 07 52 c1 7f 22 58 5b 0c 5e 0a c1 7f 25 04 9e 0d 24 4c c6 93 86 5a b1 00 9a 25 0d ce 09 c4 04 35 fd b1 00 9a 18 24 ff 7d c6 f6 b6 01 44 84 28 18 26 ff 72 15 fa fd 6a dc 15 b7 45 80 08 5c 15 b7 46 83 14 51 49 27 07 18 02 2e 6e 04 34 f9 dc 21 80 08 25 02 5c 21 15 fa fd e9 18 20 ff 7c dd 0f 02 02 5d 0a d6 11 5b 0c 7b 00 10 de 08 4f 07 30 10 9d 0d 22 08 18 e6 40 1a e5 04 b6 f4 b7 54 20 2c 18 e6 40 1a e5 04 b6 f8 07 4e 96 0c 42 5a 0c 7a 00 10 81 7f 25 ea 9d 0d 22 08 18 e6 40 1a e5 04 b6 f4 b7 54 18 fe 40 00 5e 08 07 37 04 44 1d c6 f7 20 02 c6 72 37 de 0d 1a e2 fc 01 c6 7f 07 4f 33 86 36 cd 03 7f 15 fa fc db 20 08 86 86 5a 24 15 fa fc cc 07 02 20 fe 18 0b 55 00 3f 18 0b aa 00 3f 3d d0 08 82 00 9b 08 3d 4f 07 30 02 20 0f 07 1d 1a e2 04 00 18 97 26 f6 52 c1 7f 25 f1 9e 0d 24 0a 07 0a 1a e2 04 00 18 97 26 f2 87 3d 1d 01 02 07 86 0a 7c 01 0a 1c 01 02 01 7e 01 0a 1c 01 06 80 07 b3 1f 01 06 80 fb 3d c1 7f 24 0d 07 1d 19 48 1a 08 8d 1c 52 25 f5 20 11 8d 1c 52 24 0c 9e 0d 24 08 07 07 19 48 1a 08 20 ef 3d 1d 01 02 07 86 06 7c 01 0a 1c 01 02 01 7e 01 0a 86 02 7a 01 02 18 05 40 01 0a 72 01 02 18 05 42 01 0a 72 01 02 18 05 44 01 0a 72 01 02 18 05 46 01 0a 1c 01 06 80 15 f9 51 1f 01 06 80 fb 3d 7b 00 10 cc 04 00 3b 18 ec 31 ac 71 3a 26 05 04 34 f4 20 02 86 c0 3d"));
			bool flag23 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg8, iso15765Recv);
			if (!flag23) {
				MessageBox::Show(new String("Error...."), new String("Flash write error"));
				result = false;
				return result;
			}
			Thread::Sleep(200);
			int num4 = 0;
			int tickCount = Environment::TickCount;
			bool flag24 = this->g_Data->Length == 786432;
			if (flag24) {
				num = 737280u;
				num2 = 16384u;
			}
			else {
				bool flag25 = this->g_Data->Length == 4096;
				if (flag25) {
					num = 2048u;
					num2 = 2048u;
				}
			}
			uint num5 = num;
			Array<char>* aCanMsg9 = MainForm::StringToByteArray(new String("34 00 44 00 00 40 00 00 00 40 00"));
			bool flag26 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg9, iso15765Recv, 1);
			if (!flag26) {
				result = false;
				return result;
			}
			bool flag27 = iso15765Recv->gete4_Data()->Length >= 4;
			if (!flag27) {
				result = false;
				return result;
			}
			ushort num6 = (ushort)(iso15765Recv->gete4_Data()->GetData(2) << 8) | (ushort)(iso15765Recv->gete4_Data()->GetData(3));
			num6 -= 2;
			ushort num7 = 256;
			int num8 = 0;
			char b = 1;
			MainForm::Channel->DefaultTxTimeout = 500;
			while (true) {
				Thread::Sleep(1);
				bool flag28 = (long)(num8 + (int)(num7)) > (long)((ulong)(num2));
				if (flag28) {
					num7 = (ushort)((ulong)(num2) - (ulong)((long)(num8)));
				}
				Array<char>* array6 = new Array<char>((int)(num7 + 2));
				array6->SetData(0, 54);
				array6->SetData(1, b);
				Array::Copy(this->g_Data, (long)((ulong)(num5) + (ulong)((long)(num8))), array6, 2L, (long)((ulong)(num7)));
				Debug::WriteLine(BitConverter::ToString(array6)->Replace(new String("-"), new String(" ")));
				bool flag29 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, array6, iso15765Recv, 1);
				if (!flag29) {
					break;
				}
				num8 += (int)(num7);
				num4 += (int)(num7);
				char b2 = (char)(((double)(num4) / (double)(num3)) * 100.0);
				this->SetProgress(b2 + 1);
				this->ClearText();
				double num9 = (double)(num4);
				int num10 = ((Environment::TickCount - tickCount) / 1000) % 60;
				int num11 = (((Environment::TickCount - tickCount) / 1000) / 60) % 60;
				double num12 = (num9 / (double)((Environment::TickCount - tickCount) / 1000)) / 1024.0;
				Array<String>* expr_758 = new Array<String>(12);
				expr_758->SetData(0, new String("Writing: "));
				expr_758->SetData(1, new String(num9 / 1024.0));
				expr_758->SetData(2, new String(" kb / "));
				expr_758->SetData(3, new String((double)(num3) / 1024.0));
				expr_758->SetData(4, new String(" kb ("));
				expr_758->SetData(5, b2->ToString(new String("F2")));
				expr_758->SetData(6, new String("%) | Speed: "));
				expr_758->SetData(7, num12->ToString(new String("0.00")));
				expr_758->SetData(8, new String(" kb/s | time elapse "));
				expr_758->SetData(9, num11->ToString(new String("D2")));
				expr_758->SetData(10, new String(":"));
				expr_758->SetData(11, num10->ToString(new String("D2")));
				this->SetText(String::Concat(expr_758));
				b += 1;
				if ((long)(num8) >= (long)((ulong)(num2))) {
					goto Block_35;
				}
			}
			result = false;
			return result;
			Block_35:
			this->SetText(new String("Performing reset, please wait..."));
			Array<char>* aCanMsg10 = MainForm::StringToByteArray(new String("11"));
			bool flag30 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg10, iso15765Recv, 1);
			if (flag30) {
			}
			MainForm::g_sErrorMessage = new String("Writing FLASH succesfull  Please restart ECU!");
		}
		catch (Exception* ex) {
			StackTrace* stackTrace = new StackTrace(ex, true);
			StackFrame* frame = stackTrace->GetFrame(stackTrace->FrameCount - 1);
			MessageBox::Show(((*(new String("Error, gFlash , line ")) + new String(frame->GetFileLineNumber())) + *(new String(": "))) + *(ex->Message));
			result = false;
			return result;
		}
		result = true;
		return result;
	}
	bool MainForm::CANWriteFlashTC265D(BackgroundWorker* worker, DoWorkEventArgs* e)
	{
		bool result;
		try {
			MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
			bool flag = (this->g_Data == null) || (this->g_Data->Length == 0);
			if (flag) {
				MainForm::g_sErrorMessage = new String("No data loaded.");
				result = false;
				return result;
			}
			MainForm::ECUTYPE eCUTYPE = MainForm::g_ECUSelected;
			MainForm::ECUTYPE eCUTYPE2 = eCUTYPE;
			int num;
			if (eCUTYPE2 != MainForm::ECUTYPE::MC9S12XEP768) {
				if (eCUTYPE2 != MainForm::ECUTYPE::TC265_MT21M) {
					MainForm::g_sErrorMessage = new String("Unsupported ECU type.");
					result = false;
					return result;
				}
				bool flag2 = this->g_Data->Length == 2621440;
				if (flag2) {
					num = 131072;
				}
				else {
					bool flag3 = this->g_Data->Length == 98304;
					if (!flag3) {
						MainForm::g_sErrorMessage = new String("Wrong file size?");
						result = false;
						return result;
					}
					num = 98304;
				}
			}
			else {
				bool flag4 = this->g_Data->Length == 786432;
				if (!flag4) {
					MainForm::g_sErrorMessage = new String("Wrong file size?");
					result = false;
					return result;
				}
				num = 16384;
			}
			bool flag5 = this->ConnectToUnitCAN();
			if (!flag5) {
				MainForm::g_sErrorMessage = new String("No answer from ECU!");
				result = false;
				return result;
			}
			Array<char>* aCanMsg = MainForm::StringToByteArray(new String("10 03"));
			MainForm::sendRequestCAN(2015, aCanMsg, iso15765Recv, 1);
			Thread::Sleep(10);
			this->ClearText();
			this->SetText(new String(" Erasing... Prepare Seed/Key..."));
			MainForm::sendRequestCAN(2015, aCanMsg, iso15765Recv, 1);
			Thread::Sleep(10);
			Array<char>* aCanMsg2 = MainForm::StringToByteArray(new String("8502"));
			bool flag6 = MainForm::sendRequestCAN(2015, aCanMsg2, iso15765Recv, 1);
			if (flag6) {
			}
			Array<char>* aCanMsg3 = MainForm::StringToByteArray(new String("280303"));
			bool flag7 = MainForm::sendRequestCAN(2015, aCanMsg3, iso15765Recv, 1);
			if (flag7) {
			}
			Array<char>* aCanMsg4 = MainForm::StringToByteArray(new String("10 02"));
			bool flag8 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg4, iso15765Recv, 1);
			if (flag8) {
			}
			this->aCallCanSATC265();
			Array<char>* aCanMsg5 = MainForm::StringToByteArray(new String("22 F1 99"));
			bool flag9 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg5, iso15765Recv, 1);
			if (flag9) {
			}
			List_T<char>* list = new List_T<char>();
			List_T<char>* arg_213_0 = *list;
			Array<char>* expr_208 = new Array<char>(3);
			RuntimeHelpers::InitializeArray(expr_208, fieldof(<PrivateImplementationDetails>::A8E38C7DB094115750BB5571C52B1C211F160805BD26241703DEF1576C811F82)->FieldHandle);
			arg_213_0->AddRange(expr_208);
			Array<char>* array = new Array<char>(iso15765Recv->gete4_Data()->Length - 3);
			Array::Copy(iso15765Recv->gete4_Data(), 3, array, 0, iso15765Recv->gete4_Data()->Length - 3);
			list->AddRange(array);
			Array<char>* aCanMsg6 = list->ToArray();
			bool flag10 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg6, iso15765Recv, 1);
			if (flag10) {
			}
			Array<char>* aCanMsg7 = MainForm::StringToByteArray(new String("34 00 44 70 10 00 00 00 00 0A 5C"));
			bool flag11 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg7, iso15765Recv, 1);
			if (flag11) {
			}
			Thread::Sleep(50);
			this->aCallCanWriteKernelTC265();
			Thread::Sleep(50);
			Array<char>* aCanMsg8 = MainForm::StringToByteArray(new String("37"));
			bool flag12 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg8, iso15765Recv, 1);
			if (flag12) {
			}
			Array<char>* aCanMsg9 = MainForm::StringToByteArray(new String("31 01 40 02 01"));
			bool flag13 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg9, iso15765Recv, 1);
			if (flag13) {
			}
			Thread::Sleep(50);
			bool flag14 = this->g_Data->Length == 2621440;
			if (flag14) {
				Array<char>* aCanMsg10 = MainForm::StringToByteArray(new String("31 01 FF 00 70 0A 00 00"));
				bool flag15 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg10, iso15765Recv);
				if (flag15) {
				}
			}
			else {
				bool flag16 = this->g_Data->Length == 98304;
				if (flag16) {
					Array<char>* aCanMsg11 = MainForm::StringToByteArray(new String("31 01 FF 00 7F 00 00 00"));
					bool flag17 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg11, iso15765Recv);
					if (flag17) {
					}
					Thread::Sleep(50);
					aCanMsg11 = MainForm::StringToByteArray(new String("31 01 FF 00 7F 00 40 00"));
					bool flag18 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg11, iso15765Recv);
					if (flag18) {
					}
					Thread::Sleep(50);
					aCanMsg11 = MainForm::StringToByteArray(new String("31 01 FF 00 7F 00 80 00"));
					bool flag19 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg11, iso15765Recv);
					if (flag19) {
					}
					Thread::Sleep(50);
					aCanMsg11 = MainForm::StringToByteArray(new String("31 01 FF 00 7F 00 C0 00"));
					bool flag20 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg11, iso15765Recv);
					if (flag20) {
					}
					Thread::Sleep(50);
					aCanMsg11 = MainForm::StringToByteArray(new String("31 01 FF 00 7F 01 00 00"));
					bool flag21 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg11, iso15765Recv);
					if (flag21) {
					}
					Thread::Sleep(50);
					aCanMsg11 = MainForm::StringToByteArray(new String("31 01 FF 00 7F 01 40 00"));
					bool flag22 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg11, iso15765Recv);
					if (flag22) {
					}
				}
			}
			int num2 = 0;
			int tickCount = Environment::TickCount;
			ushort num3 = 256;
			bool flag23 = this->g_Data->Length == 2621440;
			uint num4;
			uint num5;
			if (flag23) {
				num4 = 524288u;
				num5 = 262144u;
			}
			else {
				num4 = 0u;
				num5 = 98304u;
			}
			ushort num6 = num3;
			int num7 = 0;
			uint num8 = num4;
			do {
				bool flag24 = (long)(num7 + (int)(num6)) > (long)((ulong)(num5));
				if (flag24) {
					num6 = (ushort)((ulong)(num5) - (ulong)((long)(num7)));
				}
				Array<char>* array2 = new Array<char>((int)(num6 + 5));
				array2->SetData(0, 61);
				bool flag25 = this->g_Data->Length == 2621440;
				if (flag25) {
					array2->SetData(1, 112);
				}
				else {
					bool flag26 = this->g_Data->Length == 98304;
					if (flag26) {
						array2->SetData(1, 127);
					}
				}
				array2->SetData(2, (char)((num8 >> 16) & 255u));
				array2->SetData(3, (char)((num8 >> 8) & 255u));
				array2->SetData(4, 0);
				Array::Copy(this->g_Data, (long)((ulong)(num8)), array2, 5L, (long)((ulong)(num6)));
				bool flag27 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, array2, iso15765Recv, 1);
				if (flag27) {
					num7 += (int)(num6);
				}
				num2 += (int)(num6);
				char b = (char)(((double)(num2) / (double)(num)) * 100.0);
				this->SetProgress(b + 1);
				this->ClearText();
				double num9 = (double)(num2);
				int num10 = ((Environment::TickCount - tickCount) / 1000) % 60;
				int num11 = (((Environment::TickCount - tickCount) / 1000) / 60) % 60;
				double num12 = (num9 / (double)((Environment::TickCount - tickCount) / 1000)) / 1024.0;
				Array<String>* expr_5D1 = new Array<String>(12);
				expr_5D1->SetData(0, new String("Writing: "));
				expr_5D1->SetData(1, new String(num9 / 1024.0));
				expr_5D1->SetData(2, new String(" KB / "));
				expr_5D1->SetData(3, new String((double)(num) / 1024.0));
				expr_5D1->SetData(4, new String(" KB ("));
				expr_5D1->SetData(5, b->ToString(new String("F2")));
				expr_5D1->SetData(6, new String("%) | Speed: "));
				expr_5D1->SetData(7, num12->ToString(new String("0.00")));
				expr_5D1->SetData(8, new String(" KB/s | Time lapse "));
				expr_5D1->SetData(9, num11->ToString(new String("D2")));
				expr_5D1->SetData(10, new String(":"));
				expr_5D1->SetData(11, num10->ToString(new String("D2")));
				this->SetText(String::Concat(expr_5D1));
				num8 += (uint)(num6);
				Debug::WriteLine(BitConverter::ToString(array2)->Replace(new String("-"), new String(" ")));
			}
			while ((long)(num7) < (long)((ulong)(num5)));
			this->SetText(new String("Performing reset, please wait..."));
			Array<char>* aCanMsg12 = MainForm::StringToByteArray(new String("11"));
			bool flag28 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg12, iso15765Recv, 1);
			if (flag28) {
			}
			MainForm::g_sErrorMessage = new String("Writing FLASH succesfull  Please restart ECU!");
			this->aCallDeleteFile();
		}
		catch (Exception* ex) {
			StackTrace* stackTrace = new StackTrace(ex, true);
			StackFrame* frame = stackTrace->GetFrame(stackTrace->FrameCount - 1);
			MessageBox::Show(((*(new String("Error, gFlash , line ")) + new String(frame->GetFileLineNumber())) + *(new String(": "))) + *(ex->Message));
			result = false;
			return result;
		}
		result = true;
		return result;
	}
	bool MainForm::SaveDump(Array<char>* Bytes, String* strFileName)
	{
		SaveFileDialog* expr_06 = new SaveFileDialog();
		expr_06->CheckPathExists = false;
		expr_06->CheckFileExists = false;
		expr_06->DefaultExt = new String(".bin");
		expr_06->AddExtension = true;
		SaveFileDialog* saveFileDialog = expr_06;
		bool flag = saveFileDialog->ShowDialog() != DialogResult::OK;
		bool result;
		if (flag) {
			result = false;
		}
		else {
			try {
				File::WriteAllBytes(saveFileDialog->FileName, Bytes);
				strFileName = saveFileDialog->FileName;
				result = true;
			}
			catch (Exception* ex) {
				Console::WriteLine(ex->Message);
				result = false;
			}
		}
		return result;
	}
	void MainForm::SelectComboBoxItem(String* itemText)
	{
		FOREACH(_COMBOBOXITEM, this->comboBox2->Items) {
			MainForm::ComboboxItem deref_comboboxItem = *_COMBOBOXITEM;
			MainForm::ComboboxItem* comboboxItem = &deref_comboboxItem;
			bool flag = comboboxItem->getText() == *itemText;
			if (flag) {
				this->comboBox2->SelectedItem = comboboxItem;
				break;
			}
		}
	}
	void MainForm::GetFlashTypeFromBinSize()
	{
		bool flag = MainForm::binSize == 131072;
		if (flag) {
			this->SelectComboBoxItem(new String("MC9S12DJ128_128kb_VPW"));
		}
		else {
			bool flag2 = MainForm::binSize == 786432;
			if (flag2) {
				this->SelectComboBoxItem(new String("MC9S12XEP768_768kb_CAN"));
			}
			else {
				bool flag3 = (MainForm::binSize == 2621440) || (MainForm::binSize == 98304);
				if (flag3) {
					this->SelectComboBoxItem(new String("TC265_MT21M_2560kb_CAN"));
				}
			}
		}
	}
	bool MainForm::VPWJ(BackgroundWorker* worker, DoWorkEventArgs* e)
	{
		bool result;
		try {
			MainForm::Iso14230RecvObj* iso14230RecvObj = new MainForm::Iso14230RecvObj();
			bool flag = (this->g_Data == null) || (this->g_Data->Length == 0);
			if (flag) {
				MainForm::g_sErrorMessage = new String("No data loaded.");
				result = false;
				return result;
			}
			this->ClearText();
			this->SetText(new String(" Erasing... Prepare Seed/Key..."));
			bool flag2 = MainForm::ConnectToUnitnew(true);
			if (!flag2) {
				bool flag3 = MainForm::ConnectToUnitold(true, true);
				if (!flag3) {
					MainForm::g_sErrorMessage = new String("No answer from ECU!");
					result = false;
					return result;
				}
			}
			Array<char>* aMsg = MainForm::StringToByteArray(new String("3E"));
			bool flag4 = !MainForm::sendRequestKLine(aMsg, iso14230RecvObj, true);
			if (flag4) {
			}
			Array<char>* aMsg2 = MainForm::StringToByteArray(new String("10 83"));
			bool flag5 = MainForm::sendRequestKLine(aMsg2, iso14230RecvObj, true);
			if (!flag5) {
				MainForm::g_sErrorMessage = new String("No answer!");
				result = false;
				return result;
			}
			Thread::Sleep(10);
			Array<char>* aMsg3 = MainForm::StringToByteArray(new String("85 02"));
			bool flag6 = MainForm::sendRequestKLine(aMsg3, iso14230RecvObj, true);
			if (flag6) {
				Thread::Sleep(10);
			}
			Array<char>* aMsg4 = MainForm::StringToByteArray(new String("28 03 01"));
			bool flag7 = MainForm::sendRequestKLine(aMsg4, iso14230RecvObj, true);
			if (flag7) {
				Thread::Sleep(10);
			}
			bool flag8 = !MainForm::sendRequestKLine(aMsg, iso14230RecvObj, true);
			if (flag8) {
			}
			Array<char>* aMsg5 = MainForm::StringToByteArray(new String("10 82"));
			bool flag9 = MainForm::sendRequestKLine(aMsg5, iso14230RecvObj, false);
			if (!flag9) {
				MainForm::g_sErrorMessage = new String("No answer!");
				result = false;
				return result;
			}
			Thread::Sleep(10);
			String* s = new String(DateTime::getNow()->Year - 2000);
			String* s2 = new String(DateTime::getNow()->Month);
			String* s3 = new String(DateTime::getNow()->Day);
			this->aKLineMsgTransferDataDataByCommonId2->SetData(4, Char::Parse(s, NumberStyles::HexNumber));
			this->aKLineMsgTransferDataDataByCommonId2->SetData(5, Char::Parse(s2, NumberStyles::HexNumber));
			this->aKLineMsgTransferDataDataByCommonId2->SetData(6, Char::Parse(s3, NumberStyles::HexNumber));
			bool flag10 = !MainForm::sendRequestKLine(this->aKLineMsgTransferDataDataByCommonId2, iso14230RecvObj, false);
			if (flag10) {
			}
			Array<char>* aMsg6 = MainForm::StringToByteArray(new String("83 00"));
			bool flag11 = !MainForm::sendRequestKLine(aMsg6, iso14230RecvObj, false);
			if (flag11) {
			}
			bool flag12 = !MainForm::sendRequestKLine(this->aKLineMsgAccessTimingParameters2, iso14230RecvObj, false);
			if (flag12) {
			}
			Array<char>* aMsg7 = MainForm::StringToByteArray(new String("31 01"));
			bool flag13 = !MainForm::sendRequestKLineWaitEndless(MainForm::UnitAddress, aMsg7, iso14230RecvObj, false);
			if (flag13) {
			}
			bool flag14 = !MainForm::sendRequestKLine(aMsg, iso14230RecvObj, true);
			if (flag14) {
			}
			bool flag15 = !MainForm::sendRequestKLine(this->aKLineMsgRequestDownload, iso14230RecvObj, false);
			if (flag15) {
			}
			this->ClearText();
			char b = 62;
			this->ClearText();
			int num = 0;
			MainForm::ECUTYPE eCUTYPE = MainForm::g_ECUSelected;
			MainForm::ECUTYPE eCUTYPE2 = eCUTYPE;
			int num2;
			if (eCUTYPE2 != MainForm::ECUTYPE::MC9S12DJ128) {
				num2 = 245760;
			}
			else {
				num2 = 114688;
			}
			char b2 = 0;
			int tickCount = Environment::TickCount;
			while (true) {
				bool flag16 = (num + (int)(b)) > num2;
				if (flag16) {
					b = (char)(num2 - num);
				}
				Array<char>* array = new Array<char>((int)(b + 1));
				array->SetData(0, 54);
				Array::Copy(this->g_Data, num, array, 1, (int)(b));
				bool flag17 = MainForm::sendRequestKLine(array, iso14230RecvObj, false);
				if (!flag17) {
					break;
				}
				num += (int)(b);
				bool flag18 = b2 += 1 == 5;
				if (flag18) {
					b2 = 0;
					Thread::Sleep(100);
					bool flag19 = !MainForm::sendRequestKLine(aMsg, iso14230RecvObj, true);
					if (flag19) {
					}
				}
				char b3 = (char)(((double)(num) / (double)(num2)) * 100.0);
				this->SetProgress(b3 + 1);
				this->ClearText();
				double num3 = (double)(num);
				int num4 = ((Environment::TickCount - tickCount) / 1000) % 60;
				int num5 = (((Environment::TickCount - tickCount) / 1000) / 60) % 60;
				double num6 = (num3 / (double)((Environment::TickCount - tickCount) / 1000)) / 1024.0;
				Array<String>* expr_3FF = new Array<String>(12);
				expr_3FF->SetData(0, new String("Writing: "));
				expr_3FF->SetData(1, new String(num3 / 1024.0));
				expr_3FF->SetData(2, new String(" KB / "));
				expr_3FF->SetData(3, new String((double)(num2) / 1024.0));
				expr_3FF->SetData(4, new String(" KB ("));
				expr_3FF->SetData(5, b3->ToString(new String("F2")));
				expr_3FF->SetData(6, new String("%) | Speed: "));
				expr_3FF->SetData(7, num6->ToString(new String("0.00")));
				expr_3FF->SetData(8, new String(" KB/s | Time lapse "));
				expr_3FF->SetData(9, num5->ToString(new String("D2")));
				expr_3FF->SetData(10, new String(":"));
				expr_3FF->SetData(11, num4->ToString(new String("D2")));
				this->SetText(String::Concat(expr_3FF));
				if (num >= num2) {
					goto Block_14;
				}
			}
			MainForm::g_sErrorMessage = new String("Writing sequence error!");
			result = false;
			return result;
			Block_14:
			Array<char>* aMsg8 = MainForm::StringToByteArray(new String("37"));
			bool flag20 = !MainForm::sendRequestKLine(aMsg8, iso14230RecvObj, false);
			if (flag20) {
			}
			bool flag21 = !MainForm::sendRequestKLineWaitEndless(MainForm::UnitAddress, this->aKLineMsgStartRoutineByLocalId3, iso14230RecvObj, false);
			if (flag21) {
			}
			bool flag22 = !MainForm::sendRequestKLine(aMsg, iso14230RecvObj, true);
			if (flag22) {
			}
			Array<char>* aMsg9 = MainForm::StringToByteArray(new String("2E F1 EF 00 00"));
			bool flag23 = !MainForm::sendRequestKLine(aMsg9, iso14230RecvObj, false);
			if (flag23) {
			}
			bool flag24 = !MainForm::sendRequestKLine(aMsg, iso14230RecvObj, true);
			if (flag24) {
			}
			Array<char>* aMsg10 = MainForm::StringToByteArray(new String("11"));
			bool flag25 = !MainForm::sendRequestKLine(aMsg10, iso14230RecvObj, false);
			if (flag25) {
			}
			MainForm::g_sErrorMessage = new String("Writing FLASH succesfull | Please Restart ECU!");
		}
		catch (Exception* ex) {
			StackTrace* stackTrace = new StackTrace(ex, true);
			StackFrame* frame = stackTrace->GetFrame(stackTrace->FrameCount - 1);
			MessageBox::Show(((*(new String("Error, KlineWriteFlash10400 , line ")) + new String(frame->GetFileLineNumber())) + *(new String(": "))) + *(ex->Message));
		}
		result = true;
		return result;
	}
	bool MainForm::KLineWriteProcess(BackgroundWorker* worker, DoWorkEventArgs* e)
	{
		bool cancellationPending = worker->CancellationPending;
		bool result;
		if (cancellationPending) {
			this->ClearText();
			result = false;
		}
		else {
			bool flag = MainForm::g_J2534Device > -1;
			if (flag) {
				try {
					bool flag2 = MainForm::API == null;
					if (flag2) {
						MainForm::API = APIFactory::GetAPI(APIFactory::GetAPIinfo()->ElementAt(MainForm::g_J2534Device)->Filename);
					}
					bool flag3 = MainForm::Device == null;
					if (flag3) {
						MainForm::Device = MainForm::API->GetDevice(new String(""));
					}
				}
				catch (Exception* ex) {
					Console::WriteLine(ex->Message);
				}
			}
			MainForm::ECUTYPE eCUTYPE = MainForm::g_ECUSelected;
			MainForm::ECUTYPE eCUTYPE2 = eCUTYPE;
			if (eCUTYPE2 != MainForm::ECUTYPE::MC9S12DJ128) {
				this->SetText(new String("Not available."));
				this->btnLoad->Enabled = false;
				result = false;
			}
			else {
				result = this->VPWJ(worker, e);
			}
		}
		return result;
	}
	bool MainForm::CANWriteProcess(BackgroundWorker* worker, DoWorkEventArgs* e)
	{
		bool cancellationPending = worker->CancellationPending;
		bool result;
		if (cancellationPending) {
			this->ClearText();
			result = false;
		}
		else {
			bool flag = MainForm::g_J2534Device > -1;
			if (flag) {
				try {
					bool flag2 = MainForm::API == null;
					if (flag2) {
						MainForm::API = APIFactory::GetAPI(APIFactory::GetAPIinfo()->ElementAt(MainForm::g_J2534Device)->Filename);
					}
					bool flag3 = MainForm::Device == null;
					if (flag3) {
						MainForm::Device = MainForm::API->GetDevice(new String(""));
					}
				}
				catch (Exception* ex) {
					Console::WriteLine(ex->Message);
				}
			}
			MainForm::ECUTYPE eCUTYPE = MainForm::g_ECUSelected;
			MainForm::ECUTYPE eCUTYPE2 = eCUTYPE;
			if (eCUTYPE2 != MainForm::ECUTYPE::MC9S12XEP768) {
				if (eCUTYPE2 != MainForm::ECUTYPE::TC265_MT21M) {
					this->SetText(new String("Not available."));
					this->btnLoad->Enabled = false;
					result = false;
				}
				else {
					result = this->CANWriteFlashTC265D(worker, e);
				}
			}
			else {
				result = this->CANWriteFlashXEP768(worker, e);
			}
		}
		return result;
	}
	void MainForm::backgroundWorker_DoWorkWriteCAN(Object* sender, DoWorkEventArgs* e)
	{
		BackgroundWorker* worker = as_cast<BackgroundWorker*>(sender);
		this->SetText(new String("\r\n"));
		e->Result = BOX<bool>(this->CANWriteProcess(worker, e));
	}
	void MainForm::backgroundWorker_DoWorkWriteCANCompleted(Object* sender, RunWorkerCompletedEventArgs* e)
	{
		bool flag = UNBOX<bool>(e->Result);
		this->ClearText();
		this->SetText(MainForm::g_sErrorMessage);
		this->btnLoad->Enabled = true;
		this->btnLoad->Enabled = true;
		this->tbFilelocation->Enabled = true;
		this->textBox1->Enabled = true;
		this->comboBox1->Enabled = true;
		this->comboBox2->Enabled = true;
		this->progressBar1->Visible = false;
	}
	void MainForm::backgroundWorker_DoWorkWriteKLine(Object* sender, DoWorkEventArgs* e)
	{
		BackgroundWorker* worker = as_cast<BackgroundWorker*>(sender);
		this->SetText(new String("\r\n"));
		e->Result = BOX<bool>(this->KLineWriteProcess(worker, e));
	}
	void MainForm::backgroundWorker_DoWorkWriteKLineCompleted(Object* sender, RunWorkerCompletedEventArgs* e)
	{
		bool flag = UNBOX<bool>(e->Result);
		this->ClearText();
		this->SetText(MainForm::g_sErrorMessage);
		this->btnLoad->Enabled = true;
		this->btnLoad->Enabled = true;
		this->tbFilelocation->Enabled = true;
		this->textBox1->Enabled = true;
		this->comboBox1->Enabled = true;
		this->comboBox2->Enabled = true;
		this->progressBar1->Visible = false;
	}
	void MainForm::comboBox1_SelectedIndexChanged(Object* sender, EventArgs* e)
	{
		bool flag = this->comboBox1->SelectedIndex >= 0;
		if (flag) {
			MainForm::g_J2534Device = this->comboBox1->SelectedIndex;
		}
	}
	void MainForm::btnWriteFlash_Click(Object* sender, EventArgs* e)
	{
		this->progressBar1->Value = 1;
		bool flag = (MainForm::g_ECUSelected == MainForm::ECUTYPE::TC265_MT21M) || (MainForm::g_ECUSelected == MainForm::ECUTYPE::MC9S12XEP768);
		if (flag) {
			bool flag2 = !this->backgroundWorkerWriteCAN->IsBusy;
			if (flag2) {
				this->txtLog->Enabled = false;
				this->tbFilelocation->Enabled = false;
				this->btnWriteFlash->Enabled = false;
				this->btnLoad->Enabled = false;
				this->textBox1->Enabled = false;
				this->comboBox1->Enabled = false;
				this->comboBox2->Enabled = false;
				this->progressBar1->Visible = true;
				this->backgroundWorkerWriteCAN->RunWorkerAsync();
			}
		}
		else {
			bool flag3 = !this->backgroundWorkerWriteKLine->IsBusy;
			if (flag3) {
				this->txtLog->Enabled = false;
				this->tbFilelocation->Enabled = false;
				this->btnWriteFlash->Enabled = false;
				this->btnLoad->Enabled = false;
				this->textBox1->Enabled = false;
				this->comboBox1->Enabled = false;
				this->comboBox2->Enabled = false;
				this->progressBar1->Visible = true;
				this->backgroundWorkerWriteKLine->RunWorkerAsync();
			}
		}
	}
	uint MainForm::CalculateCRC32(Array<char>* data, long startAddress, long endAddress)
	{
		uint num = 4294967295u;
		for (long num2 = startAddress; num2 <= endAddress; num2 += 1L) {
			char b = data->GetData((int)(/*ERROR: Cannot translate: System.NotImplementedException: The method or operation is not implemented.. Node: ICSharpCode.NRefactory.CSharp.CheckedExpression*/));
			num = num ^ (uint)(b);
			for (int i = 0; i < 8; i += 1) {
				bool flag = (num & 1u) > 0u;
				num >>= 1;
				bool flag2 = flag;
				if (flag2) {
					num = num ^ 3988292384u;
				}
			}
		}
		return !num;
	}
	ushort MainForm::Get16SUM(int startPos, int endPos)
	{
		ushort num = 0;
		int num2 = startPos;
		while ((num2 + 2) <= endPos) {
			num += (ushort)(((int)(this->g_Data->GetData(num2)) << 8) | (int)(this->g_Data->GetData(num2 + 1)));
			num2 += 2;
		}
		return num;
	}
	bool MainForm::FixCRC()
	{
		bool flag = MainForm::g_ECUSelected == MainForm::ECUTYPE::MC9S12XEP768;
		bool result;
		if (flag) {
			bool flag2 = this->g_Data->Length != 786432;
			if (flag2) {
				MainForm::g_sErrorMessage = new String("Wrong file size?");
				result = false;
				return result;
			}
			ushort num = this->Get16SUM(737282, 753663);
			ushort num2 = (ushort)(((int)(this->g_Data->GetData(737280)) << 8) | (int)(this->g_Data->GetData(737281)));
			bool flag3 = num2 == num;
			if (flag3) {
				this->SetText(new String("Checksum OK"));
			}
			else {
				this->SetText(((*(new String("Checksum wrong (")) + num2->ToString(new String("X4"))) + *(new String(") Correcting to "))) + num->ToString(new String("X4")));
				this->g_Data->SetData(737280, (char)((num >> 8) & 255));
				this->g_Data->SetData(737281, (char)(num & 255));
			}
		}
		else {
			bool flag4 = MainForm::g_ECUSelected == MainForm::ECUTYPE::TC265_MT21M;
			if (!flag4) {
				MainForm::g_sErrorMessage = new String("Unknown Ecutype?");
				result = false;
				return result;
			}
			bool flag5 = this->g_Data->Length != 2621440;
			if (flag5) {
				MainForm::g_sErrorMessage = new String("Wrong file size?");
				result = false;
				return result;
			}
			bool flag6 = false;
			String* text = new String("");
			Array<MainForm::ChecksumArea>* array = this->checksumAreas;
			for (int i = 0; i < array->Length; i += 1) {
				MainForm::ChecksumArea* checksumArea = array->GetData(i);
				bool flag7 = (checksumArea.EndAddress >= (long)(this->g_Data->Length)) || (checksumArea.StoredAddress >= (long)(this->g_Data->Length));
				if (flag7) {
					text = (*text + *(checksumArea.AreaName)) + *(new String(": Tidak sesuai dengan ukuran yang diperlukan.\n"));
				}
				else {
					uint num3 = this->CalculateCRC32(this->g_Data, checksumArea.StartAddress, checksumArea.EndAddress);
					uint num4 = this->ReadBigEndianUInt32(this->g_Data, (int)(checksumArea.StoredAddress));
					bool flag8 = num3 == num4;
					if (flag8) {
						text = (*text + *(checksumArea.AreaName)) + *(new String(": OK, "));
					}
					else {
						text = (*text + *(checksumArea.AreaName)) + *(new String(": Checksum Incorrect, Correcting Checksum...\n"));
						this->WriteBigEndianUInt32(this->g_Data, (int)(checksumArea.StoredAddress), num3);
						flag6 = true;
					}
				}
			}
			this->SetText(text);
			bool flag9 = flag6;
			if (flag9) {
				this->SetText(new String("Checksum has been corrected for incorrect areas"));
			}
		}
		result = true;
		return result;
	}
	bool MainForm::OpenJ2534Device()
	{
		bool flag = MainForm::g_J2534Device > -1;
		bool result;
		if (flag) {
			try {
				bool flag2 = MainForm::API == null;
				if (flag2) {
					MainForm::API = APIFactory::GetAPI(APIFactory::GetAPIinfo()->ElementAt(MainForm::g_J2534Device)->Filename);
				}
				bool flag3 = MainForm::Device == null;
				if (flag3) {
					MainForm::Device = MainForm::API->GetDevice(new String(""));
				}
				result = true;
				return result;
			}
			catch (Exception* ex) {
				MainForm::g_sErrorMessage = ex->Message;
				Console::WriteLine(ex->Message);
				result = false;
				return result;
			}
		}
		MainForm::g_sErrorMessage = new String("No J2534 Device selected!");
		result = false;
		return result;
	}
	void MainForm::btnLoad_Click(Object* sender, EventArgs* e)
	{
		OpenFileDialog* openFileDialog = new OpenFileDialog();
		openFileDialog->DereferenceLinks = false;
		openFileDialog->AutoUpgradeEnabled = false;
		openFileDialog->Title = new String("Open Bin File");
		openFileDialog->Filter = new String("BIN files|*.bin");
		this->g_Data = null;
		bool flag = openFileDialog->ShowDialog() == DialogResult::OK;
		if (flag) {
			String* fileName = openFileDialog->FileName;
			try {
				this->g_Data = File::ReadAllBytes(fileName);
				bool flag2 = this->g_Data->Length > 0;
				if (flag2) {
					this->btnWriteFlash->Enabled = true;
					MainForm::binSize = this->g_Data->Length;
					MainForm::binBytes = this->g_Data;
					this->GetFlashTypeFromBinSize();
					this->tbFilelocation->Text = fileName;
				}
			}
			catch (Exception* ex) {
				Console::WriteLine(ex->Message);
				MessageBox::Show(ex->Message, new String("Error"), MessageBoxButtons::OK);
			}
		}
	}
	void MainForm::comboBox2_SelectedIndexChanged(Object* sender, EventArgs* e)
	{
		bool flag = this->comboBox2->SelectedIndex < 0;
		if (!flag) {
			MainForm::g_ECUSelected = (MainForm::ECUTYPE)(this->comboBox2->SelectedIndex);
			bool flag2 = MainForm::g_ECUSelected >= MainForm::ECUTYPE::MC9S12DJ128;
			if (flag2) {
				switch (MainForm::g_ECUSelected) {
					case MainForm::ECUTYPE::MC9S12DJ128:
						this->SetText(new String(""));
						this->btnLoad->Enabled = true;
						this->aKLineMsgTransferDataDataByCommonId1 = MainForm::StringToByteArray(new String("2E F1 98 31 01 05 E2"));
						this->aKLineMsgTransferDataDataByCommonId2 = MainForm::StringToByteArray(new String("2E F1 99 20 23 00 00"));
						this->aKLineMsgAccessTimingParameters2 = MainForm::StringToByteArray(new String("83 03 29 02 6E FF 02"));
						this->aKLineMsgRequestDownload = MainForm::StringToByteArray(new String("34 04 33 7C 00 00 03 C0 00"));
						this->aKLineMsgStartRoutineByLocalId3 = MainForm::StringToByteArray(new String("31 02 33 7C 00 00 03 BC 00"));
						break;

					case MainForm::ECUTYPE::MC9S12XEP768:
						this->SetText(new String(""));
						this->aCANMsgWriteDataByCommonId1 = MainForm::StringToByteArray(new String("2E F1 98 31 01 05 E2"));
						this->aCANMsgWriteDataByCommonId2 = MainForm::StringToByteArray(new String("2E F1 99 20 23 12 02"));
						this->aCANMsgStartRoutineByLocalId1 = MainForm::StringToByteArray(new String("31 01"));
						this->btnLoad->Enabled = true;
						break;

					case MainForm::ECUTYPE::TC265_MT21M:
						this->SetText(new String(""));
						this->aCANMsgWriteDataByCommonId1 = MainForm::StringToByteArray(new String("2E F1 98 31 01 05 E2"));
						this->aCANMsgWriteDataByCommonId2 = MainForm::StringToByteArray(new String("2E F1 99 20 23 12 02"));
						this->aCANMsgStartRoutineByLocalId1 = MainForm::StringToByteArray(new String("31 01"));
						this->btnLoad->Enabled = true;
						break;

					default:
						this->SetText(new String("Not available."));
						this->btnLoad->Enabled = false;
						break;
				}
			}
		}
	}
	void MainForm::btnECUinfo_Click(Object* sender, EventArgs* e)
	{
		MainForm::Iso14230RecvObj* iso14230RecvObj = new MainForm::Iso14230RecvObj();
		bool flag = MainForm::g_J2534Device > -1;
		if (flag) {
			try {
				bool flag2 = MainForm::API == null;
				if (flag2) {
					MainForm::API = APIFactory::GetAPI(APIFactory::GetAPIinfo()->ElementAt(MainForm::g_J2534Device)->Filename);
				}
				bool flag3 = MainForm::Device == null;
				if (flag3) {
					MainForm::Device = MainForm::API->GetDevice(new String(""));
				}
			}
			catch (Exception* ex) {
				Console::WriteLine(ex->Message);
			}
			this->ClearText();
			this->SetECUInfo(new String(""), new String(""), new String(""), new String(""), new String(""), new String(""), new String(""), new String(""), new String(""), new String(""), new String(""), new String(""));
			this->SetText(new String("Reading ECU information, please wait..."));
			bool flag4 = (MainForm::g_ECUSelected == MainForm::ECUTYPE::TC265_MT21M) || (MainForm::g_ECUSelected == MainForm::ECUTYPE::MC9S12XEP768);
			if (flag4) {
				this->ReadECUInfoCAN();
			}
			else {
				this->ReadECUInfoCAN();
				this->ReadECUInfo();
				this->ClearText();
			}
		}
		else {
			MainForm::g_sErrorMessage = new String("No J2534 Device selected!");
		}
	}
	void MainForm::groupBox1_Enter(Object* sender, EventArgs* e)
	{
	}
	bool MainForm::HDXEP768READE2P()
	{
		bool result;
		try {
			MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
			int num = 0;
			Array<char>* array = new Array<char>(4096);
			bool flag = this->ConnectToUnitCAN();
			if (!flag) {
				MainForm::g_sErrorMessage = new String("No answer from ECU!");
				result = false;
				return result;
			}
			Array<char>* aCanMsg = MainForm::StringToByteArray(new String("10 02"));
			bool flag2 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg, iso15765Recv, 1);
			if (flag2) {
			}
			Thread::Sleep(50);
			aCanMsg = MainForm::StringToByteArray(new String("10 03"));
			bool flag3 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg, iso15765Recv, 1);
			if (flag3) {
			}
			Array<char>* expr_88 = new Array<char>(3);
			RuntimeHelpers::InitializeArray(expr_88, fieldof(<PrivateImplementationDetails>::388CD0567C27CCC3231CBABAF96B6A31963F150282848836F1F33B17AF3FC162)->FieldHandle);
			Array<char>* aCanMsg2 = expr_88;
			Array<char>* array2 = new Array<char>(4);
			bool flag4 = false;
			while (!flag4) {
				bool flag5 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg2, iso15765Recv, 1);
				if (flag5) {
					bool flag6 = (iso15765Recv->gete4_Data() != null) && (iso15765Recv->gete4_Data()->Length >= 4);
					if (flag6) {
						flag4 = true;
					}
					else {
						this->SetText(new String("Invalid reply from ECU, retrying..."));
					}
				}
				else {
					this->SetText(new String("Failed to send 22 F1 F4 CAN message, retrying..."));
				}
			}
			bool flag7 = !flag4;
			if (flag7) {
				result = false;
				return result;
			}
			Array::Copy(iso15765Recv->gete4_Data(), 3, array2, 0, 4);
			Array<char>* expr_135 = new Array<char>(2);
			expr_135->SetData(0, 39);
			expr_135->SetData(1, 1);
			Array<char>* aCanMsg3 = expr_135;
			Array<char>* expr_146 = new Array<char>(4);
			expr_146->SetData(0, 39);
			expr_146->SetData(1, 2);
			Array<char>* array3 = expr_146;
			flag4 = false;
			while (!flag4) {
				bool flag8 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg3, iso15765Recv, 1);
				if (flag8) {
					bool flag9 = (iso15765Recv->gete4_Data() != null) && (iso15765Recv->gete4_Data()->Length >= 4);
					if (flag9) {
						flag4 = true;
					}
					else {
						this->SetText(new String("Invalid reply from ECU, retrying..."));
					}
				}
				else {
					this->SetText(new String("Failed to send Seed Request CAN message, retrying..."));
				}
			}
			bool flag10 = !flag4;
			if (flag10) {
				result = false;
				return result;
			}
			Array<char>* array4 = new Array<char>(2);
			Array<char>* sourceArray = new Array<char>(2);
			Array::Copy(iso15765Recv->gete4_Data(), 2, array4, 0, 2);
			bool flag11 = this->SecurityAccess1(array4, array2, sourceArray);
			if (!flag11) {
				this->SetText(new String("Security Access failed during key generation."));
				result = false;
				return result;
			}
			Array::Copy(sourceArray, 0, array3, 2, 2);
			bool flag12 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, array3, iso15765Recv, 1);
			if (flag12) {
				this->SetText(new String("Security Access Succeeded... Please wait"));
			}
			else {
				this->SetText(new String("Security Access failed."));
			}
			Thread::Sleep(800);
			Array<char>* expr_26F = new Array<char>(2);
			expr_26F->SetData(0, 39);
			expr_26F->SetData(1, 1);
			Array<char>* aCanMsg4 = expr_26F;
			Array<char>* expr_280 = new Array<char>(4);
			expr_280->SetData(0, 39);
			expr_280->SetData(1, 2);
			Array<char>* array5 = expr_280;
			flag4 = false;
			while (!flag4) {
				bool flag13 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg4, iso15765Recv, 1);
				if (flag13) {
					bool flag14 = (iso15765Recv->gete4_Data() != null) && (iso15765Recv->gete4_Data()->Length >= 4);
					if (flag14) {
						flag4 = true;
					}
					else {
						this->SetText(new String("Invalid reply from ECU, retrying..."));
					}
				}
				else {
					this->SetText(new String("Failed to send Seed Request CAN message, retrying..."));
				}
			}
			bool flag15 = !flag4;
			if (flag15) {
				result = false;
				return result;
			}
			Array<char>* array6 = new Array<char>(2);
			Array<char>* array7 = new Array<char>(2);
			Array::Copy(iso15765Recv->gete4_Data(), 2, array4, 0, 2);
			this->harley_calc_access_key_1(array4, sourceArray);
			Array::Copy(sourceArray, 0, array5, 2, 2);
			bool flag16 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, array5, iso15765Recv, 1);
			if (!flag16) {
				this->SetText(new String("Security Access failed."));
				result = false;
				return result;
			}
			this->SetText(new String("Security Access Succeeded... Please wait"));
			Thread::Sleep(50);
			Array<char>* aCanMsg5 = MainForm::StringToByteArray(new String("34 00 44 00 00 80 00 00 00 04 20"));
			bool flag17 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg5, iso15765Recv, 1);
			if (flag17) {
			}
			MainForm::Channel->DefaultTxTimeout = 500;
			Array<char>* aCanMsg6 = MainForm::StringToByteArray(new String("36 01 96 03 00 07 00 00 80 00 00 00 84 1F 23 E1 F5 88 00 09 07 E0 00 01 02 03 18 20 01 4E CD 03 76 DC 23 5D 17 5C 19 87 C7 20 09 CC 30 00 5C 17 87 C7 5C 19 5C 1B 5C 1D 18 0C 01 46 01 4A CD 01 70 CC FD 00 6C 40 86 08 6C 4C DC 17 6C 44 DC 19 6C 46 DC 1B 6C 48 DC 1D 6C 4A B6 01 4A 18 0E 7C 01 46 3D 15 FA 02 EF 1E 01 44 01 14 DE 13 08 5E 13 26 F0 96 12 42 5A 12 81 46 23 E7 C6 F4 20 54 CE 01 60 EC 00 8C FB E0 27 0B 8C FC 00 27 06 1C 01 44 01 20 CE 87 C7 5A 12 5C 13 EC 0A 5C 1D EC 08 5C 1B EC 06 5C 19 ED 04 1C 01 44 01 5D 17 B7 E4 C1 3E 26 08 81 02 25 04 81 07 23 A6 B7 E4 3D 07 A1 81 36 18 26 00 B9 5B 23 B7 64 84 F0 81 10 27 04 C6 12 20 39 B7 64 84 0F 04 44 05 8C 08 02 23 04 C6 13 20 29 83 00 06 5C 1F DD 21 19 44 5D 21 DD 15 DC 1B 6C 71 DC 1D 6C 71 5D 15 15 F9 2B 86 21 5A 25 15 F9 5C B7 E4 91 25 27 06 C6 73 18 20 02 2C 42 84 EF 5A 25 B7 E4 DC 1F 83 00 07 25 24 5C 1F DD 21 19 47 5D 21 DD 15 96 18 6A 70 DC 19 6C 71 DC 1B 6C 71 DC 1D 6C 71 5D 15 DC 1F 26 C3 96 21 20 1A CE 10 18 DD 15 CB 07 37 DC 21 18 0A 30 70 C3 00 01 63 80 26 F5 5D 15 5C 21 33 81 08 24 08 15 FA FE B7 18 20 FF 55 3D CE 10 07 CD 00 1F 87 C7 6C 31 04 36 FB 15 FA FE E6 20 1C 81 23 C6 24 20 3A B6 00 9A 81 5A 24 04 C6 93 20 2D DC 1A 8C 00 44 27 04 C6 31 20 22 B7 64 81 04 26 08 C1 23 27 0C C6 11 20 02 C6 12 86 34 18 20 01 90 87 87 87 87 87 87 87 87 87 87 87 87 87 87 87 87 87 87 DE 1A EC 00 5C 19 EC 02 5C 1B CC 05 63 5C 17 87 15 FA FE 5F 20 A0 87 5D 15 87 C7 5C 21 15 FA FE DC FC 14 52 5C 08 F6 14 57 5B 11 5B 0C FC 14 58 5C 0F 5C 0A FC 14 5C 8C F7 FF 23 03 CC F7 FF 5C 0D FE 14 54 8E 00 02 26 1A 4C 07 20 C6 F2 B6 F7 FF 81 55 26 0A FE 14 62 BE F7 F5 27 1E C6 F0 18 20 01 19 C6 F5 04 35 F7 C6 F1 FE 14 5E CD F8 00 AE 4C 26 EB FE 14 60 AE 4E 26 E4 DE 0D 1A E2 FC 01 C6 7F 15 FA 01 43 DE 0F D6 11 15 FA 01 16 97 18 26 00 DA CD 14 52 DE 0A D6 0C 15 FA 01 47 CD 14 52 DE 0A D6 0C 15 FA 01 9E 97 18 26 00 BF D6 0C DE 0A 1A E2 08 00 18 97 26 07 52 C1 7F 22 58 5B 0C 5E 0A C1 7F 25 04 9E 0D 24 4C C6 93 86 5A B1 00 9A 25 0D CE 09 C4 04 35 FD B1 00 9A 18 24 FF 7D C6 F6 B6 01 44 84 28 18 26 FF 72 15 FA FD 6A DC 15 B7 45 80 08 5C 15 B7 46 83 14 51 49 27 07 18 02 2E 6E 04 34 F9 DC 21 80 08 25 02 5C 21 15 FA FD E9 18 20 FF 7C DD 0F 02 02 5D 0A D6 11 5B 0C 7B 00 10 DE 08 4F 07 30 10 9D 0D 22 08 18 E6 40 1A E5 04 B6 F4 B7 54 20 2C 18 E6 40 1A E5 04 B6 F8 07 4E 96 0C 42 5A 0C 7A 00 10 81 7F 25 EA 9D 0D 22 08 18 E6 40 1A E5 04 B6 F4 B7 54 18 FE 40 00 5E 08 07 37 04 44 1D C6 F7 20 02 C6 72 37 DE 0D 1A E2 FC 01 C6 7F 07 4F 33 86 36 CD 03 7F 15 FA FC DB 20 08 86 86 5A 24 15 FA FC CC 07 02 20 FE 18 0B 55 00 3F 18 0B AA 00 3F 3D D0 08 82 00 9B 08 3D 4F 07 30 02 20 0F 07 1D 1A E2 04 00 18 97 26 F6 52 C1 7F 25 F1 9E 0D 24 0A 07 0A 1A E2 04 00 18 97 26 F2 87 3D 1D 01 02 07 86 0A 7C 01 0A 1C 01 02 01 7E 01 0A 1C 01 06 80 07 B3 1F 01 06 80 FB 3D C1 7F 24 0D 07 1D 19 48 1A 08 8D 1C 52 25 F5 20 11 8D 1C 52 24 0C 9E 0D 24 08 07 07 19 48 1A 08 20 EF 3D 1D 01 02 07 86 06 7C 01 0A 1C 01 02 01 7E 01 0A 86 02 7A 01 02 18 05 40 01 0A 72 01 02 18 05 42 01 0A 72 01 02 18 05 44 01 0A 72 01 02 18 05 46 01 0A 1C 01 06 80 15 F9 51 1F 01 06 80 FB 3D 7B 00 10 CC 04 00 3B 18 EC 31 AC 71 3A 26 05 04 34 F4 20 02 86 C0 3D"));
			bool flag18 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg6, iso15765Recv, 1);
			if (flag18) {
			}
			String* text = new String("");
			Array<char>* array8 = MainForm::StringToByteArray(new String("23 00 00 00"));
			int num2 = 4;
			int num3 = 2048;
			int num4 = 4096;
			int num5 = num3;
			int num6 = num4 - num3;
			int tickCount = Environment::TickCount;
			this->progressBar1->Minimum = 0;
			this->progressBar1->Maximum = num6;
			array = new Array<char>(4096);
			for (int i = 0; i < num6; i += num2) {
				array8->SetData(1, (char)(num5 >> 16));
				array8->SetData(2, (char)(num5 >> 8));
				array8->SetData(3, (char)(num5));
				bool flag19 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, array8, iso15765Recv, 1);
				if (flag19) {
					bool flag20 = iso15765Recv->gete4_Data()->GetData(0) == 99;
					if (flag20) {
						Array::Copy(iso15765Recv->gete4_Data(), 1, array, num5, iso15765Recv->gete4_Data()->Length - 1);
						num += *iso15765Recv->e4_Data->Length - 1;
						double num7 = (double)(num);
						int num8 = Environment::TickCount - tickCount;
						double num9 = (num7 / (double)(num6)) * 100.0;
						int num10 = (num8 / 1000) % 60;
						int num11 = (num8 / 60000) % 60;
						double num12 = (num7 / ((double)(num8) / 100000.0)) / 1024.0;
						this->progressBar1->Value = i + num2;
						this->SetProgress((char)(num9 + 1.0));
						this->ClearText();
						String* arg_592_0 = new String("Reading: {0:F2} KB / {1:F2} KB ({2:F2}%) | Speed: {3:0.00} KB/s | Time Elapsed: {4:D2}:{5:D2}");
						Array<Object>* expr_541 = new Array<Object>(6);
						expr_541->SetData(0, BOX<double>(num7 / 1024.0));
						expr_541->SetData(1, BOX<double>((double)(num6) / 1024.0));
						expr_541->SetData(2, BOX<double>(num9));
						expr_541->SetData(3, BOX<double>(num12));
						expr_541->SetData(4, BOX<int>(num11));
						expr_541->SetData(5, BOX<int>(num10));
						this->SetText(String::Format(arg_592_0, expr_541));
						Application::DoEvents();
					}
				}
				num5 += num2;
			}
			Array<char>* aCanMsg7 = MainForm::StringToByteArray(new String("11 01"));
			bool flag21 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg7, iso15765Recv, 1);
			if (flag21) {
			}
			this->SaveDump(array, text);
			MessageBox::Show(new String("Read Flash Successfull, Please Restart ECU"), new String("Notice"), MessageBoxButtons::OK, MessageBoxIcon::Asterisk);
		}
		catch (Exception* ex) {
			StackTrace* stackTrace = new StackTrace(ex, true);
			StackFrame* frame = stackTrace->GetFrame(stackTrace->FrameCount - 1);
			MessageBox::Show(((*(new String("Error, gFlash , line ")) + new String(frame->GetFileLineNumber())) + *(new String(": "))) + *(ex->Message));
			result = false;
			return result;
		}
		result = true;
		return result;
	}
	bool MainForm::HDTC265DREADE2P()
	{
		bool result;
		try {
			MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
			int num = 0;
			Array<char>* array = new Array<char>(98304);
			bool flag = this->ConnectToUnitCAN();
			if (!flag) {
				MessageBox::Show(new String("No answer from ECU!"), new String("Notice"), MessageBoxButtons::OK, MessageBoxIcon::Hand);
				this->SetText(new String("No answer from ECU!"));
				result = false;
				return result;
			}
			Array<char>* aCanMsg = MainForm::StringToByteArray(new String("10 03"));
			MainForm::sendRequestCAN(2015, aCanMsg, iso15765Recv, 1);
			Thread::Sleep(20);
			Array<char>* aCanMsg2 = MainForm::StringToByteArray(new String("8502"));
			bool flag2 = MainForm::sendRequestCAN(2015, aCanMsg2, iso15765Recv, 1);
			if (flag2) {
			}
			Array<char>* aCanMsg3 = MainForm::StringToByteArray(new String("280303"));
			bool flag3 = MainForm::sendRequestCAN(2015, aCanMsg3, iso15765Recv, 1);
			if (flag3) {
			}
			Array<char>* aCanMsg4 = MainForm::StringToByteArray(new String("10 02"));
			bool flag4 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg4, iso15765Recv, 1);
			if (flag4) {
			}
			Array<char>* expr_DE = new Array<char>(2);
			expr_DE->SetData(0, 39);
			expr_DE->SetData(1, 1);
			Array<char>* aCanMsg5 = expr_DE;
			Array<char>* expr_F0 = new Array<char>(10);
			expr_F0->SetData(0, 39);
			expr_F0->SetData(1, 2);
			Array<char>* array2 = expr_F0;
			bool flag5 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg5, iso15765Recv, 1);
			if (flag5) {
				Array<char>* array3 = new Array<char>(8);
				Array<char>* sourceArray = new Array<char>(8);
				Array::Copy(iso15765Recv->gete4_Data(), 2, array3, 0, 8);
				bool flag6 = this->GenerateKeyTC265(array3, sourceArray);
				if (flag6) {
					Array::Copy(sourceArray, 0, array2, 2, 8);
					bool flag7 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, array2, iso15765Recv, 1);
					if (!flag7) {
						this->SetText(new String("Security access failed."));
						result = false;
						return result;
					}
					this->SetText(new String("Security access succeeded."));
				}
			}
			Array<char>* aCanMsg6 = MainForm::StringToByteArray(new String("22 F1 99"));
			bool flag8 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg6, iso15765Recv, 1);
			if (flag8) {
			}
			List_T<char>* list = new List_T<char>();
			List_T<char>* arg_1C9_0 = *list;
			Array<char>* expr_1BE = new Array<char>(3);
			RuntimeHelpers::InitializeArray(expr_1BE, fieldof(<PrivateImplementationDetails>::A8E38C7DB094115750BB5571C52B1C211F160805BD26241703DEF1576C811F82)->FieldHandle);
			arg_1C9_0->AddRange(expr_1BE);
			Array<char>* array4 = new Array<char>(iso15765Recv->gete4_Data()->Length - 3);
			Array::Copy(iso15765Recv->gete4_Data(), 3, array4, 0, iso15765Recv->gete4_Data()->Length - 3);
			list->AddRange(array4);
			Array<char>* aCanMsg7 = list->ToArray();
			bool flag9 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg7, iso15765Recv, 1);
			if (flag9) {
			}
			Array<char>* aCanMsg8 = MainForm::StringToByteArray(new String("34 00 44 70 10 00 00 00 00 0A 5C"));
			bool flag10 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg8, iso15765Recv, 1);
			if (flag10) {
			}
			Thread::Sleep(50);
			this->aCallCanWriteKernelTC265();
			Thread::Sleep(50);
			Array<char>* aCanMsg9 = MainForm::StringToByteArray(new String("37"));
			bool flag11 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg9, iso15765Recv, 1);
			if (flag11) {
			}
			Array<char>* aCanMsg10 = MainForm::StringToByteArray(new String("31 01 40 02 01"));
			bool flag12 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg10, iso15765Recv, 1);
			if (flag12) {
			}
			String* text = new String("");
			Array<char>* array5 = MainForm::StringToByteArray(new String("23 24 7F 00 00 00 04 00"));
			int num2 = 1024;
			int num3 = 0;
			int num4 = 98304;
			int num5 = num4 - num3;
			int tickCount = Environment::TickCount;
			this->progressBar1->Minimum = 0;
			this->progressBar1->Maximum = num5;
			array = new Array<char>(num5);
			for (int i = 0; i < num5; i += num2) {
				array5->SetData(3, (char)(i >> 16));
				array5->SetData(4, (char)(i >> 8));
				bool flag13 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, array5, iso15765Recv, 1);
				if (flag13) {
					bool flag14 = iso15765Recv->gete4_Data()->GetData(0) == 99;
					if (flag14) {
						Array::Copy(iso15765Recv->gete4_Data(), 1, array, num, iso15765Recv->gete4_Data()->Length - 1);
						num += *iso15765Recv->e4_Data->Length - 1;
						double num6 = (double)(num);
						int num7 = Environment::TickCount - tickCount;
						double num8 = (num6 / (double)(num5)) * 100.0;
						int num9 = (num7 / 1000) % 60;
						int num10 = (num7 / 60000) % 60;
						double num11 = (num6 / ((double)(num7) / 100000.0)) / 1024.0;
						this->progressBar1->Value = i + num2;
						this->SetProgress((char)(num8 + 1.0));
						this->ClearText();
						String* arg_44A_0 = new String("Reading: {0:F2} KB / {1:F2} KB ({2:F2}%) | Speed: {3:0.00} KB/s | Time Elapsed: {4:D2}:{5:D2}");
						Array<Object>* expr_3F9 = new Array<Object>(6);
						expr_3F9->SetData(0, BOX<double>(num6 / 1024.0));
						expr_3F9->SetData(1, BOX<double>((double)(num5) / 1024.0));
						expr_3F9->SetData(2, BOX<double>(num8));
						expr_3F9->SetData(3, BOX<double>(num11));
						expr_3F9->SetData(4, BOX<int>(num10));
						expr_3F9->SetData(5, BOX<int>(num9));
						this->SetText(String::Format(arg_44A_0, expr_3F9));
						Application::DoEvents();
					}
				}
			}
			Array<char>* aCanMsg11 = MainForm::StringToByteArray(new String("11 01"));
			bool flag15 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg11, iso15765Recv, 1);
			if (flag15) {
			}
			MessageBox::Show(new String("Read Flash Successfull, Please Restart ECU"), new String("Notice"), MessageBoxButtons::OK, MessageBoxIcon::Asterisk);
			this->SaveDump(array, text);
		}
		catch (Exception* ex) {
			StackTrace* stackTrace = new StackTrace(ex, true);
			StackFrame* frame = stackTrace->GetFrame(stackTrace->FrameCount - 1);
			MessageBox::Show(((*(new String("Error, gFlash , line ")) + new String(frame->GetFileLineNumber())) + *(new String(": "))) + *(ex->Message));
			result = false;
			return result;
		}
		result = true;
		return result;
	}
	bool MainForm::HDTC265DREAD()
	{
		bool result;
		try {
			MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
			int num = 0;
			Array<char>* array = new Array<char>(2621440);
			bool flag = this->ConnectToUnitCAN();
			if (!flag) {
				MessageBox::Show(new String("No answer from ECU!"), new String("Notice"), MessageBoxButtons::OK, MessageBoxIcon::Hand);
				this->SetText(new String("No answer from ECU!"));
				result = false;
				return result;
			}
			Array<char>* aCanMsg = MainForm::StringToByteArray(new String("10 03"));
			MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg, iso15765Recv, 1);
			Thread::Sleep(10);
			Array<char>* aCanMsg2 = MainForm::StringToByteArray(new String("8502"));
			bool flag2 = MainForm::sendRequestCAN(2015, aCanMsg2, iso15765Recv, 1);
			if (flag2) {
			}
			Array<char>* aCanMsg3 = MainForm::StringToByteArray(new String("280303"));
			bool flag3 = MainForm::sendRequestCAN(2015, aCanMsg3, iso15765Recv, 1);
			if (flag3) {
			}
			Array<char>* aCanMsg4 = MainForm::StringToByteArray(new String("10 02"));
			bool flag4 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg4, iso15765Recv, 1);
			if (flag4) {
			}
			Array<char>* expr_DE = new Array<char>(2);
			expr_DE->SetData(0, 39);
			expr_DE->SetData(1, 1);
			Array<char>* aCanMsg5 = expr_DE;
			Array<char>* expr_F0 = new Array<char>(10);
			expr_F0->SetData(0, 39);
			expr_F0->SetData(1, 2);
			Array<char>* array2 = expr_F0;
			bool flag5 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg5, iso15765Recv, 1);
			if (flag5) {
				Array<char>* array3 = new Array<char>(8);
				Array<char>* sourceArray = new Array<char>(8);
				Array::Copy(iso15765Recv->gete4_Data(), 2, array3, 0, 8);
				bool flag6 = this->GenerateKeyTC265(array3, sourceArray);
				if (flag6) {
					Array::Copy(sourceArray, 0, array2, 2, 8);
					bool flag7 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, array2, iso15765Recv, 1);
					if (!flag7) {
						this->SetText(new String("Security access failed."));
						result = false;
						return result;
					}
					this->SetText(new String("Security access succeeded."));
				}
			}
			Array<char>* aCanMsg6 = MainForm::StringToByteArray(new String("22 F1 99"));
			bool flag8 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg6, iso15765Recv, 1);
			if (flag8) {
			}
			List_T<char>* list = new List_T<char>();
			List_T<char>* arg_1C9_0 = *list;
			Array<char>* expr_1BE = new Array<char>(3);
			RuntimeHelpers::InitializeArray(expr_1BE, fieldof(<PrivateImplementationDetails>::A8E38C7DB094115750BB5571C52B1C211F160805BD26241703DEF1576C811F82)->FieldHandle);
			arg_1C9_0->AddRange(expr_1BE);
			Array<char>* array4 = new Array<char>(iso15765Recv->gete4_Data()->Length - 3);
			Array::Copy(iso15765Recv->gete4_Data(), 3, array4, 0, iso15765Recv->gete4_Data()->Length - 3);
			list->AddRange(array4);
			Array<char>* aCanMsg7 = list->ToArray();
			bool flag9 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg7, iso15765Recv, 1);
			if (flag9) {
			}
			Array<char>* aCanMsg8 = MainForm::StringToByteArray(new String("34 00 44 70 10 00 00 00 00 0A 5C"));
			bool flag10 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg8, iso15765Recv, 1);
			if (flag10) {
			}
			Thread::Sleep(50);
			this->aCallCanWriteKernelTC265();
			Thread::Sleep(50);
			Array<char>* aCanMsg9 = MainForm::StringToByteArray(new String("37"));
			bool flag11 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg9, iso15765Recv, 1);
			if (flag11) {
			}
			Array<char>* aCanMsg10 = MainForm::StringToByteArray(new String("31 01 40 02 01"));
			bool flag12 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg10, iso15765Recv, 1);
			if (flag12) {
			}
			String* text = new String("");
			Array<char>* array5 = MainForm::StringToByteArray(new String("23 24 70 00 00 00 04 00"));
			int num2 = 1024;
			int num3 = 0;
			int num4 = 2621440;
			int num5 = num4 - num3;
			int tickCount = Environment::TickCount;
			this->progressBar1->Minimum = 0;
			this->progressBar1->Maximum = num5;
			array = new Array<char>(num5);
			for (int i = 0; i < num5; i += num2) {
				array5->SetData(3, (char)(i >> 16));
				array5->SetData(4, (char)(i >> 8));
				bool flag13 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, array5, iso15765Recv, 1);
				if (flag13) {
					bool flag14 = iso15765Recv->gete4_Data()->GetData(0) == 99;
					if (flag14) {
						Array::Copy(iso15765Recv->gete4_Data(), 1, array, num, iso15765Recv->gete4_Data()->Length - 1);
						num += *iso15765Recv->e4_Data->Length - 1;
						double num6 = (double)(num);
						int num7 = Environment::TickCount - tickCount;
						double num8 = (num6 / (double)(num5)) * 100.0;
						int num9 = (num7 / 1000) % 60;
						int num10 = (num7 / 60000) % 60;
						double num11 = (num6 / ((double)(num7) / 100000.0)) / 1024.0;
						this->progressBar1->Value = i + num2;
						this->SetProgress((char)(num8 + 1.0));
						this->ClearText();
						String* arg_44A_0 = new String("Reading: {0:F2} KB / {1:F2} KB ({2:F2}%) | Speed: {3:0.00} KB/s | Time Elapsed: {4:D2}:{5:D2}");
						Array<Object>* expr_3F9 = new Array<Object>(6);
						expr_3F9->SetData(0, BOX<double>(num6 / 1024.0));
						expr_3F9->SetData(1, BOX<double>((double)(num5) / 1024.0));
						expr_3F9->SetData(2, BOX<double>(num8));
						expr_3F9->SetData(3, BOX<double>(num11));
						expr_3F9->SetData(4, BOX<int>(num10));
						expr_3F9->SetData(5, BOX<int>(num9));
						this->SetText(String::Format(arg_44A_0, expr_3F9));
						Application::DoEvents();
					}
				}
			}
			Array<char>* aCanMsg11 = MainForm::StringToByteArray(new String("11 01"));
			bool flag15 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg11, iso15765Recv, 1);
			if (flag15) {
			}
			MessageBox::Show(new String("Read Flash Successfull, Please Restart ECU"), new String("Notice"), MessageBoxButtons::OK, MessageBoxIcon::Asterisk);
			this->SaveDump(array, text);
		}
		catch (Exception* ex) {
			StackTrace* stackTrace = new StackTrace(ex, true);
			StackFrame* frame = stackTrace->GetFrame(stackTrace->FrameCount - 1);
			MessageBox::Show(((*(new String("Error, gFlash , line ")) + new String(frame->GetFileLineNumber())) + *(new String(": "))) + *(ex->Message));
			result = false;
			return result;
		}
		result = true;
		return result;
	}
	bool MainForm::HDXEP768READ()
	{
		bool result;
		try {
			MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
			int num = 0;
			Array<char>* array = new Array<char>(786432);
			bool flag = this->ConnectToUnitCAN();
			if (!flag) {
				MainForm::g_sErrorMessage = new String("No answer from ECU!");
				result = false;
				return result;
			}
			Array<char>* aCanMsg = MainForm::StringToByteArray(new String("10 02"));
			bool flag2 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg, iso15765Recv, 1);
			if (flag2) {
			}
			Thread::Sleep(50);
			aCanMsg = MainForm::StringToByteArray(new String("10 03"));
			bool flag3 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg, iso15765Recv, 1);
			if (flag3) {
			}
			Array<char>* expr_88 = new Array<char>(3);
			RuntimeHelpers::InitializeArray(expr_88, fieldof(<PrivateImplementationDetails>::388CD0567C27CCC3231CBABAF96B6A31963F150282848836F1F33B17AF3FC162)->FieldHandle);
			Array<char>* aCanMsg2 = expr_88;
			Array<char>* array2 = new Array<char>(4);
			bool flag4 = false;
			while (!flag4) {
				bool flag5 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg2, iso15765Recv, 1);
				if (flag5) {
					bool flag6 = (iso15765Recv->gete4_Data() != null) && (iso15765Recv->gete4_Data()->Length >= 4);
					if (flag6) {
						flag4 = true;
					}
					else {
						this->SetText(new String("Invalid reply from ECU, retrying..."));
					}
				}
				else {
					this->SetText(new String("Failed to send 22 F1 F4 CAN message, retrying..."));
				}
			}
			bool flag7 = !flag4;
			if (flag7) {
				result = false;
				return result;
			}
			Array::Copy(iso15765Recv->gete4_Data(), 3, array2, 0, 4);
			Array<char>* expr_135 = new Array<char>(2);
			expr_135->SetData(0, 39);
			expr_135->SetData(1, 1);
			Array<char>* aCanMsg3 = expr_135;
			Array<char>* expr_146 = new Array<char>(4);
			expr_146->SetData(0, 39);
			expr_146->SetData(1, 2);
			Array<char>* array3 = expr_146;
			flag4 = false;
			while (!flag4) {
				bool flag8 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg3, iso15765Recv, 1);
				if (flag8) {
					bool flag9 = (iso15765Recv->gete4_Data() != null) && (iso15765Recv->gete4_Data()->Length >= 4);
					if (flag9) {
						flag4 = true;
					}
					else {
						this->SetText(new String("Invalid reply from ECU, retrying..."));
					}
				}
				else {
					this->SetText(new String("Failed to send Seed Request CAN message, retrying..."));
				}
			}
			bool flag10 = !flag4;
			if (flag10) {
				result = false;
				return result;
			}
			Array<char>* array4 = new Array<char>(2);
			Array<char>* sourceArray = new Array<char>(2);
			Array::Copy(iso15765Recv->gete4_Data(), 2, array4, 0, 2);
			bool flag11 = this->SecurityAccess1(array4, array2, sourceArray);
			if (flag11) {
				Array::Copy(sourceArray, 0, array3, 2, 2);
				bool flag12 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, array3, iso15765Recv, 1);
				if (flag12) {
					this->SetText(new String("Security Access Succeeded... Please wait"));
				}
				else {
					this->SetText(new String("Security Access failed."));
				}
			}
			else {
				this->SetText(new String("Security Access failed during key generation."));
			}
			Thread::Sleep(800);
			Array<char>* expr_268 = new Array<char>(2);
			expr_268->SetData(0, 39);
			expr_268->SetData(1, 1);
			Array<char>* aCanMsg4 = expr_268;
			Array<char>* expr_279 = new Array<char>(4);
			expr_279->SetData(0, 39);
			expr_279->SetData(1, 2);
			Array<char>* array5 = expr_279;
			flag4 = false;
			while (!flag4) {
				bool flag13 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg4, iso15765Recv, 1);
				if (flag13) {
					bool flag14 = (iso15765Recv->gete4_Data() != null) && (iso15765Recv->gete4_Data()->Length >= 4);
					if (flag14) {
						flag4 = true;
					}
					else {
						this->SetText(new String("Invalid reply from ECU, retrying..."));
					}
				}
				else {
					this->SetText(new String("Failed to send Seed Request CAN message, retrying..."));
				}
			}
			bool flag15 = !flag4;
			if (flag15) {
				result = false;
				return result;
			}
			Array<char>* array6 = new Array<char>(2);
			Array<char>* array7 = new Array<char>(2);
			Array::Copy(iso15765Recv->gete4_Data(), 2, array4, 0, 2);
			this->harley_calc_access_key_1(array4, sourceArray);
			Array::Copy(sourceArray, 0, array5, 2, 2);
			bool flag16 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, array5, iso15765Recv, 1);
			if (!flag16) {
				this->SetText(new String("Security Access failed."));
				result = false;
				return result;
			}
			this->SetText(new String("Security Access Succeeded... Please wait"));
			Thread::Sleep(50);
			Array<char>* aCanMsg5 = MainForm::StringToByteArray(new String("34 00 44 00 00 80 00 00 00 04 20"));
			bool flag17 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg5, iso15765Recv, 1);
			if (flag17) {
			}
			Thread::Sleep(50);
			Array<char>* aCanMsg6 = MainForm::StringToByteArray(new String("36 01 96 03 00 07 00 00 80 00 00 00 84 1F 23 E1 F5 88 00 09 07 E0 00 01 02 03 18 20 01 4E CD 03 76 DC 23 5D 17 5C 19 87 C7 20 09 CC 30 00 5C 17 87 C7 5C 19 5C 1B 5C 1D 18 0C 01 46 01 4A CD 01 70 CC FD 00 6C 40 86 08 6C 4C DC 17 6C 44 DC 19 6C 46 DC 1B 6C 48 DC 1D 6C 4A B6 01 4A 18 0E 7C 01 46 3D 15 FA 02 EF 1E 01 44 01 14 DE 13 08 5E 13 26 F0 96 12 42 5A 12 81 46 23 E7 C6 F4 20 54 CE 01 60 EC 00 8C FB E0 27 0B 8C FC 00 27 06 1C 01 44 01 20 CE 87 C7 5A 12 5C 13 EC 0A 5C 1D EC 08 5C 1B EC 06 5C 19 ED 04 1C 01 44 01 5D 17 B7 E4 C1 3E 26 08 81 02 25 04 81 07 23 A6 B7 E4 3D 07 A1 81 36 18 26 00 B9 5B 23 B7 64 84 F0 81 10 27 04 C6 12 20 39 B7 64 84 0F 04 44 05 8C 08 02 23 04 C6 13 20 29 83 00 06 5C 1F DD 21 19 44 5D 21 DD 15 DC 1B 6C 71 DC 1D 6C 71 5D 15 15 F9 2B 86 21 5A 25 15 F9 5C B7 E4 91 25 27 06 C6 73 18 20 02 2C 42 84 EF 5A 25 B7 E4 DC 1F 83 00 07 25 24 5C 1F DD 21 19 47 5D 21 DD 15 96 18 6A 70 DC 19 6C 71 DC 1B 6C 71 DC 1D 6C 71 5D 15 DC 1F 26 C3 96 21 20 1A CE 10 18 DD 15 CB 07 37 DC 21 18 0A 30 70 C3 00 01 63 80 26 F5 5D 15 5C 21 33 81 08 24 08 15 FA FE B7 18 20 FF 55 3D CE 10 07 CD 00 1F 87 C7 6C 31 04 36 FB 15 FA FE E6 20 1C 81 23 C6 24 20 3A B6 00 9A 81 5A 24 04 C6 93 20 2D DC 1A 8C 00 44 27 04 C6 31 20 22 B7 64 81 04 26 08 C1 23 27 0C C6 11 20 02 C6 12 86 34 18 20 01 90 87 87 87 87 87 87 87 87 87 87 87 87 87 87 87 87 87 87 DE 1A EC 00 5C 19 EC 02 5C 1B CC 05 63 5C 17 87 15 FA FE 5F 20 A0 87 5D 15 87 C7 5C 21 15 FA FE DC FC 14 52 5C 08 F6 14 57 5B 11 5B 0C FC 14 58 5C 0F 5C 0A FC 14 5C 8C F7 FF 23 03 CC F7 FF 5C 0D FE 14 54 8E 00 02 26 1A 4C 07 20 C6 F2 B6 F7 FF 81 55 26 0A FE 14 62 BE F7 F5 27 1E C6 F0 18 20 01 19 C6 F5 04 35 F7 C6 F1 FE 14 5E CD F8 00 AE 4C 26 EB FE 14 60 AE 4E 26 E4 DE 0D 1A E2 FC 01 C6 7F 15 FA 01 43 DE 0F D6 11 15 FA 01 16 97 18 26 00 DA CD 14 52 DE 0A D6 0C 15 FA 01 47 CD 14 52 DE 0A D6 0C 15 FA 01 9E 97 18 26 00 BF D6 0C DE 0A 1A E2 08 00 18 97 26 07 52 C1 7F 22 58 5B 0C 5E 0A C1 7F 25 04 9E 0D 24 4C C6 93 86 5A B1 00 9A 25 0D CE 09 C4 04 35 FD B1 00 9A 18 24 FF 7D C6 F6 B6 01 44 84 28 18 26 FF 72 15 FA FD 6A DC 15 B7 45 80 08 5C 15 B7 46 83 14 51 49 27 07 18 02 2E 6E 04 34 F9 DC 21 80 08 25 02 5C 21 15 FA FD E9 18 20 FF 7C DD 0F 02 02 5D 0A D6 11 5B 0C 7B 00 10 DE 08 4F 07 30 10 9D 0D 22 08 18 E6 40 1A E5 04 B6 F4 B7 54 20 2C 18 E6 40 1A E5 04 B6 F8 07 4E 96 0C 42 5A 0C 7A 00 10 81 7F 25 EA 9D 0D 22 08 18 E6 40 1A E5 04 B6 F4 B7 54 18 FE 40 00 5E 08 07 37 04 44 1D C6 F7 20 02 C6 72 37 DE 0D 1A E2 FC 01 C6 7F 07 4F 33 86 36 CD 03 7F 15 FA FC DB 20 08 86 86 5A 24 15 FA FC CC 07 02 20 FE 18 0B 55 00 3F 18 0B AA 00 3F 3D D0 08 82 00 9B 08 3D 4F 07 30 02 20 0F 07 1D 1A E2 04 00 18 97 26 F6 52 C1 7F 25 F1 9E 0D 24 0A 07 0A 1A E2 04 00 18 97 26 F2 87 3D 1D 01 02 07 86 0A 7C 01 0A 1C 01 02 01 7E 01 0A 1C 01 06 80 07 B3 1F 01 06 80 FB 3D C1 7F 24 0D 07 1D 19 48 1A 08 8D 1C 52 25 F5 20 11 8D 1C 52 24 0C 9E 0D 24 08 07 07 19 48 1A 08 20 EF 3D 1D 01 02 07 86 06 7C 01 0A 1C 01 02 01 7E 01 0A 86 02 7A 01 02 18 05 40 01 0A 72 01 02 18 05 42 01 0A 72 01 02 18 05 44 01 0A 72 01 02 18 05 46 01 0A 1C 01 06 80 15 F9 51 1F 01 06 80 FB 3D 7B 00 10 CC 04 00 3B 18 EC 31 AC 71 3A 26 05 04 34 F4 20 02 86 C0 3D"));
			bool flag18 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg6, iso15765Recv, 1);
			if (flag18) {
			}
			String* text = new String("");
			Array<char>* array8 = MainForm::StringToByteArray(new String("23 00 00 00"));
			int num2 = 4;
			int num3 = 16384;
			int num4 = 32768;
			int num5 = num3;
			int num6 = num4 - num3;
			int tickCount = Environment::TickCount;
			this->progressBar1->Minimum = 0;
			this->progressBar1->Maximum = num6;
			array = new Array<char>(786432);
			for (int i = 0; i < num6; i += num2) {
				array8->SetData(1, (char)(num5 >> 16));
				array8->SetData(2, (char)(num5 >> 8));
				array8->SetData(3, (char)(num5));
				bool flag19 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, array8, iso15765Recv, 1);
				if (flag19) {
					bool flag20 = iso15765Recv->gete4_Data()->GetData(0) == 99;
					if (flag20) {
						Debug::WriteLine(((*(new String("Address ")) + num5->ToString(new String("X"))) + *(new String(" Data "))) + BitConverter::ToString(iso15765Recv->gete4_Data()));
						Array::Copy(iso15765Recv->gete4_Data(), 1, array, num5, iso15765Recv->gete4_Data()->Length - 1);
						num += *iso15765Recv->e4_Data->Length - 1;
						double num7 = (double)(num);
						int num8 = Environment::TickCount - tickCount;
						double num9 = (num7 / (double)(num6)) * 100.0;
						int num10 = (num8 / 1000) % 60;
						int num11 = (num8 / 60000) % 60;
						double num12 = (num7 / ((double)(num8) / 100000.0)) / 1024.0;
						this->progressBar1->Value = i + num2;
						this->SetProgress((char)(num9 + 1.0));
						this->ClearText();
						String* arg_5AF_0 = new String("Reading: {0:F2} KB / {1:F2} KB ({2:F2}%) | Speed: {3:0.00} KB/s | Time Elapsed: {4:D2}:{5:D2}");
						Array<Object>* expr_55E = new Array<Object>(6);
						expr_55E->SetData(0, BOX<double>(num7 / 1024.0));
						expr_55E->SetData(1, BOX<double>((double)(num6) / 1024.0));
						expr_55E->SetData(2, BOX<double>(num9));
						expr_55E->SetData(3, BOX<double>(num12));
						expr_55E->SetData(4, BOX<int>(num11));
						expr_55E->SetData(5, BOX<int>(num10));
						this->SetText(String::Format(arg_5AF_0, expr_55E));
						Application::DoEvents();
					}
				}
				num5 += num2;
			}
			Array<char>* aCanMsg7 = MainForm::StringToByteArray(new String("11 01"));
			bool flag21 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg7, iso15765Recv, 1);
			if (flag21) {
			}
			this->SaveDump(array, text);
			MessageBox::Show(new String("Read Flash Successfull, Please Restart ECU"), new String("Notice"), MessageBoxButtons::OK, MessageBoxIcon::Asterisk);
		}
		catch (Exception* ex) {
			StackTrace* stackTrace = new StackTrace(ex, true);
			StackFrame* frame = stackTrace->GetFrame(stackTrace->FrameCount - 1);
			MessageBox::Show(((*(new String("Error, gFlash , line ")) + new String(frame->GetFileLineNumber())) + *(new String(": "))) + *(ex->Message));
			result = false;
			return result;
		}
		result = true;
		return result;
	}
	void MainForm::btnReadFlash_Click(Object* sender, EventArgs* e)
	{
		bool flag = !this->OpenJ2534Device();
		if (!flag) {
			MainForm::Iso14230RecvObj* iso14230RecvObj = new MainForm::Iso14230RecvObj();
			this->ClearText();
			bool flag2 = MainForm::g_ECUSelected == MainForm::ECUTYPE::MC9S12XEP768;
			if (flag2) {
				bool flag3 = this->HDXEP768READ();
				if (flag3) {
					String* str = new String("");
					MainForm::g_sErrorMessage = *(new String("Saved to: ")) + *str;
				}
				else {
					MainForm::g_sErrorMessage = new String("Reading FLASH failed!");
				}
			}
			else {
				bool flag4 = this->HDTC265DREAD();
				if (flag4) {
					String* str2 = new String("");
					MainForm::g_sErrorMessage = *(new String("Saved to: ")) + *str2;
				}
				else {
					MainForm::g_sErrorMessage = new String("Reading FLASH failed!");
				}
			}
		}
	}
	void MainForm::btnReadEEPROM_Click(Object* sender, EventArgs* e)
	{
		bool flag = !this->OpenJ2534Device();
		if (!flag) {
			MainForm::Iso14230RecvObj* iso14230RecvObj = new MainForm::Iso14230RecvObj();
			this->ClearText();
			bool flag2 = MainForm::g_ECUSelected == MainForm::ECUTYPE::MC9S12DJ128;
			if (flag2) {
				MainForm::g_sErrorMessage = new String("Not Available!");
				MessageBox::Show(new String("Not Available !"), new String("Notice"), MessageBoxButtons::OK, MessageBoxIcon::Hand);
				this->SetText(new String("Not Available !"));
			}
			else {
				bool flag3 = MainForm::g_ECUSelected == MainForm::ECUTYPE::MC9S12XEP768;
				if (flag3) {
					bool flag4 = this->HDXEP768READE2P();
					if (flag4) {
						String* str = new String("");
						MainForm::g_sErrorMessage = *(new String("Saved to: ")) + *str;
					}
					else {
						MessageBox::Show(new String("Reading FLASH failed!"), new String("Notice"), MessageBoxButtons::OK, MessageBoxIcon::Hand);
						MainForm::g_sErrorMessage = new String("Reading FLASH failed!");
					}
				}
				else {
					bool flag5 = this->HDTC265DREADE2P();
					if (flag5) {
						String* str2 = new String("");
						MainForm::g_sErrorMessage = *(new String("Saved to: ")) + *str2;
					}
					else {
						MessageBox::Show(new String("Reading FLASH failed!"), new String("Notice"), MessageBoxButtons::OK, MessageBoxIcon::Hand);
						MainForm::g_sErrorMessage = new String("Reading FLASH failed!");
					}
				}
			}
		}
	}
	void MainForm::writePartNumberVinXEP768(String* PartNumber, String* VIN, String* ASPN)
	{
		try {
			bool flag = !this->OpenJ2534Device();
			if (!flag) {
				MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
				bool flag2 = this->ConnectToUnitCAN();
				if (!flag2) {
					MainForm::g_sErrorMessage = new String("No answer from ECU!");
				}
				MessageBox::Show(new String("Please switch the ignition Off < Then > Switch Ignition ON"), new String("Instruction"), MessageBoxButtons::OK, MessageBoxIcon::Asterisk);
				Array<char>* aCanMsg = MainForm::StringToByteArray(new String("10 03"));
				MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg, iso15765Recv, 1);
				Thread::Sleep(10);
				Array<char>* aCanMsg2 = MainForm::StringToByteArray(new String("10 03"));
				bool flag3 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg2, iso15765Recv, 1);
				if (flag3) {
					Thread::Sleep(10);
				}
				Array<char>* aCanMsg3 = MainForm::StringToByteArray(new String("27 01"));
				bool flag4 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg3, iso15765Recv, 1);
				if (flag4) {
				}
				Thread::Sleep(10);
				Array<char>* aCanMsg4 = MainForm::StringToByteArray(new String("27 02 E6 30"));
				bool flag5 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg4, iso15765Recv, 1);
				if (flag5) {
				}
				Array<char>* aCanMsg5 = MainForm::StringToByteArray(new String("22 F1 ED"));
				bool flag6 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg5, iso15765Recv);
				if (flag6) {
				}
				bool flag7 = !String::IsNullOrEmpty(ASPN);
				if (flag7) {
					this->SetText(new String("Write Assembly ECU Part Number"));
					Thread::Sleep(10);
					Array<char>* sourceArray = MainForm::StringToByteArray(new String("2E F1 ED"));
					Array<char>* bytes = Encoding::ASCII->GetBytes(ASPN);
					Array<char>* array = new Array<char>(15);
					Array::Copy(sourceArray, array, 3);
					Array::Copy(bytes, 0, array, 3, bytes->Length);
					bool flag8 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, array, iso15765Recv);
					if (flag8) {
						this->SetText(new String("Write Assembly ECU Part Number Successfull"));
					}
				}
				Thread::Sleep(10);
				Array<char>* aCanMsg6 = MainForm::StringToByteArray(new String("22 F1 EA"));
				bool flag9 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg6, iso15765Recv);
				if (flag9) {
					Thread::Sleep(10);
				}
				bool flag10 = !String::IsNullOrEmpty(PartNumber);
				if (flag10) {
					this->SetText(new String("Write H/W ECU Part Number"));
					Thread::Sleep(10);
					Array<char>* sourceArray2 = MainForm::StringToByteArray(new String("2E F1 EA "));
					Array<char>* bytes2 = Encoding::ASCII->GetBytes(ASPN);
					Array<char>* array2 = new Array<char>(15);
					Array::Copy(sourceArray2, array2, 3);
					Array::Copy(bytes2, 0, array2, 3, bytes2->Length);
					bool flag11 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, array2, iso15765Recv);
					if (flag11) {
						this->SetText(new String("Write H/W ECU Part Number Successfull"));
					}
				}
				Array<char>* aCanMsg7 = MainForm::StringToByteArray(new String("22 F1 EF"));
				bool flag12 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg7, iso15765Recv);
				if (flag12) {
					Thread::Sleep(10);
				}
				bool flag13 = !String::IsNullOrEmpty(VIN);
				if (flag13) {
					this->SetText(new String("Write VIN ECU"));
					Thread::Sleep(10);
					Array<char>* aCanMsg8 = MainForm::StringToByteArray(*(new String("2E F1 EF ")) + BitConverter::ToString(Encoding::ASCII->GetBytes(VIN))->Replace(new String("-"), new String("")));
					bool flag14 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg8, iso15765Recv);
					if (flag14) {
						this->SetText(new String("Write VIN ECU Successfull"));
					}
				}
			}
		}
		catch (Exception* ex) {
			StackTrace* stackTrace = new StackTrace(ex, true);
			StackFrame* frame = stackTrace->GetFrame(stackTrace->FrameCount - 1);
			MessageBox::Show(((*(new String("Error, gFlash , line ")) + new String(frame->GetFileLineNumber())) + *(new String(": "))) + *(ex->Message));
		}
	}
	void MainForm::writePartNumberVinTC265D(String* PartNumber, String* VIN, String* ASPN, String* SWCONFIG)
	{
		try {
			bool flag = !this->OpenJ2534Device();
			if (!flag) {
				MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
				bool flag2 = this->ConnectToUnitCAN();
				if (!flag2) {
					MainForm::g_sErrorMessage = new String("No answer from ECU!");
				}
				Array<char>* aCanMsg = MainForm::StringToByteArray(new String("10 03"));
				MainForm::sendRequestCAN(2015, aCanMsg, iso15765Recv, 1);
				Thread::Sleep(10);
				Array<char>* aCanMsg2 = MainForm::StringToByteArray(new String("3E 00 01"));
				bool flag3 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg2, iso15765Recv, 1);
				if (flag3) {
				}
				Array<char>* expr_81 = new Array<char>(2);
				expr_81->SetData(0, 39);
				expr_81->SetData(1, 1);
				Array<char>* aCanMsg3 = expr_81;
				Array<char>* expr_92 = new Array<char>(10);
				expr_92->SetData(0, 39);
				expr_92->SetData(1, 2);
				Array<char>* array = expr_92;
				bool flag4 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg3, iso15765Recv, 1);
				if (flag4) {
					Array<char>* array2 = new Array<char>(8);
					Array<char>* sourceArray = new Array<char>(8);
					Array::Copy(iso15765Recv->gete4_Data(), 2, array2, 0, 8);
					bool flag5 = this->GenerateKeyTC265(array2, sourceArray);
					if (flag5) {
						Array::Copy(sourceArray, 0, array, 2, 8);
						bool flag6 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, array, iso15765Recv, 1);
						if (!flag6) {
							this->SetText(new String("Security access failed."));
							return;
						}
						this->SetText(new String("Security access succeeded."));
					}
				}
				Thread::Sleep(10);
				Array<char>* aCanMsg4 = MainForm::StringToByteArray(new String("22 F1 EC"));
				bool flag7 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg4, iso15765Recv);
				if (flag7) {
				}
				bool flag8 = !String::IsNullOrEmpty(ASPN);
				if (flag8) {
					this->SetText(new String("Write Assembly ECU Part Number"));
					Thread::Sleep(10);
					Array<char>* sourceArray2 = MainForm::StringToByteArray(new String("2E F1 EC "));
					Array<char>* bytes = Encoding::ASCII->GetBytes(ASPN);
					Array<char>* array3 = new Array<char>(15);
					Array::Copy(sourceArray2, array3, 3);
					Array::Copy(bytes, 0, array3, 3, bytes->Length);
					bool flag9 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, array3, iso15765Recv);
					if (flag9) {
						this->SetText(new String("Write Assembly ECU Part Number Successfull"));
					}
				}
				Thread::Sleep(10);
				Array<char>* aCanMsg5 = MainForm::StringToByteArray(new String("22 F1 EC"));
				bool flag10 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg5, iso15765Recv);
				if (flag10) {
				}
				bool flag11 = !String::IsNullOrEmpty(PartNumber);
				if (flag11) {
					this->SetText(new String("Write H/W ECU Part Number"));
					Thread::Sleep(10);
					Array<char>* sourceArray3 = MainForm::StringToByteArray(new String("2E F1 EC "));
					Array<char>* bytes2 = Encoding::ASCII->GetBytes(ASPN);
					Array<char>* array4 = new Array<char>(15);
					Array::Copy(sourceArray3, array4, 3);
					Array::Copy(bytes2, 0, array4, 3, bytes2->Length);
					bool flag12 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, array4, iso15765Recv);
					if (flag12) {
						this->SetText(new String("Write H/W ECU Part Number Successfull"));
					}
				}
				Array<char>* aCanMsg6 = MainForm::StringToByteArray(new String("22 F1 90"));
				bool flag13 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg6, iso15765Recv);
				if (flag13) {
				}
				bool flag14 = !String::IsNullOrEmpty(VIN);
				if (flag14) {
					this->SetText(new String("Write VIN ECU"));
					Thread::Sleep(10);
					Array<char>* aCanMsg7 = MainForm::StringToByteArray(*(new String("2E F1 90 ")) + BitConverter::ToString(Encoding::ASCII->GetBytes(VIN))->Replace(new String("-"), new String("")));
					bool flag15 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg7, iso15765Recv);
					if (flag15) {
						this->SetText(new String("Write VIN ECU Successfull"));
					}
				}
				Thread::Sleep(10);
				Array<char>* aCanMsg8 = MainForm::StringToByteArray(new String("22 10 01"));
				bool flag16 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg8, iso15765Recv);
				if (flag16) {
				}
				bool flag17 = !String::IsNullOrEmpty(SWCONFIG);
				if (flag17) {
					this->SetText(new String("Write SW CONFIGURATION"));
					Thread::Sleep(10);
					Array<char>* aCanMsg9 = MainForm::StringToByteArray(*(new String("2E 10 01 ")) + BitConverter::ToString(Encoding::ASCII->GetBytes(SWCONFIG))->Replace(new String("-"), new String("")));
					bool flag18 = MainForm::sendRequestCANWaitEndless(MainForm::g_ecu_CanTx, aCanMsg9, iso15765Recv);
					if (flag18) {
						this->SetText(new String("Write SW CONFIGURATION Successfull"));
					}
				}
			}
		}
		catch (Exception* ex) {
			StackTrace* stackTrace = new StackTrace(ex, true);
			StackFrame* frame = stackTrace->GetFrame(stackTrace->FrameCount - 1);
			MessageBox::Show(((*(new String("Error, gFlash , line ")) + new String(frame->GetFileLineNumber())) + *(new String(": "))) + *(ex->Message));
		}
	}
	uint MainForm::ReadBigEndianUInt32(Array<char>* data, int index)
	{
		return (uint)(((((int)(data->GetData(index)) << 24) | ((int)(data->GetData(index + 1)) << 16)) | ((int)(data->GetData(index + 2)) << 8)) | (int)(data->GetData(index + 3)));
	}
	void MainForm::WriteBigEndianUInt32(Array<char>* data, int index, uint value)
	{
		data->SetData(index, (char)((value >> 24) & 255u));
		data->SetData(index + 1, (char)((value >> 16) & 255u));
		data->SetData(index + 2, (char)((value >> 8) & 255u));
		data->SetData(index + 3, (char)(value & 255u));
	}
	void MainForm::moduleConfigToolStripMenuItem_Click(Object* sender, EventArgs* e)
	{
		MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
		bool flag = this->ConnectToUnitCAN();
		if (flag) {
			this->aCallCanKeepAlive();
			this->aCallCanClearDTC();
			this->aCallCanStartDiag03();
			bool flag2 = MainForm::g_ECUSelected == MainForm::ECUTYPE::TC265_MT21M;
			if (flag2) {
				this->aCallCanReadData22F1F4();
				this->aCallCanReadData22F1EC();
				this->aCallCanSATC265();
			}
			else {
				bool flag3 = MainForm::g_ECUSelected == MainForm::ECUTYPE::MC9S12XEP768;
				if (flag3) {
				}
			}
		}
		else {
			MainForm::g_sErrorMessage = new String("No answer from ECU!");
		}
	}
	void MainForm::writeVINPartNumberToolStripMenuItem_Click(Object* sender, EventArgs* e)
	{
		bool flag = MainForm::g_ECUSelected == MainForm::ECUTYPE::TC265_MT21M;
		if (flag) {
			ECMIdentification* eCMIdentification = new ECMIdentification();
			bool flag2 = eCMIdentification->ShowDialog() == DialogResult::OK;
			if (flag2) {
				String* text = eCMIdentification->textBoxECUVIN->Text;
				String* text2 = eCMIdentification->textBoxECUHWPN->Text;
				String* text3 = eCMIdentification->textBoxECUASPN->Text;
				String* text4 = eCMIdentification->textBoxECUSWCONFIG->Text;
				this->writePartNumberVinTC265D(text2, text, text3, text4);
			}
		}
		else {
			bool flag3 = MainForm::g_ECUSelected == MainForm::ECUTYPE::MC9S12XEP768;
			if (flag3) {
				ECMIdentification* eCMIdentification2 = new ECMIdentification();
				bool flag4 = eCMIdentification2->ShowDialog() == DialogResult::OK;
				if (flag4) {
					String* text5 = eCMIdentification2->textBoxECUVIN->Text;
					String* text6 = eCMIdentification2->textBoxECUHWPN->Text;
					String* text7 = eCMIdentification2->textBoxECUASPN->Text;
					this->writePartNumberVinXEP768(text6, text5, text7);
				}
			}
		}
	}
	void MainForm::aCallDeleteFile()
	{
		bool flag = File::Exists(this->tbFilelocation->Text);
		if (flag) {
			try {
				File::Delete(this->tbFilelocation->Text);
			}
			catch (Exception* ex) {
				MessageBox::Show(*(new String("Gagal menghapus file: ")) + *(ex->Message), new String("Error"), MessageBoxButtons::OK, MessageBoxIcon::Hand);
			}
		}
	}
	void MainForm::aCallCanSATC265()
	{
		MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
		Array<char>* expr_0D = new Array<char>(2);
		expr_0D->SetData(0, 39);
		expr_0D->SetData(1, 1);
		Array<char>* aCanMsg = expr_0D;
		Array<char>* expr_1E = new Array<char>(10);
		expr_1E->SetData(0, 39);
		expr_1E->SetData(1, 2);
		Array<char>* array = expr_1E;
		bool flag = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg, iso15765Recv, 1);
		if (flag) {
			Array<char>* array2 = new Array<char>(8);
			Array<char>* sourceArray = new Array<char>(8);
			Array::Copy(iso15765Recv->gete4_Data(), 2, array2, 0, 8);
			bool flag2 = this->GenerateKeyTC265(array2, sourceArray);
			if (flag2) {
				Array::Copy(sourceArray, 0, array, 2, 8);
				bool flag3 = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, array, iso15765Recv, 1);
				if (flag3) {
					this->SetText(new String("Security access succeeded."));
				}
				else {
					this->SetText(new String("Security access failed."));
				}
			}
		}
	}
	void MainForm::aCallCanKeepAlive()
	{
		MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
		Array<char>* aCanMsg = MainForm::StringToByteArray(new String("3E 00 01"));
		bool flag = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg, iso15765Recv, 1);
		if (flag) {
			Thread::Sleep(10);
		}
	}
	void MainForm::aCallCanClearDTC()
	{
		MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
		Array<char>* aCanMsg = MainForm::StringToByteArray(new String("14 FF FF FF"));
		bool flag = MainForm::sendRequestCAN(2015, aCanMsg, iso15765Recv, 1);
		if (flag) {
			Thread::Sleep(10);
		}
	}
	void MainForm::aCallCanStartDiag01()
	{
		MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
		Array<char>* aCanMsg = MainForm::StringToByteArray(new String("10 01"));
		bool flag = MainForm::sendRequestCAN(2015, aCanMsg, iso15765Recv, 1);
		if (flag) {
			Thread::Sleep(10);
		}
	}
	void MainForm::aCallCanStartDiag02()
	{
		MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
		Array<char>* aCanMsg = MainForm::StringToByteArray(new String("10 02"));
		bool flag = MainForm::sendRequestCAN(2015, aCanMsg, iso15765Recv, 1);
		if (flag) {
			Thread::Sleep(10);
		}
	}
	void MainForm::aCallCanStartDiag03()
	{
		MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
		Array<char>* aCanMsg = MainForm::StringToByteArray(new String("10 03"));
		bool flag = MainForm::sendRequestCAN(2015, aCanMsg, iso15765Recv, 1);
		if (flag) {
			Thread::Sleep(10);
		}
	}
	void MainForm::aCallCanReadData22F1F4()
	{
		MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
		Array<char>* aCanMsg = MainForm::StringToByteArray(new String("22 F1 F4"));
		bool flag = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg, iso15765Recv, 1);
		if (flag) {
			Thread::Sleep(10);
		}
	}
	void MainForm::aCallCanReadData22F1EC()
	{
		MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
		Array<char>* aCanMsg = MainForm::StringToByteArray(new String("22 F1 EC"));
		bool flag = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg, iso15765Recv, 1);
		if (flag) {
			Thread::Sleep(10);
		}
	}
	void MainForm::aCallCanWriteKernelTC265()
	{
		MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
		Array<char>* aCanMsg = MainForm::StringToByteArray(new String("36 01 04 00 01 A3 20 00 10 70 20 00 10 70 20 00 10 70 20 00 10 70 20 00 10 70 20 00 10 70 20 00 10 70 0D 00 40 03 91 00 01 26 82 0F C5 0F 05 10 64 2F FC FF 7B 10 57 40 1B 04 14 40 7B 10 20 50 3B 80 00 60 6D 00 48 00 6D 00 06 00 6D 00 B9 00 82 02 00 90 91 20 00 2F 91 00 01 F6 D9 22 00 09 08 02 4C 20 37 2F 04 FC 6C 20 0C F3 08 43 8F 0F 01 F0 8F 83 01 30 A6 3F 08 13 91 20 00 2F A6 F3 0C F2 D9 22 10 09 8F 8F 00 20 0F 23 A0 F0 6C 20 08 83 0C F7 8F 83 01 30 8F 0F 01 F0 A6 3F 08 53 A6 F3 0C F6 91 20 00 FF 8F 8F 00 20 0F 23 A0 F0 D9 FF 14 09 68 0F 91 20 00 FF D9 FF 1C 09 7B 80 F6 F0 68 0F 40 F2 4C 20 6F 8F FF FF 4C F0 6F 1F FC 7F 00 90 91 00 01 F6 8F 84 1E F0 28 1F 37 04 68 F8 28 06 28 2F 37 04 68 F4 28 44 28 3F 8F 85 1E F0 28 5F 37 05 68 F8 28 85 28 6F 37 05 68 F4 28 7F 00 90 91 20 00 2F D9 22 30 09 4C 20 91 00 01 F6 8F 8F 1E F0 28 4F 4C 20 37 0F 68 F8 28 3F 4C 20 37 0F 68 F4 28 2F 4C 20 91 20 00 2F 28 1F D9 22 34 09 4C 20 8F 8F 1E F0 28 8F 4C 20 37 0F 68 F8 28 7F 4C 20 37 0F 68 F4 28 6F 4C 20 91 20 00 2F 28 5F D9 22 20 09 4C 20 37 0F 64 FC 28 0F 91 20 00 FF DA 09 D9 FF 3C 09 68 0F 00 90 3B F0 0F 20 FF 84 06 80 60 42 11 02 01 F6 08 12 00 90 FF 84 06 80 60 42 11 02 01 F6 28 15 00 90 91 00 01 F6 28 04 00 90 91 20 00 FF D9 FF 3C 09 48 02 37 02 E1 21 00 90 91 00 01 F6 D9 FF 00 40 82 3F A8 0F DA 7F 28 2F 28 34 28 45 1D 00 BD 01 91 00 01 F6 D9 FF 00 40 82 08 6D 00 43 02 6D FF E5 FF DF 02 FC 7F 6D 00 24 01 76 23 A8 08 3C F6 08 24 8B 34 22 F2 EE 04 6D 00 AC 00 3C EF 8B 14 23 F2 EE 04 6D 00 1A 00 3C E9 8B D4 23 F2 EE 04 6D 00 55 00 3C E3 8B 14 21 F2 EE 04 6D 00 E0 00 3C DD 3B 10 01 50 6D FF C9 FF 3C D8 3B 10 03 40 3B 80 07 50 1D FF C2 FF 91 00 01 F6 D9 FF 00 40 B9 FF 00 00 3B D0 03 40 8B 8F 00 F2 3B 30 01 50 6E 0A B9 FF 04 00 8B FF 0F F2 EE 07 3B D0 03 40 3B 10 01 50 1D FF AA FF 08 63 0C F7 8F 83 01 30 8F 0F 01 F0 A6 3F 08 93 3B 80 07 50 A6 F3 0C F8 3B 10 03 40 8F 8F 00 20 0F 23 A0 F0 6D FF 96 FF 91 00 01 47 02 F4 D9 44 18 80 6D 00 32 02 3B 10 03 40 3B F0 0E 50 DF 02 DF 7F DA 71 28 2F 82 1F 28 3F 82 2F A8 0F 1D 00 48 01 91 00 01 F6 D9 FF 00 40 B9 FF 00 00 3B 50 10 20 3B D0 03 40 3B 30 01 50 5F 2F 33 80 08 44 08 32 8F 04 01 F0 8F 82 01 20 0F F2 A0 40 08 62 A6 42 08 54 8F 84 00 F0 0F F2 A0 40 9B 04 00 26 7B 00 08 F0 7F F2 0B 80 91 00 01 46 D9 44 07 40 3B 00 10 50 6D 00 05 02 3C 16 9B 04 10 25 7B C0 00 F0 7F F2 0B 80 91 00 01 46 D9 44 07 40 3B 00 10 50 6D 00 41 02 3C 07 3B D0 03 40 3B 10 03 50 1D FF 40 FF 91 00 01 F6 D9 FF 00 40 DA 7D 28 2F 82 1F A8 0F 1D 00 FD 00 91 00 01 F6 D9 FF 00 40 B9 FF 00 00 3B 10 02 40 8B 8F 00 F2 3B 30 01 50 6E 09 0C F3 8B 4F 02 F2 EE 07 3B 10 02 40 3B 10 03 50 1D FF 1F FF 08 42 0C F5 8F 82 01 20 8F 0F 01 F0 A6 F2 0C F7 08 93 A6 F2 0C F6 40 F4 8F 8F 00 F0 A6 F2 0C F8 A0 02 8F 8F 00 F0 A6 3F 3B 10 40 30 60 FF 7F 3F E3 FF 01 22 00 36 FD F0 0D 00 91 00 01 F6 D9 FF 00 40 3B 30 06 20 C2 1F 28 22 A8 0F 1D 00 BE 00 14 33 B0 12 01 24 10 30 E9 33 02 00 3C EB 91 00 01 F6 D9 FF 00 40 82 2F A8 0F DA 51 28 2F 82 1F 28 3F 6D 00 AB 00 91 30 00 FF D9 FF 18 16 48 02 4C F0 37 02 62 24 8F 22 40 21 37 2F 02 F4 68 0F 91 30 00 FF D9 FF 00 36 4C F0 91 30 00 FF 8F 8F 00 F0 B7 0F 10 F8 D9 FF 20 16 96 02 68 0F 3C 00 91 00 01 F6 82 0A 82 08 3B 00 01 90 D9 FF 00 40 3B 30 40 D0 6D 00 0F 01 6D FF B1 FE DF 02 FC 7F 6D FF 64 FE 82 04 6D FF 96 FE 02 2F 8F 02 0F 21 DF 02 1C 80 BF 8F 05 80 3B 00 01 20 00 90 91 00 01 F6 D9 FF 00 40 A8 0F 82 08 40 FC 8F F8 0F 21 7F F2 39 80 1B 18 00 90 02 94 6D FF 7C FE 01 C8 00 F6 02 98 28 22 3C F3 8B 02 21 32 DF 03 2D 00 8B 02 22 22 DF 02 D0 FF DF 08 4E 00 C6 9F 16 0F EE 4A 8B 78 20 F3 82 0B 1B 1B 00 C0 02 C4 6D FF 62 FE 01 FB 00 26 01 2A 00 26 02 CB E9 22 02 00 8F FC 0F 21 3F F2 F2 FF 37 0F 70 F0 A2 F8 37 08 70 80 42 FA 9A 19 37 0A 70 A0 8F FF 0F 91 DF 08 AB FF 82 02 00 90 82 14 6D FF 45 FE 16 0F 8F 8F 00 F0 A6 F2 37 02 50 F0 37 0F 70 80 7F DF AE 7F A8 08 82 0F 92 24 6D FF 36 FE 10 F2 C2 1F E9 22 02 00 DF 6F F9 FF 7B 00 00 43 82 05 3B 80 00 60 C2 A8 6D FF DB FD 37 08 70 80 6D FF 97 FD 82 6A 82 19 3C 81 82 12 00 90 91 00 01 F6 D9 FF 00 40 B9 F2 00 00 82 0F 40 FC FF 82 1D 80 B9 C5 00 00 8F FF 0F 21 92 18 7F 52 0A 80 16 FF 10 CF 92 14 08 25 6D FF 11 FE 02 8F 3C F2 8F F5 00 51 82 04 6D FF 0A FE 3B 80 00 40 6D FF 0D FE 6D FF 6E FD 3C 67 3B 80 00 40 6D FF 06 FE 08 15 82 04 B7 15 1C 52 82 0F 6D FF F8 FD 82 14 08 05 6D FF F4 FD 10 CF 92 24 08 25 C2 1F 6D FF EE FD DF 6F FA FF 6D FF 54 FD 7B 00 01 F0 6D 00 4D 00 6D FF EF FD F6 25 C2 FF EE FA 82 22 00 90 6D FF 9F FD 82 04 6D FF D1 FD 8B 02 23 22 DF 02 F5 FF 91 00 01 F6 D9 FF 00 40 8C F0 7B 00 01 C6 C2 AF 37 0F 70 D0 82 1A 82 69 1B 0C 10 C0 DF 0D 2B 00 6D 00 2B 00 3B 80 00 40 6D FF C7 FD B7 2A 1C 52 82 04 6D FF BB FD 1A 9C 60 FC 8B 7D 20 83 82 02 01 C2 00 F6 1B 12 00 B0 02 B4 08 25 6D FF AE FD 8F FB 0F 31 02 B2 3F 83 F5 FF 37 08 70 80 6D FF 0F FD 5A 8D 42 98 C2 1A 37 0F 70 D0 37 08 70 90 3C D6 82 02 00 90 00 90 91 30 00 FF D9 FF 30 36 DF 04 18 80 4D C0 E1 FF 91 30 00 FF D9 FF 00 46 6E 10 91 30 00 FF D9 FF 0C 46 1E 1B 91 30 00 FF D9 FF 18 46 1E 26 00 A0 91 30 00 FF D9 FF 30 36 4C F0 8F FF CF F1 96 F1 68 0F 4C F0 8F FF CF F1 96 F2 68 0F 00 90 91 30 00 FF D9 FF 30 36 DF 04 18 80 4D C0 E1 FF 91 30 00 FF D9 FF 00 46 6E 10 91 30 00 FF D9 FF 0C 46 1E 1B 91 30 00 FF D9 FF 18 46 1E 26 00 A0 91 30 00 FF D9 FF 30 36 4C F0 8F FF CF F1 96 F1 68 0F 4C F0 8F FF CF F1 96 F3 68 0F 00 90 02 4F 40 4F 6D 00 B2 00 76 27 6D 00 61 01 02 F4 40 F4 1D 00 26 01 00 90 8F F5 01 21 40 4C 02 48 8F B5 1F B0 02 4F 82 0A DF 02 3F 00 82 02 00 90 6D 00 9C 00 DF 02 FC 7F 6D 00 4A 01 82 04 6D 00 B1 00 DF 02 F5 7F 52 82 01 C2 00 F6 82 09 08 36 08 22 8F 86 01 60 8F 02 01 20 A6 26 08 02 08 73 A6 26 08 62 8F 83 01 30 8F 02 01 20 A6 23 08 42 08 14 A6 23 08 52 8F 84 00 40 8F 82 00 50 A6 64 A6 35 6D 00 AD 00 1B 89 00 90 8B 09 22 22 D9 FF 08 00 DF 02 DE FF 02 F4 6D 00 AD 00 DF 02 C8 7F 1B 0F 02 F0 C2 1A 3F BA C5 7F 82 12 00 90 8F 75 00 F1 6E 03 82 02 00 90 60 42 40 4F 8F D5 1F 80 82 0F 01 42 20 C0 80 C9 80 F2 42 29 7F 8F 32 00 6D 00 4C 00 DF 02 F0 7F 6D 00 FA 00 82 14 6D 00 61 00 DF 02 E9 7F 08 36 08 22 8F 86 01 60 8F 02 01 20 A6 26 08 02 08 75 A6 26 08 62 8F 85 01 50 8F 02 01 20 A6 25 08 42 08 13 A6 25 08 52 8F 83 00 40 8F 82 00 20 A6 64 A6 25 6D 00 61 00 02 94 6D 00 69 00 D9 FF 08 00 DF 02 C6 7F C2 1F 3C CC 82 12 00 90 91 00 80 FF 40 4C 82 08 D9 FF 10 02 01 04 90 94 4C F0 AE 35 4C F0 AE 43 4C F0 2E 1C C2 18 B7 08 0E F9 6D FF 06 FF BA 0F 26 9F 6E F3 2D 0C 00 00 3C F0 00 90 91 00 F0 FA DA F0 D9 FF 54 55 68 0F A0 04 6D FF DF FF 91 00 80 FF D9 FF 10 02 4C F0 82 02 EF AF 0C 80 4C F0 EF CF 09 80 4C F0 AE C6 4C F0 AE D4 48 02 07 22 99 2C 00 90 DA 50 91 00 F0 FA AB DF A5 44 D9 FF 54 55 68 04 A0 04 6D FF C1 FF 91 00 80 FF D9 FF 10 02 4C F0 82 02 EF AF 0C 80 4C F0 EF CF 09 80 4C F0 AE C6 4C F0 AE D4 48 02 07 22 99 2C 00 90 91 00 F0 FA D9 FF 70 75 68 04 91 00 F0 FA D9 FF 74 75 68 05 00 90 02 4F 82 04 6D FF B7 FE 91 10 F0 FA 82 14 6D FF B2 FE D9 FF 90 9A 68 0F 91 10 F0 FA 82 0F D9 FF 98 9A 68 0F 91 10 F0 FA D9 FF A8 AA DA A0 68 0F DA AA 68 0F 82 14 6D FF C5 FE 82 04 6D FF C2 FE A0 04 6D FF 80 FF 91 00 80 FF D9 FF 10 02 4C F0 82 02 EF AF 0C 80 4C F0 EF CF 09 80 4C F0 AE C6 4C F0 AE D4 48 02 07 22 99 2C 00 90 02 4F 82 04 40 4C 6D FF 80 FE 91 10 F0 FA 82 14 6D FF 7B FE D9 FF 90 9A 68 0F 91 10 F0 FA 82 1F D9 FF 98 9A 68 0F 91 10 F0 FA D9 FF A8 AA DA 80 68 0F DA 50 68 0F 82 14 6D FF 8E FE 82 04 6D FF 8B FE 40 C4 6D FF 49 FF 91 00 80 FF D9 FF 10 02 4C F0 82 02 EF AF 0C 80 4C F0 EF CF 09 80 4C F0 AE C6 4C F0 AE D4 48 02 07 22 99 2C 00 90 91 00 F0 FA DA FA D9 FF 54 55 68 0F 00 90 00 00 00 00 00 10 10 70 00 00 00 00 00 10 10 70 00 00 00 00 00 10 10 70 00 00 00 00 FF FF FF FF FF FF FF FF 58 0A 10 70 00 10 10 70 00 00 00 00 58 0A 10 70 00 10 10 70 00 00 00 00 20 00 10 70 00 10 10 70 00 00 00 00 58 0A 10 70 00 00 00 00 00 00 00 00 58 0A 10 70 00 00 00 00 00 00 00 00 58 0A 10 70 58 0A 10 70 00 00 00 00 FF FF FF FF FF FF FF FF FF FF FF FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 DB DC D4 5A"));
		bool flag = MainForm::sendRequestCAN(MainForm::g_ecu_CanTx, aCanMsg, iso15765Recv, 1);
		if (flag) {
		}
	}
	void MainForm::moduleReplacemetToolStripMenuItem_Click(Object* sender, EventArgs* e)
	{
		MainForm::Iso15765Recv* iso15765Recv = new MainForm::Iso15765Recv();
		bool flag = this->ConnectToUnitCAN();
		if (flag) {
			this->aCallCanKeepAlive();
			this->aCallCanClearDTC();
			this->aCallCanStartDiag03();
			bool flag2 = MainForm::g_ECUSelected == MainForm::ECUTYPE::TC265_MT21M;
			if (flag2) {
				this->aCallCanReadData22F1F4();
				this->aCallCanReadData22F1EC();
				this->aCallCanSATC265();
			}
			else {
				bool flag3 = MainForm::g_ECUSelected == MainForm::ECUTYPE::MC9S12XEP768;
				if (flag3) {
				}
			}
		}
		else {
			MainForm::g_sErrorMessage = new String("No answer from ECU!");
		}
	}
	void MainForm::Dispose(bool disposing)
	{
		bool flag = disposing && (this->components != null);
		if (flag) {
			this->components->Dispose();
		}
		Form::Dispose(disposing);
	}
	void MainForm::InitializeComponent()
	{
		ComponentResourceManager* componentResourceManager = new ComponentResourceManager(/*ERROR: Cannot translate: System.NotImplementedException: typeOfExpression: --> TODO: --> http://www.boost.org/doc/libs/1_55_0/doc/html/typeof/tuto.html. Node: ICSharpCode.NRefactory.CSharp.TypeOfExpression*/);
		this->label1 = new Label();
		this->comboBox1 = new ComboBox();
		this->groupBox1 = new GroupBox();
		this->textBox1 = new TextBox();
		this->btnWriteFlash = new Button();
		this->progressBar1 = new ProgressBar();
		this->btnLoad = new Button();
		this->groupBox3 = new GroupBox();
		this->label2 = new Label();
		this->comboBox2 = new ComboBox();
		this->btnECUinfo = new Button();
		this->pictureBox1 = new PictureBox();
		this->tbFilelocation = new TextBox();
		this->gBoxFile = new GroupBox();
		this->btnReadFlash = new Button();
		this->menuStrip1 = new MenuStrip();
		this->diagnosticToolStripMenuItem = new ToolStripMenuItem();
		this->parameterToolStripMenuItem = new ToolStripMenuItem();
		this->readDTCToolStripMenuItem = new ToolStripMenuItem();
		this->actuatorTestToolStripMenuItem = new ToolStripMenuItem();
		this->specialFunctionToolStripMenuItem = new ToolStripMenuItem();
		this->writeVINPartNumberToolStripMenuItem = new ToolStripMenuItem();
		this->moduleReplacemetToolStripMenuItem = new ToolStripMenuItem();
		this->Log = new GroupBox();
		this->txtLog = new TextBox();
		this->btnReadEEPROM = new Button();
		this->groupBox1->SuspendLayout();
		this->groupBox3->SuspendLayout();
		(ISupportInitialize*)(this->pictureBox1)->BeginInit();
		this->gBoxFile->SuspendLayout();
		this->menuStrip1->SuspendLayout();
		this->Log->SuspendLayout();
		Form::SuspendLayout();
		this->label1->AutoSize = true;
		this->label1->Font = new Font(new String("Arial Narrow"), (float)8.25);
		this->label1->Location = new Point(6, 23);
		this->label1->Name = new String("label1");
		this->label1->Size = new Size(38, 15);
		this->label1->TabIndex = 0;
		this->label1->Text = new String("J2534 :");
		this->comboBox1->DropDownStyle = ComboBoxStyle::DropDownList;
		this->comboBox1->Font = new Font(new String("Arial Narrow"), (float)8.25, FontStyle::Bold, GraphicsUnit::Point, 0);
		this->comboBox1->FormattingEnabled = true;
		this->comboBox1->Location = new Point(50, 20);
		this->comboBox1->Name = new String("comboBox1");
		this->comboBox1->Size = new Size(220, 23);
		this->comboBox1->TabIndex = 1;
		this->comboBox1->SelectedIndexChanged += *(new EventHandler(this->comboBox1_SelectedIndexChanged));
		this->groupBox1->Controls->Add(this->comboBox1);
		this->groupBox1->Controls->Add(this->label1);
		this->groupBox1->Font = new Font(new String("Arial Narrow"), (float)8.25, FontStyle::Regular, GraphicsUnit::Point, 0);
		this->groupBox1->Location = new Point(12, 27);
		this->groupBox1->Name = new String("groupBox1");
		this->groupBox1->Size = new Size(277, 55);
		this->groupBox1->TabIndex = 2;
		this->groupBox1->TabStop = false;
		this->groupBox1->Text = new String("Device");
		this->groupBox1->Enter += *(new EventHandler(this->groupBox1_Enter));
		this->textBox1->BackColor = SystemColors::Menu;
		this->textBox1->Font = new Font(new String("Arial"), (float)8.25, FontStyle::Regular, GraphicsUnit::Point, 0);
		this->textBox1->Location = new Point(6, 41);
		this->textBox1->Name = new String("textBox1");
		this->textBox1->ReadOnly = true;
		this->textBox1->Size = new Size(439, 20);
		this->textBox1->TabIndex = 6;
		this->btnWriteFlash->Font = new Font(new String("Arial Rounded MT Bold"), (float)8.25, FontStyle::Regular, GraphicsUnit::Point, 0);
		this->btnWriteFlash->Location = new Point(464, 276);
		this->btnWriteFlash->Name = new String("btnWriteFlash");
		this->btnWriteFlash->Size = new Size(71, 24);
		this->btnWriteFlash->TabIndex = 7;
		this->btnWriteFlash->Text = new String("Write");
		this->btnWriteFlash->UseVisualStyleBackColor = true;
		this->btnWriteFlash->Click += *(new EventHandler(this->btnWriteFlash_Click));
		this->progressBar1->ForeColor = SystemColors::Menu;
		this->progressBar1->Location = new Point(6, 219);
		this->progressBar1->Name = new String("progressBar1");
		this->progressBar1->Size = new Size(335, 14);
		this->progressBar1->TabIndex = 8;
		this->btnLoad->BackColor = SystemColors::MenuHighlight;
		this->btnLoad->Font = new Font(new String("Tahoma"), (float)9.75, FontStyle::Bold, GraphicsUnit::Point, 0);
		this->btnLoad->Location = new Point(467, 370);
		this->btnLoad->Name = new String("btnLoad");
		this->btnLoad->Size = new Size(71, 35);
		this->btnLoad->TabIndex = 9;
		this->btnLoad->Text = new String("Open");
		this->btnLoad->UseVisualStyleBackColor = false;
		this->btnLoad->Click += *(new EventHandler(this->btnLoad_Click));
		this->groupBox3->Controls->Add(this->label2);
		this->groupBox3->Controls->Add(this->comboBox2);
		this->groupBox3->Font = new Font(new String("Arial Narrow"), (float)8.25);
		this->groupBox3->Location = new Point(295, 27);
		this->groupBox3->Name = new String("groupBox3");
		this->groupBox3->Size = new Size(240, 55);
		this->groupBox3->TabIndex = 10;
		this->groupBox3->TabStop = false;
		this->groupBox3->Text = new String("Flash Size");
		this->label2->AutoSize = true;
		this->label2->Font = new Font(new String("Arial Narrow"), (float)8.25);
		this->label2->Location = new Point(6, 22);
		this->label2->Name = new String("label2");
		this->label2->Size = new Size(32, 15);
		this->label2->TabIndex = 1;
		this->label2->Text = new String("Type:");
		this->comboBox2->FormattingEnabled = true;
		this->comboBox2->Location = new Point(44, 20);
		this->comboBox2->Name = new String("comboBox2");
		this->comboBox2->Size = new Size(184, 23);
		this->comboBox2->TabIndex = 0;
		this->comboBox2->SelectedIndexChanged += *(new EventHandler(this->comboBox2_SelectedIndexChanged));
		this->btnECUinfo->Font = new Font(new String("Arial Rounded MT Bold"), (float)8.25, FontStyle::Regular, GraphicsUnit::Point, 0);
		this->btnECUinfo->Location = new Point(467, 342);
		this->btnECUinfo->Name = new String("btnECUinfo");
		this->btnECUinfo->Size = new Size(71, 24);
		this->btnECUinfo->TabIndex = 12;
		this->btnECUinfo->Text = new String("ECU Info");
		this->btnECUinfo->UseVisualStyleBackColor = true;
		this->btnECUinfo->Click += *(new EventHandler(this->btnECUinfo_Click));
		this->pictureBox1->Image = (Image*)(componentResourceManager->GetObject(new String("pictureBox1.Image")));
		this->pictureBox1->Location = new Point(365, 88);
		this->pictureBox1->Name = new String("pictureBox1");
		this->pictureBox1->Size = new Size(170, 63);
		this->pictureBox1->SizeMode = PictureBoxSizeMode::StretchImage;
		this->pictureBox1->TabIndex = 13;
		this->pictureBox1->TabStop = false;
		this->tbFilelocation->Anchor = ((AnchorStyles::Top | AnchorStyles::Bottom) | AnchorStyles::Left) | AnchorStyles::Right;
		this->tbFilelocation->BackColor = SystemColors::Menu;
		this->tbFilelocation->Location = new Point(6, 15);
		this->tbFilelocation->Name = new String("tbFilelocation");
		this->tbFilelocation->Size = new Size(439, 20);
		this->tbFilelocation->TabIndex = 14;
		this->gBoxFile->Controls->Add(this->tbFilelocation);
		this->gBoxFile->Controls->Add(this->textBox1);
		this->gBoxFile->Location = new Point(12, 336);
		this->gBoxFile->Name = new String("gBoxFile");
		this->gBoxFile->Size = new Size(449, 69);
		this->gBoxFile->TabIndex = 15;
		this->gBoxFile->TabStop = false;
		this->gBoxFile->Text = new String("File");
		this->btnReadFlash->Font = new Font(new String("Arial Rounded MT Bold"), (float)8.25, FontStyle::Regular, GraphicsUnit::Point, 0);
		this->btnReadFlash->Location = new Point(379, 306);
		this->btnReadFlash->Name = new String("btnReadFlash");
		this->btnReadFlash->Size = new Size(82, 24);
		this->btnReadFlash->TabIndex = 16;
		this->btnReadFlash->Text = new String("Read Flash");
		this->btnReadFlash->UseVisualStyleBackColor = true;
		this->btnReadFlash->Click += *(new EventHandler(this->btnReadFlash_Click));
		ToolStripItemCollection* arg_A39_0 = this->menuStrip1->Items;
		Array<ToolStripItem>* expr_A27 = new Array<ToolStripItem>(2);
		expr_A27->SetData(0, this->diagnosticToolStripMenuItem);
		expr_A27->SetData(1, this->specialFunctionToolStripMenuItem);
		arg_A39_0->AddRange(expr_A27);
		this->menuStrip1->Location = new Point(0, 0);
		this->menuStrip1->Name = new String("menuStrip1");
		this->menuStrip1->Size = new Size(545, 24);
		this->menuStrip1->TabIndex = 17;
		this->menuStrip1->Text = new String("menuStrip1");
		ToolStripItemCollection* arg_AC6_0 = this->diagnosticToolStripMenuItem->DropDownItems;
		Array<ToolStripItem>* expr_AAB = new Array<ToolStripItem>(3);
		expr_AAB->SetData(0, this->parameterToolStripMenuItem);
		expr_AAB->SetData(1, this->readDTCToolStripMenuItem);
		expr_AAB->SetData(2, this->actuatorTestToolStripMenuItem);
		arg_AC6_0->AddRange(expr_AAB);
		this->diagnosticToolStripMenuItem->Name = new String("diagnosticToolStripMenuItem");
		this->diagnosticToolStripMenuItem->Size = new Size(75, 20);
		this->diagnosticToolStripMenuItem->Text = new String("Diagnostic");
		this->parameterToolStripMenuItem->Name = new String("parameterToolStripMenuItem");
		this->parameterToolStripMenuItem->Size = new Size(180, 22);
		this->parameterToolStripMenuItem->Text = new String("Parameter");
		this->readDTCToolStripMenuItem->Name = new String("readDTCToolStripMenuItem");
		this->readDTCToolStripMenuItem->Size = new Size(180, 22);
		this->readDTCToolStripMenuItem->Text = new String("Read / Erase DTC");
		this->actuatorTestToolStripMenuItem->Name = new String("actuatorTestToolStripMenuItem");
		this->actuatorTestToolStripMenuItem->Size = new Size(180, 22);
		this->actuatorTestToolStripMenuItem->Text = new String("Actuator Test");
		ToolStripItemCollection* arg_BD4_0 = this->specialFunctionToolStripMenuItem->DropDownItems;
		Array<ToolStripItem>* expr_BC2 = new Array<ToolStripItem>(2);
		expr_BC2->SetData(0, this->writeVINPartNumberToolStripMenuItem);
		expr_BC2->SetData(1, this->moduleReplacemetToolStripMenuItem);
		arg_BD4_0->AddRange(expr_BC2);
		this->specialFunctionToolStripMenuItem->Name = new String("specialFunctionToolStripMenuItem");
		this->specialFunctionToolStripMenuItem->Size = new Size(106, 20);
		this->specialFunctionToolStripMenuItem->Text = new String("Special Function");
		this->writeVINPartNumberToolStripMenuItem->Name = new String("writeVINPartNumberToolStripMenuItem");
		this->writeVINPartNumberToolStripMenuItem->ShortcutKeys = (Keys)(131159);
		this->writeVINPartNumberToolStripMenuItem->Size = new Size(194, 22);
		this->writeVINPartNumberToolStripMenuItem->Text = new String("Write VIN ECU");
		this->writeVINPartNumberToolStripMenuItem->Click += *(new EventHandler(this->writeVINPartNumberToolStripMenuItem_Click));
		this->moduleReplacemetToolStripMenuItem->Name = new String("moduleReplacemetToolStripMenuItem");
		this->moduleReplacemetToolStripMenuItem->Size = new Size(194, 22);
		this->moduleReplacemetToolStripMenuItem->Text = new String("Module Replacement");
		this->moduleReplacemetToolStripMenuItem->Click += *(new EventHandler(this->moduleReplacemetToolStripMenuItem_Click));
		this->Log->BackColor = SystemColors::Window;
		this->Log->Controls->Add(this->txtLog);
		this->Log->Controls->Add(this->progressBar1);
		this->Log->ForeColor = SystemColors::MenuText;
		this->Log->Location = new Point(12, 88);
		this->Log->Name = new String("Log");
		this->Log->Size = new Size(347, 242);
		this->Log->TabIndex = 18;
		this->Log->TabStop = false;
		this->Log->Text = new String("Information");
		this->txtLog->Anchor = ((AnchorStyles::Top | AnchorStyles::Bottom) | AnchorStyles::Left) | AnchorStyles::Right;
		this->txtLog->BackColor = SystemColors::Menu;
		this->txtLog->Location = new Point(6, 21);
		this->txtLog->Multiline = true;
		this->txtLog->Name = new String("txtLog");
		this->txtLog->Size = new Size(335, 192);
		this->txtLog->TabIndex = 0;
		this->btnReadEEPROM->Font = new Font(new String("Arial Rounded MT Bold"), (float)8.25);
		this->btnReadEEPROM->Location = new Point(379, 276);
		this->btnReadEEPROM->Name = new String("btnReadEEPROM");
		this->btnReadEEPROM->Size = new Size(82, 24);
		this->btnReadEEPROM->TabIndex = 19;
		this->btnReadEEPROM->Text = new String("Read E2P");
		this->btnReadEEPROM->UseVisualStyleBackColor = true;
		this->btnReadEEPROM->Click += *(new EventHandler(this->btnReadEEPROM_Click));
		Form::AutoScaleDimensions = new SizeF((float)6, (float)13);
		Form::AutoScaleMode = AutoScaleMode::Font;
		this->BackColor = SystemColors::Window;
		this->BackgroundImageLayout = ImageLayout::Center;
		Form::ClientSize = new Size(545, 411);
		Form::Controls->Add(this->btnReadEEPROM);
		Form::Controls->Add(this->Log);
		Form::Controls->Add(this->btnReadFlash);
		Form::Controls->Add(this->gBoxFile);
		Form::Controls->Add(this->pictureBox1);
		Form::Controls->Add(this->btnECUinfo);
		Form::Controls->Add(this->groupBox3);
		Form::Controls->Add(this->btnLoad);
		Form::Controls->Add(this->btnWriteFlash);
		Form::Controls->Add(this->groupBox1);
		Form::Controls->Add(this->menuStrip1);
		Form::FormBorderStyle = FormBorderStyle::FixedDialog;
		Form::Icon = (Icon*)(componentResourceManager->GetObject(new String("$this.Icon")));
		Form::MainMenuStrip = this->menuStrip1;
		Form::MaximizeBox = false;
		Form::Name = new String("MainForm");
		Form::StartPosition = FormStartPosition::CenterScreen;
		this->Text = new String("Harley Davidson ECU FlashTool");
		Form::Load += *(new EventHandler(this->Form1_Load));
		this->groupBox1->ResumeLayout(false);
		this->groupBox1->PerformLayout();
		this->groupBox3->ResumeLayout(false);
		this->groupBox3->PerformLayout();
		(ISupportInitialize*)(this->pictureBox1)->EndInit();
		this->gBoxFile->ResumeLayout(false);
		this->gBoxFile->PerformLayout();
		this->menuStrip1->ResumeLayout(false);
		this->menuStrip1->PerformLayout();
		this->Log->ResumeLayout(false);
		this->Log->PerformLayout();
		Form::ResumeLayout(false);
		Form::PerformLayout();
	}
	MainForm::MainForm()
	{
		Dictionary_T<String, String>* expr_69 = new Dictionary_T<String, String>();
		expr_69->Add(new String("B1T1"), new String("H594A"));
		MainForm::ECUPartNumDict = expr_69;
		MainForm::API = null;
		MainForm::Device = null;
		MainForm::Channel = null;
	}

}