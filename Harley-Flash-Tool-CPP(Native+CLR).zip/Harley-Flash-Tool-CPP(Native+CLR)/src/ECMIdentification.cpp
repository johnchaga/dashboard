
#include "ECMIdentification.h"
namespace Harley_FlashTool {
	ECMIdentification::ECMIdentification(){
		components = null;
		this->InitializeComponent();
	}
	void ECMIdentification::buttonOK_Click(Object* sender, EventArgs* e)
	{
		Form::DialogResult = DialogResult::OK;
		Form::Close();
	}
	void ECMIdentification::Dispose(bool disposing)
	{
		bool flag = disposing && (this->components != null);
		if (flag) {
			this->components->Dispose();
		}
		Form::Dispose(disposing);
	}
	void ECMIdentification::InitializeComponent()
	{
		ComponentResourceManager* componentResourceManager = new ComponentResourceManager(/*ERROR: Cannot translate: System.NotImplementedException: typeOfExpression: --> TODO: --> http://www.boost.org/doc/libs/1_55_0/doc/html/typeof/tuto.html. Node: ICSharpCode.NRefactory.CSharp.TypeOfExpression*/);
		this->textBoxECUHWPN = new TextBox();
		this->label1 = new Label();
		this->labelECUVIN = new Label();
		this->textBoxECUVIN = new TextBox();
		this->buttonOK = new Button();
		this->label2 = new Label();
		this->textBoxECUASPN = new TextBox();
		this->label3 = new Label();
		this->textBoxECUSWCONFIG = new TextBox();
		Form::SuspendLayout();
		this->textBoxECUHWPN->Location = new Point(12, 66);
		this->textBoxECUHWPN->Name = new String("textBoxECUHWPN");
		this->textBoxECUHWPN->Size = new Size(185, 20);
		this->textBoxECUHWPN->TabIndex = 0;
		this->label1->AutoSize = true;
		this->label1->Location = new Point(18, 48);
		this->label1->Name = new String("label1");
		this->label1->Size = new Size(118, 13);
		this->label1->TabIndex = 1;
		this->label1->Text = new String("ECU H/W Part Number");
		this->labelECUVIN->AutoSize = true;
		this->labelECUVIN->Location = new Point(18, 9);
		this->labelECUVIN->Name = new String("labelECUVIN");
		this->labelECUVIN->Size = new Size(90, 13);
		this->labelECUVIN->TabIndex = 2;
		this->labelECUVIN->Text = new String("ECU VIN Number");
		this->textBoxECUVIN->Location = new Point(12, 25);
		this->textBoxECUVIN->Name = new String("textBoxECUVIN");
		this->textBoxECUVIN->Size = new Size(185, 20);
		this->textBoxECUVIN->TabIndex = 3;
		this->buttonOK->BackColor = SystemColors::MenuHighlight;
		this->buttonOK->Font = new Font(new String("Microsoft Sans Serif"), (float)9, FontStyle::Regular, GraphicsUnit::Point, 0);
		this->buttonOK->Location = new Point(343, 89);
		this->buttonOK->Name = new String("buttonOK");
		this->buttonOK->Size = new Size(66, 36);
		this->buttonOK->TabIndex = 4;
		this->buttonOK->Text = new String("Write");
		this->buttonOK->UseVisualStyleBackColor = false;
		this->buttonOK->Click += *(new EventHandler(this->buttonOK_Click));
		this->label2->AutoSize = true;
		this->label2->Location = new Point(18, 89);
		this->label2->Name = new String("label2");
		this->label2->Size = new Size(138, 13);
		this->label2->TabIndex = 5;
		this->label2->Text = new String("ECU Assembly Part Number");
		this->textBoxECUASPN->Location = new Point(12, 105);
		this->textBoxECUASPN->Name = new String("textBoxECUASPN");
		this->textBoxECUASPN->Size = new Size(185, 20);
		this->textBoxECUASPN->TabIndex = 6;
		this->label3->AutoSize = true;
		this->label3->Location = new Point(234, 9);
		this->label3->Name = new String("label3");
		this->label3->Size = new Size(90, 13);
		this->label3->TabIndex = 7;
		this->label3->Text = new String("SW Configuration");
		this->textBoxECUSWCONFIG->Location = new Point(224, 25);
		this->textBoxECUSWCONFIG->MaxLength = 16;
		this->textBoxECUSWCONFIG->Name = new String("textBoxECUSWCONFIG");
		this->textBoxECUSWCONFIG->Size = new Size(185, 20);
		this->textBoxECUSWCONFIG->TabIndex = 8;
		Form::AutoScaleDimensions = new SizeF((float)6, (float)13);
		Form::AutoScaleMode = AutoScaleMode::Font;
		Form::ClientSize = new Size(419, 138);
		Form::Controls->Add(this->textBoxECUSWCONFIG);
		Form::Controls->Add(this->label3);
		Form::Controls->Add(this->textBoxECUASPN);
		Form::Controls->Add(this->label2);
		Form::Controls->Add(this->buttonOK);
		Form::Controls->Add(this->textBoxECUVIN);
		Form::Controls->Add(this->labelECUVIN);
		Form::Controls->Add(this->label1);
		Form::Controls->Add(this->textBoxECUHWPN);
		Form::Icon = (Icon*)(componentResourceManager->GetObject(new String("$this.Icon")));
		Form::Name = new String("ECMIdentification");
		Form::StartPosition = FormStartPosition::CenterScreen;
		this->Text = new String("ECM Identification");
		Form::ResumeLayout(false);
		Form::PerformLayout();
	}

}