#pragma once
#include <System/System.h>
#include "RuntimeHelpers.h"
#include "<PrivateImplementationDetails>.h"

using namespace System::Runtime::CompilerServices;
using namespace System;
namespace Harley_FlashTool {
	class ConstData : public virtual Object{
		public:
		static Array<char>* KeysArray1;
		public:
		static Array<char>* KeysArray2;
		static:
			ConstData();
	};
}