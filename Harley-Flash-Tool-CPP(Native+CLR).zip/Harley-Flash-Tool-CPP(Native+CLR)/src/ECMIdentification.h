#pragma once
#include <System/System.h>
#include "Form.h"
#include "IContainer.h"
#include "TextBox.h"
#include "Label.h"
#include "Button.h"
#include "EventArgs.h"
#include "DialogResult.h"
#include "ComponentResourceManager.h"
#include "Point.h"
#include "Size.h"
#include "SystemColors.h"
#include "Font.h"
#include "FontStyle.h"
#include "GraphicsUnit.h"
#include "EventHandler.h"
#include "SizeF.h"
#include "AutoScaleMode.h"
#include "Icon.h"
#include "FormStartPosition.h"

using namespace System::Windows::Forms;
using namespace System::ComponentModel;
using namespace System;
using namespace System::Drawing;
namespace Harley_FlashTool {
	class ECMIdentification : public virtual Form, public virtual Object{
		private:
			IContainer* components;
		public:
			TextBox* textBoxECUHWPN;
		private:
			Label* label1;
		private:
			Label* labelECUVIN;
		public:
			TextBox* textBoxECUVIN;
		private:
			Button* buttonOK;
		private:
			Label* label2;
		public:
			TextBox* textBoxECUASPN;
		private:
			Label* label3;
		public:
			TextBox* textBoxECUSWCONFIG;
		public:
			ECMIdentification();
		private:
			void buttonOK_Click(Object* sender, EventArgs* e);
		public:
		virtual void Dispose(bool disposing);
		private:
			void InitializeComponent();
	};
}