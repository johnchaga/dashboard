#include "Resources.h"
namespace Harley_FlashTool {
	namespace Properties {
		ResourceManager* Resources::resourceMan;
		CultureInfo* Resources::resourceCulture;
		ResourceManager* Resources::getResourceManager(){
			bool flag = Resources::resourceMan == null;
			if (flag){
				ResourceManager* resourceManager = new ResourceManager(new String("Harley_FlashTool.Properties.Resources"), /*ERROR: Cannot translate: System.NotImplementedException: typeOfExpression: --> TODO: --> http://www.boost.org/doc/libs/1_55_0/doc/html/typeof/tuto.html. Node: ICSharpCode.NRefactory.CSharp.TypeOfExpression*/->Assembly);
				Resources::resourceMan = resourceManager;
			}
			return Resources::resourceMan;
		}
		CultureInfo* Resources::getCulture()
		{
			return Resources::resourceCulture;
		}
		void Resources::setCulture(CultureInfo* value)
		{
			Resources::resourceCulture = value;
		}
		Bitmap* Resources::getmicrocontroller_icon_24()
		{
			Object* object = Resources::getResourceManager()->GetObject(new String("microcontroller-icon-24"), Resources::resourceCulture);
			return (Bitmap*)(object);
		}
		Resources::Resources()
		{
		}

	}
}