#include "Settings.h"
namespace Harley_FlashTool {
	namespace Properties {
		Settings* Settings::defaultInstance = (Settings*)(SettingsBase::Synchronized(new Settings()));
		Settings* Settings::getDefault(){
			return Settings::defaultInstance;
		}

	}
}