#pragma once
#include <System/System.h>
#include "ApplicationSettingsBase.h"
#include "SettingsBase.h"

using namespace System::CodeDom::Compiler;
using namespace System::Runtime::CompilerServices;
using namespace System::Configuration;
using namespace System;
namespace Harley_FlashTool {
	namespace Properties {
		//Attribute: GeneratedCode*(new String("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator"), new String("17.11.0.0"))
		//Attribute: CompilerGenerated*
		class Settings : public virtual ApplicationSettingsBase, public virtual Object{
			private:
			static Settings* defaultInstance;
			public:
			static Settings* getDefault();
				//Ignored empty method declaration
		};
	}
}