#pragma once
#include <System/System.h>
#include "ResourceManager.h"
#include "CultureInfo.h"
#include "Bitmap.h"

using namespace System::CodeDom::Compiler;
using namespace System::Diagnostics;
using namespace System::Runtime::CompilerServices;
using namespace System::Resources;
using namespace System::Globalization;
using namespace System::Drawing;
using namespace System;
namespace Harley_FlashTool {
	namespace Properties {
		//Attribute: GeneratedCode*(new String("System.Resources.Tools.StronglyTypedResourceBuilder"), new String("17.0.0.0"))
		//Attribute: DebuggerNonUserCode*
		//Attribute: CompilerGenerated*
		class Resources : public virtual Object{
			private:
			static ResourceManager* resourceMan;
			private:
			static CultureInfo* resourceCulture;
			public:
			static ResourceManager* getResourceManager();
				//Ignored empty method declaration
			public:
			static CultureInfo* getCulture();
			public:
			static void setCulture(CultureInfo* value);
			public:
			static Bitmap* getmicrocontroller_icon_24();
				//Ignored empty method declaration
			public:
				Resources();
		};
	}
}
